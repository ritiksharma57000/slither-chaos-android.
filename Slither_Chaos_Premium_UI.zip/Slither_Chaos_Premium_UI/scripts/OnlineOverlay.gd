extends CanvasLayer

# Simple full-screen overlay used for: the Connecting / searching screen (with Cancel),
# connection errors (with Retry) and the online leaderboard. Built in code so no scene file is needed.

signal match_found(info)
signal closed()

enum Mode { QUICK_PLAY, LEADERBOARD }

class Spinner extends Control:
	var t: float = 0.0
	func _process(delta: float) -> void:
		t += delta * 5.0
		update()
	func _draw() -> void:
		var c = rect_size * 0.5
		draw_arc(c, 26.0, 0.0, TAU, 32, Color(0.0, 0.9, 0.8, 0.18), 5.0)
		draw_arc(c, 26.0, t, t + 2.2, 20, Color(0.0, 0.95, 0.75, 1.0), 5.0)
		draw_arc(c, 14.0, -t * 1.6, -t * 1.6 + 1.4, 14, Color(0.9, 0.35, 1.0, 1.0), 4.0)

var mode: int = Mode.QUICK_PLAY
var status_label: Label
var message_label: Label
var spinner: Control
var btn_cancel: Button
var btn_retry: Button
var list_box: VBoxContainer
var list_scroll: ScrollContainer
var title_label: Label
var _error_shown: bool = false

func _ready() -> void:
	layer = 40
	pause_mode = PAUSE_MODE_PROCESS
	_build_ui()
	OnlineClient.connect("status_changed", self, "_on_status_changed")
	OnlineClient.connect("searching", self, "_on_searching")
	OnlineClient.connect("match_ready", self, "_on_match_ready")
	OnlineClient.connect("fatal_error", self, "_on_error")
	OnlineClient.connect("session_lost", self, "_on_error")
	OnlineClient.connect("leaderboard_received", self, "_on_leaderboard")
	_on_status_changed(OnlineClient.status)

func _exit_tree() -> void:
	for pair in [["status_changed", "_on_status_changed"], ["searching", "_on_searching"], ["match_ready", "_on_match_ready"], ["fatal_error", "_on_error"], ["session_lost", "_on_error"], ["leaderboard_received", "_on_leaderboard"]]:
		if OnlineClient.is_connected(pair[0], self, pair[1]):
			OnlineClient.disconnect(pair[0], self, pair[1])

func _make_style(bg: Color, border: Color, radius: int) -> StyleBoxFlat:
	var sb = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 24
	sb.content_margin_right = 24
	sb.content_margin_top = 18
	sb.content_margin_bottom = 18
	return sb

func _make_button(text: String, green: bool) -> Button:
	var b = Button.new()
	b.text = text
	b.rect_min_size = Vector2(240, 50)
	var normal = _make_style(Color(0, 0.75, 0.55, 1) if green else Color(0.08, 0.12, 0.22, 0.95), Color(0, 0.35, 0.25, 1) if green else Color(0.04, 0.06, 0.12, 1), 14)
	var hover = _make_style(Color(0, 0.65, 0.48, 1) if green else Color(0.06, 0.09, 0.16, 0.95), Color(0, 0.25, 0.18, 1), 14)
	normal.content_margin_top = 8
	normal.content_margin_bottom = 8
	hover.content_margin_top = 8
	hover.content_margin_bottom = 8
	b.add_stylebox_override("normal", normal)
	b.add_stylebox_override("hover", hover)
	b.add_stylebox_override("pressed", hover)
	b.add_font_override("font", UISettings.font(20))
	return b

func _build_ui() -> void:
	var dim = ColorRect.new()
	dim.color = Color(0.03, 0.05, 0.1, 0.93)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)
	dim.set_anchors_and_margins_preset(Control.PRESET_WIDE)

	var center = CenterContainer.new()
	add_child(center)
	center.set_anchors_and_margins_preset(Control.PRESET_WIDE)

	var panel = PanelContainer.new()
	panel.add_stylebox_override("panel", _make_style(Color(0.06, 0.08, 0.15, 0.96), Color(0, 0.9, 0.8, 0.6), 16))
	panel.rect_min_size = Vector2(460, 0)
	center.add_child(panel)

	var vb = VBoxContainer.new()
	vb.add_constant_override("separation", 14)
	panel.add_child(vb)

	title_label = Label.new()
	title_label.align = Label.ALIGN_CENTER
	title_label.add_color_override("font_color", Color(0, 0.95, 0.75))
	title_label.add_font_override("font", UISettings.font(30))
	vb.add_child(title_label)

	status_label = Label.new()
	status_label.align = Label.ALIGN_CENTER
	status_label.add_font_override("font", UISettings.font(18))
	vb.add_child(status_label)

	spinner = Spinner.new()
	spinner.rect_min_size = Vector2(0, 80)
	vb.add_child(spinner)

	message_label = Label.new()
	message_label.align = Label.ALIGN_CENTER
	message_label.autowrap = true
	message_label.rect_min_size = Vector2(400, 0)
	message_label.add_font_override("font", UISettings.font(18, false))
	vb.add_child(message_label)

	list_scroll = ScrollContainer.new()
	list_scroll.rect_min_size = Vector2(400, 260)
	list_scroll.visible = false
	vb.add_child(list_scroll)
	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_scroll.add_child(list_box)

	btn_retry = _make_button("RETRY", true)
	btn_retry.connect("pressed", self, "_on_retry_pressed")
	btn_retry.visible = false
	vb.add_child(btn_retry)

	btn_cancel = _make_button("CANCEL", false)
	btn_cancel.connect("pressed", self, "_on_cancel_pressed")
	vb.add_child(btn_cancel)

func start_quick_play() -> void:
	mode = Mode.QUICK_PLAY
	_error_shown = false
	title_label.text = "ONLINE QUICK PLAY"
	message_label.text = "Connecting to the online server..."
	btn_cancel.text = "CANCEL"
	btn_retry.visible = false
	spinner.visible = true
	OnlineClient.quick_play()

func show_leaderboard() -> void:
	mode = Mode.LEADERBOARD
	_error_shown = false
	title_label.text = "ONLINE LEADERBOARD"
	message_label.text = "Loading rankings from the server..."
	btn_cancel.text = "CLOSE"
	list_scroll.visible = false
	OnlineClient.request_leaderboard()

# ------------------------------------------------------------ signal handlers
func _on_status_changed(_status) -> void:
	status_label.text = "● " + OnlineClient.status_text()
	var st = OnlineClient.status_text()
	if st == "CONNECTED":
		status_label.add_color_override("font_color", Color(0.3, 1.0, 0.5))
	elif st == "OFFLINE":
		status_label.add_color_override("font_color", Color(1.0, 0.35, 0.35))
	else:
		status_label.add_color_override("font_color", Color(1.0, 0.85, 0.2))
	if st == "RECONNECTING" and not _error_shown:
		message_label.text = "Connection interrupted. Reconnecting..."

func _on_searching() -> void:
	if mode == Mode.QUICK_PLAY and not _error_shown:
		message_label.text = "Searching for a match..."

func _on_match_ready(info: Dictionary) -> void:
	if mode != Mode.QUICK_PLAY:
		return
	message_label.text = "Match found! Starting..."
	emit_signal("match_found", info)

func _on_error(msg: String) -> void:
	_error_shown = true
	spinner.visible = false
	message_label.text = msg
	btn_retry.visible = true
	btn_cancel.text = "BACK" if mode == Mode.QUICK_PLAY else "CLOSE"

func _on_leaderboard(data: Dictionary) -> void:
	if mode != Mode.LEADERBOARD:
		return
	spinner.visible = false
	var you = data.get("you", {})
	message_label.text = "Your rank: %s   |   Your best: %d" % [("#" + str(int(you.get("rank", 0)))) if int(you.get("rank", 0)) > 0 else "unranked", int(you.get("best", 0))]
	for c in list_box.get_children():
		c.queue_free()
	var rows = data.get("top", [])
	if rows.size() == 0:
		var empty = Label.new()
		empty.text = "No results yet. Be the first!"
		list_box.add_child(empty)
	for r in rows:
		var l = Label.new()
		l.text = "#%d   %s   -   %d pts   (len %d, kills %d)" % [int(r["rank"]), str(r["name"]), int(r["score"]), int(r["length"]), int(r["kills"])]
		if str(r["name"]) == OnlineClient.player_name:
			l.add_color_override("font_color", Color(1.0, 0.9, 0.3))
		list_box.add_child(l)
	list_scroll.visible = true

func _on_retry_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	if mode == Mode.QUICK_PLAY:
		start_quick_play()
	else:
		show_leaderboard()

func _on_cancel_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	if mode == Mode.QUICK_PLAY:
		OnlineClient.cancel()
	emit_signal("closed")
	queue_free()
