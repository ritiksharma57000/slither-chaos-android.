extends Node2D

onready var cpu_particles = $CPUParticles2D

func _ready() -> void:
	if cpu_particles:
		cpu_particles.emitting = UISettings.particles_enabled
	var timer = get_tree().create_timer(0.9)
	timer.connect("timeout", self, "queue_free")

func set_burst_color(color: Color) -> void:
	if cpu_particles:
		cpu_particles.color = color
