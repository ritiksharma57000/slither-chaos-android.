extends Node2D

# Visual representation of one snake in an online match.
# It never decides anything: it only renders (interpolated) state received from the server.

const BodySegmentScene = preload("res://scenes/BodySegment.tscn")
const HEAD_TEX = preload("res://assets/textures/head.png")
const INTERP_DELAY_MS = 110

var snake_id: int = 0
var is_local: bool = false
var is_bot: bool = false
var snake_name: String = ""
var is_alive: bool = true
var head_color: Color = Color(0.0, 0.95, 0.65)
var body_color: Color = Color(0.0, 0.75, 0.5)
var boosting: bool = false

var segments_parent: Node2D = null
var head_sprite: Sprite = null
var name_label: Label = null
var camera: Camera2D = null
var seg_nodes: Array = []
var states: Array = []   # [{t, pos, ang, segs, flags}]
var _shield: bool = false
var _t: float = 0.0

func setup(p_id: int, p_name: String, p_bot: bool, p_head: Color, p_body: Color, p_local: bool, p_segments_parent: Node2D) -> void:
	snake_id = p_id
	snake_name = p_name
	is_bot = p_bot
	head_color = p_head
	body_color = p_body
	is_local = p_local
	segments_parent = p_segments_parent
	head_sprite = Sprite.new()
	head_sprite.texture = HEAD_TEX
	head_sprite.modulate = head_color
	add_child(head_sprite)
	name_label = Label.new()
	name_label.text = ("[BOT] " if is_bot else "") + snake_name
	name_label.rect_position = Vector2(-70, -54)
	name_label.rect_size = Vector2(140, 16)
	name_label.align = Label.ALIGN_CENTER
	name_label.add_color_override("font_color", Color(1.0, 0.55, 0.55) if is_bot else Color(1, 1, 1))
	if is_local:
		name_label.visible = false
	add_child(name_label)
	if is_local:
		camera = Camera2D.new()
		camera.current = true
		camera.zoom = Vector2(1.18, 1.18)
		camera.limit_left = 0
		camera.limit_top = 0
		camera.limit_right = 8000
		camera.limit_bottom = 8000
		camera.limit_smoothed = true
		camera.smoothing_enabled = true
		camera.smoothing_speed = 6.0
		add_child(camera)

func push_state(now_ms: int, pos: Vector2, ang: float, segs: PoolVector2Array, flags: int) -> void:
	states.append({"t": now_ms, "pos": pos, "ang": ang, "segs": segs, "flags": flags})
	if states.size() > 6:
		states.pop_front()

func render(now_ms: int, delta: float) -> void:
	if states.empty():
		return
	var rt = now_ms - INTERP_DELAY_MS
	while states.size() > 2 and states[1]["t"] <= rt:
		states.pop_front()
	var a = states[0]
	var b = states[states.size() - 1] if states.size() == 1 else states[1]
	var f = 1.0
	if b["t"] != a["t"]:
		f = clamp(float(rt - a["t"]) / float(b["t"] - a["t"]), 0.0, 1.0)
	position = a["pos"].linear_interpolate(b["pos"], f)
	var ang = lerp_angle(a["ang"], b["ang"], f)
	head_sprite.rotation = ang
	boosting = (int(b["flags"]) & 1) != 0
	_shield = (int(b["flags"]) & 2) != 0
	head_sprite.scale = Vector2(1.1, 1.1) if boosting else Vector2(1, 1)
	_t += delta
	var alpha = 1.0
	if _shield:
		alpha = 0.55 + 0.35 * sin(_t * 14.0)
	head_sprite.modulate = Color(head_color.r, head_color.g, head_color.b, alpha)
	var sa: PoolVector2Array = a["segs"]
	var sb: PoolVector2Array = b["segs"]
	var n = sb.size()
	_ensure_segment_count(n)
	var prev = position
	for i in range(n):
		var pa = sa[i] if i < sa.size() else sb[i]
		var p = pa.linear_interpolate(sb[i], f)
		var seg = seg_nodes[i]
		seg.position = p
		var d = prev - p
		if d.length_squared() > 0.01:
			seg.rotation = d.angle()
		prev = p

func _ensure_segment_count(n: int) -> void:
	if seg_nodes.size() == n:
		return
	while seg_nodes.size() < n:
		var seg = BodySegmentScene.instance()
		segments_parent.add_child(seg)
		# purely visual: no collision detection on the client
		var area = seg.get_node("SegmentArea")
		area.monitorable = false
		area.monitoring = false
		seg_nodes.append(seg)
	while seg_nodes.size() > n:
		var old = seg_nodes.pop_back()
		old.queue_free()
	for i in range(n):
		seg_nodes[i].setup_custom_segment(i, n, i == n - 1, body_color)

func destroy() -> void:
	for seg in seg_nodes:
		if is_instance_valid(seg):
			seg.queue_free()
	seg_nodes.clear()
	queue_free()
