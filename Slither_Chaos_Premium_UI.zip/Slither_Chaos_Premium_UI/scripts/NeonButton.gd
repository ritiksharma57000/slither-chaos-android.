extends Button

# Animated neon button: vertical colour gradient, pulsing border, glow halo,
# gentle scale on hover / press. Drawn procedurally (no textures).
# The button text is drawn by the normal Button code on top of this art.

var color_a: Color = Color(0.1, 0.95, 1.0)
var color_b: Color = Color(0.0, 0.5, 1.0)
var text_color: Color = Color(0.02, 0.05, 0.12)
var icon_kind: String = ""
var font_px: int = 26

var _hover_t: float = 0.0
var _press_t: float = 0.0
var _time: float = 0.0
var _phase: float = 0.0
var _points: PoolVector2Array = PoolVector2Array()
var _colors: PoolColorArray = PoolColorArray()
var _glow_box: StyleBoxFlat = null
var _radius: float = 20.0

func setup(p_text: String, p_a: Color, p_b: Color, p_text_color: Color, p_font_px: int, p_icon: String = "") -> void:
	text = p_text
	color_a = p_a
	color_b = p_b
	text_color = p_text_color
	font_px = p_font_px
	icon_kind = p_icon
	_apply_look()

func _ready() -> void:
	flat = true
	focus_mode = Control.FOCUS_NONE
	_phase = rand_range(0.0, 6.28)
	for s in ["normal", "hover", "pressed", "disabled", "focus", "hover_pressed"]:
		add_stylebox_override(s, StyleBoxEmpty.new())
	_glow_box = StyleBoxFlat.new()
	_glow_box.bg_color = Color(0, 0, 0, 0)
	_glow_box.anti_aliasing = true
	_apply_look()
	connect("resized", self, "_on_resized")
	connect("visibility_changed", self, "_on_vis_changed")
	_on_resized()
	_on_vis_changed()

func _apply_look() -> void:
	add_font_override("font", UISettings.font(font_px))
	add_color_override("font_color", text_color)
	add_color_override("font_color_hover", text_color)
	add_color_override("font_color_pressed", text_color)
	add_color_override("font_color_disabled", Color(0.55, 0.6, 0.68))
	_rebuild_poly()
	update()

func _on_vis_changed() -> void:
	set_process(is_visible_in_tree())

func _on_resized() -> void:
	rect_pivot_offset = rect_size * 0.5
	_rebuild_poly()

func _rebuild_poly() -> void:
	var w: float = rect_size.x
	var h: float = rect_size.y
	if w < 4.0 or h < 4.0:
		return
	_radius = min(h * 0.5, 30.0)
	var pts: PoolVector2Array = PoolVector2Array()
	var cols: PoolColorArray = PoolColorArray()
	var corners = [
		Vector2(w - _radius, _radius),
		Vector2(w - _radius, h - _radius),
		Vector2(_radius, h - _radius),
		Vector2(_radius, _radius)
	]
	var start_angles = [-PI * 0.5, 0.0, PI * 0.5, PI]
	for c in range(4):
		for i in range(9):
			var a: float = start_angles[c] + (PI * 0.5) * float(i) / 8.0
			var p: Vector2 = corners[c] + Vector2(cos(a), sin(a)) * _radius
			pts.append(p)
			var tt: float = clamp(p.y / h, 0.0, 1.0)
			cols.append(color_a.linear_interpolate(color_b, tt))
	_points = pts
	_colors = cols

func _process(delta: float) -> void:
	_time += delta
	var want_hover: float = 1.0 if (is_hovered() and not disabled) else 0.0
	var mode = get_draw_mode()
	var want_press: float = 1.0 if ((mode == BaseButton.DRAW_PRESSED or mode == BaseButton.DRAW_HOVER_PRESSED) and not disabled) else 0.0
	var k: float = clamp(delta * 14.0, 0.0, 1.0)
	_hover_t = lerp(_hover_t, want_hover, k)
	_press_t = lerp(_press_t, want_press, k)
	var s: float = 1.0 + 0.045 * _hover_t - 0.06 * _press_t
	rect_scale = Vector2(s, s)
	update()

func _draw() -> void:
	if _points.size() < 8:
		return
	var w: float = rect_size.x
	var h: float = rect_size.y
	var dim: float = 0.45 if disabled else 1.0
	var pulse: float = 0.5 + 0.5 * sin(_time * 2.2 + _phase)
	if UISettings.quality == 0:
		pulse = 0.6
	# glow halo (StyleBoxFlat shadow, cheap)
	if UISettings.glow_enabled and not disabled:
		_glow_box.set_corner_radius_all(int(_radius))
		_glow_box.shadow_size = int(8.0 + 10.0 * _hover_t + 4.0 * pulse)
		_glow_box.shadow_color = Color(color_a.r, color_a.g, color_a.b, 0.28 + 0.2 * _hover_t + 0.07 * pulse)
		draw_style_box(_glow_box, Rect2(Vector2.ZERO, rect_size))
	# gradient body
	var body_cols: PoolColorArray = PoolColorArray()
	for c in _colors:
		body_cols.append(Color(c.r * dim, c.g * dim, c.b * dim, 1.0).linear_interpolate(Color(1, 1, 1, 1), 0.1 * _hover_t + 0.2 * _press_t))
	draw_polygon(_points, body_cols)
	# glossy top highlight
	var gloss: PoolVector2Array = PoolVector2Array()
	var gcols: PoolColorArray = PoolColorArray()
	var gr: float = _radius * 0.8
	gloss.append(Vector2(_radius, 3.0))
	gloss.append(Vector2(w - _radius, 3.0))
	gloss.append(Vector2(w - _radius * 0.7, h * 0.46))
	gloss.append(Vector2(_radius * 0.7, h * 0.46))
	for i in range(4):
		gcols.append(Color(1, 1, 1, 0.22 if i < 2 else 0.02))
	if gr > 0.0:
		draw_polygon(gloss, gcols)
	# pulsing neon border
	var ring: PoolVector2Array = _points
	ring.append(_points[0])
	var border_a: float = (0.55 + 0.35 * pulse + 0.2 * _hover_t) * dim
	draw_polyline(ring, Color(1, 1, 1, clamp(border_a, 0.0, 1.0)), 2.0, true)
	# icon
	if icon_kind != "":
		_draw_icon(Vector2(h * 0.62, h * 0.5), h * 0.26, Color(text_color.r, text_color.g, text_color.b, 0.95 * dim))

func _draw_icon(c: Vector2, r: float, col: Color) -> void:
	if icon_kind == "play":
		var tri: PoolVector2Array = PoolVector2Array([c + Vector2(-r * 0.7, -r), c + Vector2(r * 1.1, 0), c + Vector2(-r * 0.7, r)])
		draw_colored_polygon(tri, col)
	elif icon_kind == "customize":
		# sparkle / diamond
		var d: PoolVector2Array = PoolVector2Array([c + Vector2(0, -r * 1.1), c + Vector2(r * 0.45, -r * 0.2), c + Vector2(r * 1.1, 0), c + Vector2(r * 0.45, r * 0.2), c + Vector2(0, r * 1.1), c + Vector2(-r * 0.45, r * 0.2), c + Vector2(-r * 1.1, 0), c + Vector2(-r * 0.45, -r * 0.2)])
		draw_colored_polygon(d, col)
	elif icon_kind == "gear":
		draw_arc(c, r * 0.75, 0.0, TAU, 20, col, 3.0)
		for i in range(8):
			var a: float = float(i) * TAU / 8.0
			draw_line(c + Vector2(cos(a), sin(a)) * r * 0.8, c + Vector2(cos(a), sin(a)) * r * 1.2, col, 3.0)
		draw_circle(c, r * 0.28, col)
	elif icon_kind == "back":
		draw_line(c + Vector2(r * 0.5, -r), c + Vector2(-r * 0.6, 0), col, 3.0)
		draw_line(c + Vector2(-r * 0.6, 0), c + Vector2(r * 0.5, r), col, 3.0)
