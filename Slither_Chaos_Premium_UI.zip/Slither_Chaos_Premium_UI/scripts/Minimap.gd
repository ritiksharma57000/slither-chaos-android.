extends Control

export var map_world_size: Vector2 = Vector2(8000, 8000)

var player_node: Node2D = null
var ai_snakes_container: Node2D = null

func setup(p_player: Node2D, p_snakes: Node2D, p_size: Vector2) -> void:
	player_node = p_player
	ai_snakes_container = p_snakes
	map_world_size = p_size

func _process(_delta: float) -> void:
	update()

func _draw() -> void:
	var r_size = rect_size
	# Background
	draw_rect(Rect2(Vector2.ZERO, r_size), Color(0.04, 0.06, 0.1, 0.82), true)
	draw_rect(Rect2(Vector2.ZERO, r_size), Color(0.0, 0.9, 0.8, 0.9), false, 2.0)
	# neon corner brackets
	var cl: float = 16.0
	var bc: Color = Color(0.3, 1.0, 1.0, 1.0)
	draw_polyline(PoolVector2Array([Vector2(0, cl), Vector2(0, 0), Vector2(cl, 0)]), bc, 3.0)
	draw_polyline(PoolVector2Array([Vector2(r_size.x - cl, 0), Vector2(r_size.x, 0), Vector2(r_size.x, cl)]), bc, 3.0)
	draw_polyline(PoolVector2Array([Vector2(0, r_size.y - cl), Vector2(0, r_size.y), Vector2(cl, r_size.y)]), bc, 3.0)
	draw_polyline(PoolVector2Array([Vector2(r_size.x - cl, r_size.y), Vector2(r_size.x, r_size.y), Vector2(r_size.x, r_size.y - cl)]), bc, 3.0)
	
	# Quadrant lines (4 visual zones)
	var mid_x = r_size.x * 0.5
	var mid_y = r_size.y * 0.5
	draw_line(Vector2(mid_x, 0), Vector2(mid_x, r_size.y), Color(0.3, 0.4, 0.6, 0.4), 1.0)
	draw_line(Vector2(0, mid_y), Vector2(r_size.x, mid_y), Color(0.3, 0.4, 0.6, 0.4), 1.0)
	
	# Draw AI snakes
	if is_instance_valid(ai_snakes_container):
		for snake in ai_snakes_container.get_children():
			if is_instance_valid(snake) and snake.is_alive:
				var nx = clamp((snake.global_position.x / map_world_size.x) * r_size.x, 2, r_size.x - 2)
				var ny = clamp((snake.global_position.y / map_world_size.y) * r_size.y, 2, r_size.y - 2)
				draw_circle(Vector2(nx, ny), 2.5, Color(1.0, 0.25, 0.4, 0.9))
				
	# Draw Player
	if is_instance_valid(player_node) and player_node.is_alive:
		var px = clamp((player_node.global_position.x / map_world_size.x) * r_size.x, 3, r_size.x - 3)
		var py = clamp((player_node.global_position.y / map_world_size.y) * r_size.y, 3, r_size.y - 3)
		draw_circle(Vector2(px, py), 4.5, Color(0.0, 1.0, 0.6, 1.0))
		draw_circle(Vector2(px, py), 2.0, Color(1.0, 1.0, 1.0, 1.0))
