extends Node2D

const ARENA_WIDTH: float = 8000.0
const ARENA_HEIGHT: float = 8000.0

const FoodScene = preload("res://scenes/Food.tscn")
const AISnakeScene = preload("res://scenes/AISnake.tscn")
const ParticleBurstScene = preload("res://scenes/ParticleBurst.tscn")

onready var player = $Player
onready var segments_holder = $SegmentsHolder
onready var food_holder = $FoodHolder
onready var decor_holder = $DecorHolder
onready var ai_holder = $AIHolder
onready var hud = $CanvasHUD/HUD
onready var pause_menu = $CanvasPause/PauseMenu
onready var game_over_menu = $CanvasGameOver/GameOverMenu

const DECOR_TEXTURES = [
	preload("res://assets/textures/decor_flower.png"),
	preload("res://assets/textures/decor_mushroom.png"),
	preload("res://assets/textures/decor_rock.png"),
	preload("res://assets/textures/decor_grass.png")
]

const AI_NAMES = [
	"Viper_X", "CyberGhost", "NeonFang", "PixelCobra", "VoidHunter",
	"SolarStalker", "QuantumWorm", "ChronoGlider", "NovaDrifter", "PulseCrawler",
	"ShadowSerpent", "HexaBlade", "TitanCoil", "AstroStinger", "PrismWurm"
]

const AI_COLORS = [
	Color(0.2, 0.8, 1.0), Color(1.0, 0.3, 0.6), Color(1.0, 0.85, 0.2),
	Color(0.7, 0.2, 1.0), Color(0.2, 1.0, 0.4), Color(1.0, 0.4, 0.1)
]

var survival_time_remaining: float = 90.0
var elapsed_time: float = 0.0
var is_game_over: bool = false
var current_zone: String = "NEON CITY"

var target_food_count: int = 240
var target_ai_count: int = 14
var decor_count: int = 280

func _ready() -> void:
	randomize()
	GameManager.start_new_game()
	
	if GameManager.low_performance_mode:
		target_food_count = 120
		target_ai_count = 7
		decor_count = 100
		
	hud.connect("pause_requested", self, "_on_pause_requested")
	hud.connect("boost_state_changed", self, "_on_boost_state_changed")
	
	var joystick = hud.get_node("Control/MobileControls/VirtualJoystick")
	if joystick:
		joystick.connect("joystick_moved", self, "_on_joystick_moved")
		joystick.connect("joystick_released", self, "_on_joystick_released")
		
	pause_menu.connect("resumed", self, "_on_resumed")
	pause_menu.connect("restarted", self, "_on_restart_game")
	game_over_menu.connect("play_again", self, "_on_restart_game")
	
	player.connect("food_eaten", self, "_on_player_food_eaten")
	player.connect("died", self, "_on_player_died")
	player.connect("energy_changed", hud, "update_energy")
	
	player.initialize_segments(segments_holder)
	
	var minimap = hud.get_node("Control/Minimap")
	if minimap:
		minimap.setup(player, ai_holder, Vector2(ARENA_WIDTH, ARENA_HEIGHT))
		
	_spawn_decorations()
	_populate_food_initial()
	_spawn_ai_snakes()
	
	hud.update_stats(GameManager.current_score, player.segments.size() + 1, survival_time_remaining, GameManager.total_coins)
	hud.set_zone_name(current_zone)

func _spawn_decorations() -> void:
	for _i in range(decor_count):
		var spr = Sprite.new()
		var tex_idx = randi() % DECOR_TEXTURES.size()
		spr.texture = DECOR_TEXTURES[tex_idx]
		spr.position = Vector2(rand_range(160.0, ARENA_WIDTH - 160.0), rand_range(160.0, ARENA_HEIGHT - 160.0))
		var s = rand_range(0.85, 1.3)
		spr.scale = Vector2(s, s)
		spr.rotation = rand_range(0.0, PI * 2.0)
		decor_holder.add_child(spr)

func _populate_food_initial() -> void:
	for _i in range(target_food_count):
		_spawn_single_food()

func _spawn_single_food() -> void:
	var food = FoodScene.instance()
	food.position = Vector2(rand_range(150.0, ARENA_WIDTH - 150.0), rand_range(150.0, ARENA_HEIGHT - 150.0))
	var roll = randf()
	var type = "berry"
	if roll < 0.12:
		type = "coin"
	elif roll < 0.32:
		type = "crystal"
	elif roll < 0.60:
		type = "orb"
	food.configure(type)
	food.connect("collected", self, "_on_food_collected")
	food_holder.add_child(food)

func _spawn_ai_snakes() -> void:
	for i in range(target_ai_count):
		_spawn_single_ai(i)

func _spawn_single_ai(idx: int) -> void:
	var ai = AISnakeScene.instance()
	ai.position = Vector2(rand_range(400.0, ARENA_WIDTH - 400.0), rand_range(400.0, ARENA_HEIGHT - 400.0))
	var personalities = ["collector", "explorer", "aggressive", "survivor", "tricky"]
	var p_type = personalities[randi() % personalities.size()]
	var p_name = AI_NAMES[idx % AI_NAMES.size()]
	var h_col = AI_COLORS[idx % AI_COLORS.size()]
	var b_col = h_col.linear_interpolate(Color(0.1, 0.1, 0.1), 0.25)
	
	ai.configure(p_name, p_type, h_col, b_col, Rect2(80, 80, ARENA_WIDTH - 160, ARENA_HEIGHT - 160))
	ai.connect("ai_died", self, "_on_ai_died")
	ai_holder.add_child(ai)
	ai.initialize_segments(segments_holder)

func _on_ai_died(ai_ref, drop_positions: Array) -> void:
	var burst = ParticleBurstScene.instance()
	burst.global_position = ai_ref.global_position
	burst.set_burst_color(Color(1.0, 0.2, 0.4))
	add_child(burst)
	
	for pos in drop_positions:
		var food = FoodScene.instance()
		food.position = pos
		food.configure("crystal" if randf() < 0.4 else "orb")
		food.connect("collected", self, "_on_food_collected")
		food_holder.call_deferred("add_child", food)
		
	var timer = get_tree().create_timer(4.5)
	timer.connect("timeout", self, "_respawn_ai")

func _respawn_ai() -> void:
	if not is_game_over and ai_holder.get_child_count() < target_ai_count:
		_spawn_single_ai(randi() % AI_NAMES.size())

func _on_food_collected(food_ref) -> void:
	var burst = ParticleBurstScene.instance()
	burst.global_position = food_ref.global_position
	var burst_color = Color(1.0, 0.3, 0.6)
	if food_ref.food_type == "orb":
		burst_color = Color(0.2, 0.9, 1.0)
	elif food_ref.food_type == "crystal":
		burst_color = Color(1.0, 0.9, 0.2)
	elif food_ref.food_type == "coin":
		burst_color = Color(1.0, 1.0, 0.3)
	burst.set_burst_color(burst_color)
	add_child(burst)
	
	GameManager.play_sfx(GameManager.SFX_PICKUP, rand_range(0.95, 1.25))
	call_deferred("_spawn_single_food")

func _on_player_food_eaten(points: int, _length_gain: int, time_bonus: float) -> void:
	GameManager.add_score(points)
	survival_time_remaining += time_bonus
	hud.update_stats(GameManager.current_score, player.segments.size() + 1, survival_time_remaining, GameManager.total_coins)
	
	if points >= 50:
		hud.show_toast("+%d CHAOS CRYSTAL!" % points, Color(1.0, 0.85, 0.2))
	elif points >= 25:
		hud.show_toast("+%d ENERGY ORB!" % points, Color(0.3, 0.95, 1.0))

func _process(delta: float) -> void:
	if is_game_over:
		return
	
	survival_time_remaining -= delta
	elapsed_time += delta
	GameManager.update_survival_time(delta)
	
	hud.update_stats(GameManager.current_score, player.segments.size() + 1, max(0.0, survival_time_remaining), GameManager.total_coins)
	_update_current_zone()
	
	if survival_time_remaining <= 0.0:
		_end_game("SURVIVAL TIME EXPIRED!")
		return
		
	var ppos = player.global_position
	if ppos.x < 60.0 or ppos.x > ARENA_WIDTH - 60.0 or ppos.y < 60.0 or ppos.y > ARENA_HEIGHT - 60.0:
		_end_game("ELECTRIC BARRIER COLLISION!")

func _update_current_zone() -> void:
	var ppos = player.global_position
	var new_zone = ""
	if ppos.x < ARENA_WIDTH * 0.5 and ppos.y < ARENA_HEIGHT * 0.5:
		new_zone = "NEON CITY"
	elif ppos.x >= ARENA_WIDTH * 0.5 and ppos.y < ARENA_HEIGHT * 0.5:
		new_zone = "COSMIC FIELD"
	elif ppos.x < ARENA_WIDTH * 0.5 and ppos.y >= ARENA_HEIGHT * 0.5:
		new_zone = "CRYSTAL ZONE"
	else:
		new_zone = "DARK ZONE"
		
	if new_zone != current_zone:
		current_zone = new_zone
		hud.set_zone_name(current_zone)
		hud.show_toast("ENTERING " + current_zone, Color(0.0, 0.9, 1.0))

func _end_game(reason: String) -> void:
	if is_game_over:
		return
	is_game_over = true
	player.die(reason)

func _on_player_died(reason: String) -> void:
	GameManager.trigger_game_over(reason)
	game_over_menu.display(
		reason,
		GameManager.current_score,
		GameManager.current_length,
		elapsed_time,
		GameManager.high_score,
		GameManager.longest_length,
		GameManager.coins_collected_this_round
	)

func _on_joystick_moved(vec: Vector2) -> void:
	player.set_joystick_vector(vec)

func _on_joystick_released() -> void:
	player.set_joystick_vector(Vector2.ZERO)

func _on_boost_state_changed(is_boosting: bool) -> void:
	player.set_touch_boosting(is_boosting)

func _on_pause_requested() -> void:
	if not is_game_over:
		pause_menu.open()

func _on_resumed() -> void:
	pass

func _on_restart_game() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()
