extends Control

# Premium neon homepage. Three main buttons: PLAY, CUSTOMIZE, SETTINGS.
# Screens: home -> mode (offline / online) , customize (skins, missions, career), settings.
# Everything is built in code so there are no fragile node paths in a scene file.
# All data comes from the existing GameManager / OnlineClient autoloads (nothing is faked).

const NeonButtonScript = preload("res://scripts/NeonButton.gd")
const MenuBackgroundScript = preload("res://scripts/MenuBackground.gd")
const SkinPreviewScript = preload("res://scripts/SkinPreview.gd")
const OnlineOverlayScript = preload("res://scripts/OnlineOverlay.gd")

const DARK_TEXT: Color = Color(0.02, 0.06, 0.14)
const WHITE_TEXT: Color = Color(1, 1, 1)

var tween: Tween
var fade_rect: ColorRect
var screens: Dictionary = {}
var current: String = "home"
var _busy_until: int = 0
var _leaving: bool = false
var _time: float = 0.0
var _status_timer: float = 0.0
var _syncing: bool = false
var online_overlay = null

# home
var title_box: Control
var stat_best: Label
var stat_len: Label
var stat_time: Label
var coins_label: Label
# mode
var online_status_label: Label
# customize
var tab_buttons: Dictionary = {}
var pages: Dictionary = {}
var preview_skin_id: String = ""
var skin_preview
var skin_caption: Label
var skin_coins: Label
var skins_list: VBoxContainer
var missions_list: VBoxContainer
var career_label: Label
# settings
var btn_sfx
var btn_music
var btn_particles
var btn_glow
var btn_shake
var quality_buttons: Array = []
var quality_hint: Label
var slider_volume: HSlider
var slider_sens: HSlider
var label_volume: Label
var label_sens: Label

func _ready() -> void:
	set_anchors_and_margins_preset(Control.PRESET_WIDE)
	UISettings.apply_music()
	var bg = MenuBackgroundScript.new()
	add_child(bg)
	tween = Tween.new()
	add_child(tween)
	_build_home()
	_build_mode()
	_build_customize()
	_build_settings()
	fade_rect = ColorRect.new()
	fade_rect.color = Color(0.0, 0.0, 0.02, 1.0)
	fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fade_rect)
	fade_rect.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	_refresh_home()
	tween.interpolate_property(fade_rect, "modulate", Color(1, 1, 1, 1), Color(1, 1, 1, 0), 0.4, Tween.TRANS_QUAD, Tween.EASE_OUT)
	tween.start()

func _process(delta: float) -> void:
	_time += delta
	if title_box != null and screens["home"].visible:
		var b: float = 0.93 + 0.07 * sin(_time * 1.5)
		title_box.modulate = Color(b, b, b, 1.0)
	if current == "mode":
		_status_timer -= delta
		if _status_timer <= 0.0:
			_status_timer = 0.4
			_refresh_online_status()

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if online_overlay != null and is_instance_valid(online_overlay):
			return
		if current != "home":
			_go("home", false)

# =========================================================== small builders
func _lbl(text: String, size: int, color: Color, bold: bool = true, align: int = Label.ALIGN_CENTER) -> Label:
	var l = Label.new()
	l.text = text
	l.align = align
	l.add_font_override("font", UISettings.font(size, bold))
	l.add_color_override("font_color", color)
	return l

func _spacer(h: float) -> Control:
	var c = Control.new()
	c.rect_min_size = Vector2(0, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c

func _neon(text: String, a: Color, b: Color, txt: Color, size: Vector2, font_px: int, icon: String = ""):
	var nb = NeonButtonScript.new()
	nb.rect_min_size = size
	nb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	nb.setup(text, a, b, txt, font_px, icon)
	return nb

func _new_screen(screen_name: String) -> Control:
	var s = Control.new()
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(s)
	s.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	s.visible = (screen_name == "home")
	screens[screen_name] = s
	return s

func _column(parent: Control, width: float) -> VBoxContainer:
	var col = VBoxContainer.new()
	col.anchor_left = 0.5
	col.anchor_right = 0.5
	col.anchor_top = 0.0
	col.anchor_bottom = 1.0
	col.margin_left = -width * 0.5
	col.margin_right = width * 0.5
	col.margin_top = 24
	col.margin_bottom = -24
	col.alignment = BoxContainer.ALIGN_CENTER
	col.add_constant_override("separation", 14)
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(col)
	return col

func _back_button():
	var b = _neon("BACK", Color(0.35, 0.42, 0.7), Color(0.12, 0.15, 0.32), WHITE_TEXT, Vector2(220, 56), 22, "back")
	b.connect("pressed", self, "_on_back_pressed")
	return b

func _card_style(accent: Color) -> StyleBoxFlat:
	var sb = UISettings.make_box(Color(0.04, 0.06, 0.14, 0.92), Color(accent.r, accent.g, accent.b, 0.8), 22, 2, 16, Color(accent.r, accent.g, accent.b, 0.25))
	sb.content_margin_left = 26
	sb.content_margin_right = 26
	sb.content_margin_top = 22
	sb.content_margin_bottom = 22
	return sb

# =========================================================== HOME
func _build_home() -> void:
	var s = _new_screen("home")
	var col = _column(s, 1100)
	col.add_constant_override("separation", 10)

	title_box = HBoxContainer.new()
	title_box.alignment = BoxContainer.ALIGN_CENTER
	title_box.add_constant_override("separation", 26)
	title_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l1 = Label.new()
	l1.text = "SLITHER"
	l1.add_font_override("font", UISettings.glow_font(88, 5, Color(0.0, 0.9, 1.0, 0.3)))
	l1.add_color_override("font_color", Color(0.6, 1.0, 1.0))
	var l2 = Label.new()
	l2.text = "CHAOS"
	l2.add_font_override("font", UISettings.glow_font(88, 5, Color(1.0, 0.2, 0.8, 0.3)))
	l2.add_color_override("font_color", Color(1.0, 0.55, 0.95))
	title_box.add_child(l1)
	title_box.add_child(l2)
	col.add_child(title_box)

	col.add_child(_lbl("NEON ARCADE SURVIVAL", 24, Color(0.78, 0.6, 1.0), false))
	col.add_child(_spacer(10))

	var stats = HBoxContainer.new()
	stats.alignment = BoxContainer.ALIGN_CENTER
	stats.add_constant_override("separation", 18)
	stats.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stat_best = _stat_card(stats, "BEST SCORE", Color(1.0, 0.85, 0.3))
	stat_len = _stat_card(stats, "LONGEST SNAKE", Color(0.3, 1.0, 0.8))
	stat_time = _stat_card(stats, "BEST SURVIVAL TIME", Color(0.75, 0.5, 1.0))
	col.add_child(stats)
	col.add_child(_spacer(14))

	var play = _neon("PLAY", Color(0.15, 1.0, 0.95), Color(0.0, 0.5, 1.0), DARK_TEXT, Vector2(480, 86), 36, "play")
	play.connect("pressed", self, "_on_play_pressed")
	col.add_child(play)
	var cust = _neon("CUSTOMIZE", Color(0.75, 0.38, 1.0), Color(0.2, 0.3, 1.0), WHITE_TEXT, Vector2(480, 66), 26, "customize")
	cust.connect("pressed", self, "_on_customize_pressed")
	col.add_child(cust)
	var sett = _neon("SETTINGS", Color(1.0, 0.2, 0.75), Color(0.0, 0.65, 0.95), WHITE_TEXT, Vector2(480, 66), 26, "gear")
	sett.connect("pressed", self, "_on_settings_pressed")
	col.add_child(sett)

	# coins chip (real value from the save data)
	var chip = PanelContainer.new()
	chip.add_stylebox_override("panel", UISettings.make_box(Color(0.05, 0.08, 0.16, 0.9), Color(1.0, 0.85, 0.3, 0.7), 16, 2, 8, Color(1.0, 0.85, 0.3, 0.15)))
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	coins_label = _lbl("COINS 0", 20, Color(1.0, 0.88, 0.35))
	chip.add_child(coins_label)
	s.add_child(chip)
	chip.rect_position = Vector2(22, 18)

func _stat_card(parent: Control, caption: String, accent: Color) -> Label:
	var p = PanelContainer.new()
	p.rect_min_size = Vector2(210, 0)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_stylebox_override("panel", UISettings.make_box(Color(0.04, 0.06, 0.14, 0.82), Color(accent.r, accent.g, accent.b, 0.65), 14, 2, 8, Color(accent.r, accent.g, accent.b, 0.18)))
	var v = VBoxContainer.new()
	v.add_constant_override("separation", 0)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(_lbl(caption, 13, Color(accent.r, accent.g, accent.b, 0.9), false))
	var val = _lbl("0", 32, Color(1, 1, 1))
	v.add_child(val)
	p.add_child(v)
	parent.add_child(p)
	return val

func _refresh_home() -> void:
	stat_best.text = str(GameManager.high_score)
	stat_len.text = str(GameManager.longest_length)
	var secs_total: int = int(GameManager.best_time)
	stat_time.text = "%02d:%02d" % [secs_total / 60, secs_total % 60]
	coins_label.text = "COINS  " + str(GameManager.total_coins)

# =========================================================== MODE SELECT
func _build_mode() -> void:
	var s = _new_screen("mode")
	var col = _column(s, 1100)
	col.add_child(_lbl("SELECT MODE", 44, Color(0.6, 1.0, 1.0)))
	var row = HBoxContainer.new()
	row.alignment = BoxContainer.ALIGN_CENTER
	row.add_constant_override("separation", 30)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(row)

	# ---- offline card
	var off_accent: Color = Color(0.3, 1.0, 0.65)
	var c1 = PanelContainer.new()
	c1.rect_min_size = Vector2(440, 340)
	c1.add_stylebox_override("panel", _card_style(off_accent))
	var v1 = VBoxContainer.new()
	v1.add_constant_override("separation", 12)
	v1.add_child(_lbl("OFFLINE SURVIVAL", 30, off_accent))
	var d1 = _lbl("Play instantly. No internet needed.\nSurvive against AI snakes on the full map.", 18, Color(0.82, 0.9, 1.0), false)
	d1.autowrap = true
	d1.rect_min_size = Vector2(380, 90)
	v1.add_child(d1)
	var sp1 = Control.new()
	sp1.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v1.add_child(sp1)
	var b1 = _neon("PLAY OFFLINE", Color(0.3, 1.0, 0.65), Color(0.0, 0.65, 0.8), DARK_TEXT, Vector2(340, 66), 24, "play")
	b1.connect("pressed", self, "_on_offline_pressed")
	v1.add_child(b1)
	c1.add_child(v1)
	row.add_child(c1)

	# ---- online card
	var on_accent: Color = Color(0.3, 0.8, 1.0)
	var c2 = PanelContainer.new()
	c2.rect_min_size = Vector2(440, 340)
	c2.add_stylebox_override("panel", _card_style(on_accent))
	var v2 = VBoxContainer.new()
	v2.add_constant_override("separation", 10)
	v2.add_child(_lbl("ONLINE QUICK PLAY", 30, on_accent))
	var d2 = _lbl("Connects to the game server and finds a match for you automatically. Nothing to host or set up.", 18, Color(0.82, 0.9, 1.0), false)
	d2.autowrap = true
	d2.rect_min_size = Vector2(380, 70)
	v2.add_child(d2)
	online_status_label = _lbl("SERVER: OFFLINE", 17, Color(1.0, 0.5, 0.5))
	v2.add_child(online_status_label)
	var sp2 = Control.new()
	sp2.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v2.add_child(sp2)
	var b2 = _neon("QUICK PLAY", Color(0.35, 0.85, 1.0), Color(0.45, 0.3, 1.0), WHITE_TEXT, Vector2(340, 66), 24, "play")
	b2.connect("pressed", self, "_on_online_pressed")
	v2.add_child(b2)
	var b3 = _neon("LEADERBOARD", Color(0.3, 0.38, 0.65), Color(0.12, 0.15, 0.32), WHITE_TEXT, Vector2(340, 44), 17)
	b3.connect("pressed", self, "_on_online_leaderboard_pressed")
	v2.add_child(b3)
	c2.add_child(v2)
	row.add_child(c2)

	col.add_child(_back_button())

func _refresh_online_status() -> void:
	if online_status_label == null:
		return
	if not OnlineClient.is_server_configured():
		online_status_label.text = "SERVER ADDRESS NOT SET"
		online_status_label.add_color_override("font_color", Color(1.0, 0.5, 0.5))
		return
	var st: String = OnlineClient.status_text()
	if st == "CONNECTED":
		online_status_label.text = "SERVER: CONNECTED"
		online_status_label.add_color_override("font_color", Color(0.3, 1.0, 0.55))
	elif st == "OFFLINE":
		online_status_label.text = "SERVER: NOT CONNECTED YET"
		online_status_label.add_color_override("font_color", Color(0.75, 0.8, 0.9))
	else:
		online_status_label.text = "SERVER: " + st
		online_status_label.add_color_override("font_color", Color(1.0, 0.85, 0.3))

# =========================================================== CUSTOMIZE
func _build_customize() -> void:
	var s = _new_screen("customize")
	var col = _column(s, 1100)
	col.add_constant_override("separation", 12)
	col.add_child(_lbl("CUSTOMIZE", 44, Color(0.85, 0.65, 1.0)))

	var tabs = HBoxContainer.new()
	tabs.alignment = BoxContainer.ALIGN_CENTER
	tabs.add_constant_override("separation", 12)
	tabs.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for t in [["skins", "SNAKE SKINS"], ["missions", "MISSIONS"], ["career", "CAREER STATS"]]:
		var tb = _neon(t[1], Color(0.75, 0.38, 1.0), Color(0.2, 0.3, 1.0), WHITE_TEXT, Vector2(220, 46), 18)
		tb.connect("pressed", self, "_on_tab_pressed", [t[0]])
		tabs.add_child(tb)
		tab_buttons[t[0]] = tb
	col.add_child(tabs)

	var holder = Control.new()
	holder.rect_min_size = Vector2(1000, 360)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(holder)

	# --- skins page
	var sk = HBoxContainer.new()
	sk.add_constant_override("separation", 22)
	sk.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(sk)
	sk.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	var left = VBoxContainer.new()
	left.add_constant_override("separation", 8)
	left.rect_min_size = Vector2(380, 0)
	skin_preview = SkinPreviewScript.new()
	skin_preview.rect_min_size = Vector2(380, 250)
	left.add_child(skin_preview)
	skin_caption = _lbl("", 20, Color(1, 1, 1))
	skin_caption.autowrap = true
	skin_caption.rect_min_size = Vector2(380, 56)
	left.add_child(skin_caption)
	skin_coins = _lbl("", 18, Color(1.0, 0.88, 0.35), false)
	left.add_child(skin_coins)
	sk.add_child(left)
	var sc = ScrollContainer.new()
	sc.rect_min_size = Vector2(590, 0)
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.scroll_horizontal_enabled = false
	sk.add_child(sc)
	skins_list = VBoxContainer.new()
	skins_list.rect_min_size = Vector2(570, 0)
	skins_list.add_constant_override("separation", 8)
	sc.add_child(skins_list)
	pages["skins"] = sk

	# --- missions page
	var msc = ScrollContainer.new()
	msc.scroll_horizontal_enabled = false
	holder.add_child(msc)
	msc.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	missions_list = VBoxContainer.new()
	missions_list.rect_min_size = Vector2(980, 0)
	missions_list.add_constant_override("separation", 10)
	msc.add_child(missions_list)
	pages["missions"] = msc

	# --- career page
	var cp = PanelContainer.new()
	cp.add_stylebox_override("panel", _card_style(Color(0.6, 0.5, 1.0)))
	holder.add_child(cp)
	cp.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	career_label = _lbl("", 24, Color(0.9, 0.95, 1.0), false, Label.ALIGN_LEFT)
	cp.add_child(career_label)
	pages["career"] = cp

	col.add_child(_back_button())

func _on_tab_pressed(tab: String) -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	_show_tab(tab)

func _show_tab(tab: String) -> void:
	for k in pages.keys():
		pages[k].visible = (k == tab)
		var tb = tab_buttons[k]
		tb.self_modulate = Color(1, 1, 1, 1) if k == tab else Color(0.55, 0.55, 0.7, 0.85)
	if tab == "skins":
		_rebuild_skins()
	elif tab == "missions":
		_rebuild_missions()
	elif tab == "career":
		_update_career()

func _refresh_customize() -> void:
	if preview_skin_id == "" or not GameManager.SKINS_CATALOG.has(preview_skin_id):
		preview_skin_id = GameManager.equipped_skin_id
	_show_tab("skins")

func _rebuild_skins() -> void:
	for ch in skins_list.get_children():
		ch.queue_free()
	for skin_id in GameManager.SKINS_CATALOG.keys():
		var data = GameManager.SKINS_CATALOG[skin_id]
		var unlocked: bool = GameManager.unlocked_skins.get(skin_id, false)
		var equipped: bool = (GameManager.equipped_skin_id == skin_id)
		var row = HBoxContainer.new()
		row.add_constant_override("separation", 10)
		var sw = ColorRect.new()
		sw.color = data["head_color"]
		sw.rect_min_size = Vector2(14, 52)
		row.add_child(sw)
		var pick = Button.new()
		pick.text = data["name"] + ("   (selected)" if skin_id == preview_skin_id else "")
		pick.rect_min_size = Vector2(0, 52)
		pick.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		pick.align = Button.ALIGN_LEFT
		UISettings.style_button(pick, data["head_color"], 20)
		pick.connect("pressed", self, "_on_skin_pick", [skin_id])
		row.add_child(pick)
		var act = Button.new()
		act.rect_min_size = Vector2(200, 52)
		if equipped:
			act.text = "EQUIPPED"
			act.disabled = true
			UISettings.style_button(act, Color(0.3, 1.0, 0.6), 17)
		elif unlocked:
			act.text = "EQUIP"
			UISettings.style_button(act, Color(0.3, 0.9, 1.0), 18)
			act.connect("pressed", self, "_on_skin_equip", [skin_id])
		else:
			act.text = "UNLOCK  %d COINS" % int(data["cost"])
			UISettings.style_button(act, Color(1.0, 0.8, 0.3), 16)
			act.disabled = GameManager.total_coins < int(data["cost"])
			act.connect("pressed", self, "_on_skin_unlock", [skin_id])
		row.add_child(act)
		skins_list.add_child(row)
	_update_skin_preview()

func _update_skin_preview() -> void:
	var data = GameManager.SKINS_CATALOG.get(preview_skin_id, {})
	var unlocked: bool = GameManager.unlocked_skins.get(preview_skin_id, false)
	skin_preview.set_skin(preview_skin_id, not unlocked)
	var state: String = "LOCKED"
	if GameManager.equipped_skin_id == preview_skin_id:
		state = "EQUIPPED"
	elif unlocked:
		state = "UNLOCKED"
	skin_caption.text = str(data.get("name", "")).to_upper() + "\n" + state
	if state == "LOCKED":
		skin_caption.text += "  -  costs " + str(int(data.get("cost", 0))) + " coins"
	skin_coins.text = "Your coins: " + str(GameManager.total_coins)

func _on_skin_pick(skin_id: String) -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	preview_skin_id = skin_id
	_rebuild_skins()

func _on_skin_equip(skin_id: String) -> void:
	if GameManager.equip_skin(skin_id):
		GameManager.play_sfx(GameManager.SFX_CLICK)
		preview_skin_id = skin_id
		_rebuild_skins()

func _on_skin_unlock(skin_id: String) -> void:
	# real purchase with coins earned in the game (existing GameManager rule)
	if GameManager.unlock_skin(skin_id):
		GameManager.play_sfx(GameManager.SFX_PICKUP)
		preview_skin_id = skin_id
		_rebuild_skins()

func _rebuild_missions() -> void:
	for ch in missions_list.get_children():
		ch.queue_free()
	for m in GameManager.missions:
		var p = PanelContainer.new()
		p.add_stylebox_override("panel", UISettings.make_box(Color(0.05, 0.08, 0.16, 0.9), Color(0.3, 0.8, 1.0, 0.5), 14, 2, 6, Color(0.3, 0.8, 1.0, 0.12)))
		var h = HBoxContainer.new()
		h.add_constant_override("separation", 16)
		var v = VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		v.add_constant_override("separation", 4)
		v.add_child(_lbl("%s   (%d / %d)" % [m["title"], m["progress"], m["target"]], 21, Color(0.4, 0.95, 1.0), true, Label.ALIGN_LEFT))
		v.add_child(_lbl(m["desc"], 16, Color(0.75, 0.8, 0.9), false, Label.ALIGN_LEFT))
		var bar = ProgressBar.new()
		bar.max_value = float(m["target"])
		bar.value = float(m["progress"])
		bar.percent_visible = false
		bar.rect_min_size = Vector2(0, 8)
		bar.add_stylebox_override("fg", UISettings.make_box(Color(0.1, 0.9, 1.0, 1.0), Color(0, 0, 0, 0), 4, 0))
		bar.add_stylebox_override("bg", UISettings.make_box(Color(0.1, 0.14, 0.26, 1.0), Color(0, 0, 0, 0), 4, 0))
		v.add_child(bar)
		h.add_child(v)
		var rb = Button.new()
		rb.rect_min_size = Vector2(190, 50)
		if m["claimed"]:
			rb.text = "CLAIMED"
			rb.disabled = true
			UISettings.style_button(rb, Color(0.3, 1.0, 0.6), 17)
		elif m["progress"] >= m["target"]:
			rb.text = "CLAIM %d COINS" % int(m["reward"])
			UISettings.style_button(rb, Color(1.0, 0.85, 0.3), 17)
			rb.connect("pressed", self, "_on_claim", [m["id"]])
		else:
			rb.text = "REWARD %d" % int(m["reward"])
			rb.disabled = true
			UISettings.style_button(rb, Color(0.5, 0.55, 0.7), 17)
		h.add_child(rb)
		p.add_child(h)
		missions_list.add_child(p)

func _on_claim(mission_id: String) -> void:
	if GameManager.claim_mission_reward(mission_id):
		GameManager.play_sfx(GameManager.SFX_PICKUP)
		_rebuild_missions()

func _update_career() -> void:
	var secs_total: int = int(GameManager.best_time)
	career_label.text = "LIFETIME STATS\n\nHigh score:  %d\nLongest snake:  %d segments\nBest survival time:  %02d:%02d\nGames played:  %d\nFood eaten:  %d\nAI snakes eliminated:  %d\nCoin balance:  %d" % [
		GameManager.high_score,
		GameManager.longest_length,
		secs_total / 60, secs_total % 60,
		GameManager.total_games_played,
		GameManager.total_food_collected,
		GameManager.total_snakes_eliminated,
		GameManager.total_coins
	]

# =========================================================== SETTINGS
func _build_settings() -> void:
	var s = _new_screen("settings")
	var col = _column(s, 1100)
	col.add_constant_override("separation", 12)
	col.add_child(_lbl("SETTINGS", 44, Color(1.0, 0.6, 0.9)))

	var panel = PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	panel.add_stylebox_override("panel", _card_style(Color(1.0, 0.3, 0.8)))
	col.add_child(panel)
	var cols = HBoxContainer.new()
	cols.add_constant_override("separation", 50)
	panel.add_child(cols)

	var left = VBoxContainer.new()
	left.rect_min_size = Vector2(450, 0)
	left.add_constant_override("separation", 12)
	left.add_child(_lbl("AUDIO AND CONTROLS", 17, Color(0.4, 0.95, 1.0), false, Label.ALIGN_LEFT))
	btn_sfx = _toggle_row(left, "Sound effects", "_on_sfx_toggle")
	var vrow = _row(left, "Sound volume")
	slider_volume = _make_slider(0.0, 100.0, 5.0, "_on_volume_changed", Color(0.3, 0.95, 1.0))
	vrow.add_child(slider_volume)
	label_volume = _lbl("100%", 17, Color(1, 1, 1), true, Label.ALIGN_RIGHT)
	label_volume.rect_min_size = Vector2(56, 0)
	vrow.add_child(label_volume)
	btn_music = _toggle_row(left, "Music", "_on_music_toggle")
	var srow = _row(left, "Control sensitivity")
	slider_sens = _make_slider(50.0, 150.0, 5.0, "_on_sens_changed", Color(1.0, 0.45, 0.85))
	srow.add_child(slider_sens)
	label_sens = _lbl("100%", 17, Color(1, 1, 1), true, Label.ALIGN_RIGHT)
	label_sens.rect_min_size = Vector2(56, 0)
	srow.add_child(label_sens)
	cols.add_child(left)

	var right = VBoxContainer.new()
	right.rect_min_size = Vector2(450, 0)
	right.add_constant_override("separation", 12)
	right.add_child(_lbl("GRAPHICS", 17, Color(1.0, 0.5, 0.9), false, Label.ALIGN_LEFT))
	var qrow = _row(right, "Graphics quality")
	var qnames = ["LOW", "MEDIUM", "HIGH"]
	for i in range(3):
		var qb = _neon(qnames[i], Color(0.3, 0.9, 1.0), Color(0.2, 0.4, 1.0), DARK_TEXT, Vector2(86, 38), 15)
		qb.connect("pressed", self, "_on_quality_pressed", [i])
		qrow.add_child(qb)
		quality_buttons.append(qb)
	quality_hint = _lbl("", 14, Color(0.7, 0.78, 0.92), false, Label.ALIGN_LEFT)
	quality_hint.autowrap = true
	quality_hint.rect_min_size = Vector2(440, 38)
	right.add_child(quality_hint)
	btn_particles = _toggle_row(right, "Particles", "_on_particles_toggle")
	btn_glow = _toggle_row(right, "Glow effects", "_on_glow_toggle")
	btn_shake = _toggle_row(right, "Screen shake", "_on_shake_toggle")
	cols.add_child(right)

	var guide = _lbl("Steer: joystick, mouse, WASD or arrows     Boost: Space, Shift or the boost button", 15, Color(0.65, 0.72, 0.9), false)
	col.add_child(guide)

	var bottom = HBoxContainer.new()
	bottom.alignment = BoxContainer.ALIGN_CENTER
	bottom.add_constant_override("separation", 16)
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(_back_button())
	var mobile: bool = (OS.get_name() == "Android" or OS.get_name() == "iOS" or OS.get_name() == "HTML5")
	if not mobile:
		var q = _neon("QUIT GAME", Color(0.9, 0.3, 0.4), Color(0.45, 0.08, 0.2), WHITE_TEXT, Vector2(220, 56), 20)
		q.connect("pressed", self, "_on_quit_pressed")
		bottom.add_child(q)
	col.add_child(bottom)

func _row(parent: Control, caption: String) -> HBoxContainer:
	var r = HBoxContainer.new()
	r.add_constant_override("separation", 10)
	r.rect_min_size = Vector2(0, 40)
	var l = _lbl(caption, 19, Color(0.92, 0.96, 1.0), false, Label.ALIGN_LEFT)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.valign = Label.VALIGN_CENTER
	r.add_child(l)
	parent.add_child(r)
	return r

func _toggle_row(parent: Control, caption: String, handler: String):
	var r = _row(parent, caption)
	var b = _neon("ON", Color(0.3, 0.95, 1.0), Color(0.2, 0.4, 1.0), DARK_TEXT, Vector2(110, 38), 17)
	b.connect("pressed", self, handler)
	r.add_child(b)
	return b

func _set_toggle(b, on: bool) -> void:
	if on:
		b.setup("ON", Color(0.3, 0.95, 1.0), Color(0.2, 0.4, 1.0), DARK_TEXT, 17)
	else:
		b.setup("OFF", Color(0.32, 0.36, 0.5), Color(0.14, 0.16, 0.26), Color(0.85, 0.88, 0.95), 17)

func _knob_texture(col: Color) -> ImageTexture:
	var size: int = 30
	var img = Image.new()
	img.create(size, size, false, Image.FORMAT_RGBA8)
	img.lock()
	var c: float = float(size) * 0.5
	for y in range(size):
		for x in range(size):
			var d: float = Vector2(float(x) + 0.5 - c, float(y) + 0.5 - c).length()
			var a: float = clamp(c - 1.0 - d, 0.0, 1.0)
			var rim: float = clamp((d - (c - 6.0)) / 3.0, 0.0, 1.0)
			var px: Color = Color(1, 1, 1, a).linear_interpolate(Color(col.r, col.g, col.b, a), rim)
			img.set_pixel(x, y, px)
	img.unlock()
	var tex = ImageTexture.new()
	tex.create_from_image(img, 0)
	return tex

func _make_slider(min_v: float, max_v: float, step_v: float, handler: String, accent: Color) -> HSlider:
	var sl = HSlider.new()
	sl.min_value = min_v
	sl.max_value = max_v
	sl.step = step_v
	sl.rect_min_size = Vector2(190, 36)
	sl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sl.add_stylebox_override("slider", UISettings.make_box(Color(0.12, 0.16, 0.3, 1.0), Color(0, 0, 0, 0), 4, 0))
	sl.add_stylebox_override("grabber_area", UISettings.make_box(Color(accent.r, accent.g, accent.b, 0.9), Color(0, 0, 0, 0), 4, 0))
	sl.add_stylebox_override("grabber_area_highlight", UISettings.make_box(Color(accent.r, accent.g, accent.b, 1.0), Color(0, 0, 0, 0), 4, 0))
	var kt = _knob_texture(accent)
	sl.add_icon_override("grabber", kt)
	sl.add_icon_override("grabber_highlight", kt)
	sl.add_icon_override("grabber_disabled", kt)
	sl.connect("value_changed", self, handler)
	return sl

func _refresh_settings() -> void:
	_syncing = true
	_set_toggle(btn_sfx, GameManager.sound_enabled)
	_set_toggle(btn_music, GameManager.music_enabled)
	_set_toggle(btn_particles, UISettings.particles_enabled)
	_set_toggle(btn_glow, UISettings.glow_enabled)
	_set_toggle(btn_shake, UISettings.shake_enabled)
	slider_volume.value = round(UISettings.master_volume * 100.0)
	label_volume.text = str(int(slider_volume.value)) + "%"
	slider_sens.value = round(UISettings.sensitivity * 100.0)
	label_sens.text = str(int(slider_sens.value)) + "%"
	for i in range(3):
		var qb = quality_buttons[i]
		qb.self_modulate = Color(1, 1, 1, 1) if i == UISettings.quality else Color(0.5, 0.55, 0.7, 0.8)
	var hints = [
		"LOW: lighter effects and fewer AI snakes. Best for old PCs.",
		"MEDIUM: balanced. Standard number of AI snakes.",
		"HIGH: same gameplay as Medium, richer menu effects."
	]
	quality_hint.text = hints[UISettings.quality]
	_syncing = false

func _on_sfx_toggle() -> void:
	var on: bool = GameManager.toggle_sound()
	_set_toggle(btn_sfx, on)
	if on:
		GameManager.play_sfx(GameManager.SFX_CLICK)

func _on_music_toggle() -> void:
	var on: bool = GameManager.toggle_music()
	UISettings.apply_music()
	_set_toggle(btn_music, on)
	GameManager.play_sfx(GameManager.SFX_CLICK)

func _on_particles_toggle() -> void:
	UISettings.set_particles(not UISettings.particles_enabled)
	_set_toggle(btn_particles, UISettings.particles_enabled)
	GameManager.play_sfx(GameManager.SFX_CLICK)

func _on_glow_toggle() -> void:
	UISettings.set_glow(not UISettings.glow_enabled)
	_set_toggle(btn_glow, UISettings.glow_enabled)
	GameManager.play_sfx(GameManager.SFX_CLICK)

func _on_shake_toggle() -> void:
	UISettings.set_shake(not UISettings.shake_enabled)
	_set_toggle(btn_shake, UISettings.shake_enabled)
	GameManager.play_sfx(GameManager.SFX_CLICK)

func _on_volume_changed(v: float) -> void:
	label_volume.text = str(int(v)) + "%"
	if _syncing:
		return
	UISettings.set_volume(v / 100.0)

func _on_sens_changed(v: float) -> void:
	label_sens.text = str(int(v)) + "%"
	if _syncing:
		return
	UISettings.set_sensitivity(v / 100.0)

func _on_quality_pressed(i: int) -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	UISettings.set_quality(i)
	_refresh_settings()

func _on_quit_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	get_tree().quit()

# =========================================================== NAVIGATION
func _refresh(target: String) -> void:
	if target == "home":
		_refresh_home()
	elif target == "customize":
		_refresh_customize()
	elif target == "settings":
		_refresh_settings()
	elif target == "mode":
		_refresh_online_status()

func _go(target: String, forward: bool = true) -> void:
	if not screens.has(target) or target == current:
		return
	var now: int = OS.get_ticks_msec()
	if now < _busy_until:
		return
	_busy_until = now + 280
	GameManager.play_sfx(GameManager.SFX_CLICK)
	var old = screens[current]
	var nw = screens[target]
	_refresh(target)
	var dir: float = 1.0 if forward else -1.0
	tween.interpolate_property(old, "modulate", Color(1, 1, 1, 1), Color(1, 1, 1, 0), 0.18, Tween.TRANS_QUAD, Tween.EASE_IN)
	tween.interpolate_property(old, "rect_position", Vector2.ZERO, Vector2(-50.0 * dir, 0.0), 0.2, Tween.TRANS_QUAD, Tween.EASE_IN)
	tween.interpolate_callback(self, 0.21, "_hide_screen", old)
	nw.visible = true
	nw.modulate = Color(1, 1, 1, 0)
	nw.rect_position = Vector2(50.0 * dir, 0.0)
	tween.interpolate_property(nw, "modulate", Color(1, 1, 1, 0), Color(1, 1, 1, 1), 0.28, Tween.TRANS_QUAD, Tween.EASE_OUT, 0.1)
	tween.interpolate_property(nw, "rect_position", Vector2(50.0 * dir, 0.0), Vector2.ZERO, 0.3, Tween.TRANS_CUBIC, Tween.EASE_OUT, 0.1)
	tween.start()
	current = target

func _hide_screen(s: Control) -> void:
	if s == screens[current]:
		return
	s.visible = false
	s.modulate = Color(1, 1, 1, 1)
	s.rect_position = Vector2.ZERO

func _on_play_pressed() -> void:
	_go("mode", true)

func _on_customize_pressed() -> void:
	_go("customize", true)

func _on_settings_pressed() -> void:
	_go("settings", true)

func _on_back_pressed() -> void:
	_go("home", false)

# =========================================================== GAME START
func _on_offline_pressed() -> void:
	_start_scene("res://scenes/MainGame.tscn")

func _start_scene(path: String) -> void:
	if _leaving:
		return
	_leaving = true
	GameManager.play_sfx(GameManager.SFX_CLICK)
	tween.interpolate_property(fade_rect, "modulate", fade_rect.modulate, Color(1, 1, 1, 1), 0.25, Tween.TRANS_QUAD, Tween.EASE_IN)
	tween.interpolate_callback(self, 0.27, "_change_scene_now", path)
	tween.start()

func _change_scene_now(path: String) -> void:
	var err: int = get_tree().change_scene(path)
	if err != OK:
		push_error("MainMenu: could not open " + path)
		_leaving = false
		fade_rect.modulate = Color(1, 1, 1, 0)

# =========================================================== ONLINE (existing implementation, unchanged logic)
func _open_online_overlay() -> void:
	if online_overlay != null and is_instance_valid(online_overlay):
		online_overlay.queue_free()
	online_overlay = OnlineOverlayScript.new()
	add_child(online_overlay)
	online_overlay.connect("match_found", self, "_on_online_match_found")
	online_overlay.connect("closed", self, "_on_online_overlay_closed")

func _on_online_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	_open_online_overlay()
	online_overlay.start_quick_play()

func _on_online_leaderboard_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	_open_online_overlay()
	online_overlay.show_leaderboard()

func _on_online_match_found(_info) -> void:
	get_tree().change_scene("res://scenes/OnlineGame.tscn")

func _on_online_overlay_closed() -> void:
	online_overlay = null
	_refresh_home()
