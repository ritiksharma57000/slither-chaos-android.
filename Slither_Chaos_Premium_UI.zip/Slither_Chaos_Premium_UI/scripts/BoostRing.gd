extends Control

# Neon ring around the boost button. The arc shows the REAL boost energy left.
var fraction: float = 1.0
var pressed_state: bool = false

func _draw() -> void:
	var c: Vector2 = rect_size * 0.5
	var r: float = min(rect_size.x, rect_size.y) * 0.5 + 4.0
	var col: Color = Color(1.0, 0.65, 0.2) if pressed_state else Color(0.1, 0.95, 1.0)
	draw_arc(c, r, 0.0, TAU, 40, Color(0.1, 0.2, 0.35, 0.6), 5.0)
	if fraction > 0.01:
		draw_arc(c, r, -PI * 0.5, -PI * 0.5 + TAU * clamp(fraction, 0.0, 1.0), 40, col, 5.0)
	if UISettings.glow_enabled:
		draw_arc(c, r + 3.0, 0.0, TAU, 40, Color(col.r, col.g, col.b, 0.12), 8.0)

func set_state(frac: float, is_pressed: bool) -> void:
	if abs(frac - fraction) > 0.004 or is_pressed != pressed_state:
		fraction = frac
		pressed_state = is_pressed
		update()
