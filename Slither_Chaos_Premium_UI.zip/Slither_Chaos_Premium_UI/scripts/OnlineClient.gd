extends Node

# Autoload singleton: OnlineClient
# Talks to the dedicated Slither Chaos server over WebSocket (Godot 3.5.3 WebSocketClient).
# The server is authoritative: the client only sends a desired direction + boost flag.

signal status_changed(status)
signal searching()
signal match_ready(info)
signal snapshot(data)
signal roster_changed()
signal kill_event(ev)
signal died(result)
signal leaderboard_received(data)
signal fatal_error(message)
signal session_lost(message)

enum Status { OFFLINE, CONNECTING, CONNECTED, RECONNECTING }

const Config = preload("res://scripts/OnlineConfig.gd")
const SAVE_PATH = "user://slither_online.json"
const RETRY_DELAYS = [1.0, 2.0, 2.0, 3.0, 3.0, 4.0, 5.0, 5.0]
const CONNECT_TIMEOUT = 10.0
const RX_TIMEOUT_MS = 12000

var status: int = Status.OFFLINE
var device_id: String = ""
var player_name: String = ""
var token: String = ""

var in_match: bool = false
var searching_match: bool = false
var want_quick_play: bool = false
var pending_leaderboard: bool = false
var match_info: Dictionary = {}
var roster: Dictionary = {}
var last_snapshot: Dictionary = {}
var last_died: Dictionary = {}
var rtt_ms: int = 0

var _client: WebSocketClient = null
var _attempt: int = 0
var _retry_in: float = -1.0
var _connect_elapsed: float = 0.0
var _ping_timer: float = 0.0
var _last_rx_ms: int = 0
var _manual_close: bool = false
var _welcomed: bool = false
var _credited_death_id: int = -1

func _ready() -> void:
	pause_mode = PAUSE_MODE_PROCESS
	_load_identity()

# ----------------------------------------------------------------- identity
func _load_identity() -> void:
	randomize()
	var file = File.new()
	if file.file_exists(SAVE_PATH) and file.open(SAVE_PATH, File.READ) == OK:
		var parsed = parse_json(file.get_as_text())
		file.close()
		if typeof(parsed) == TYPE_DICTIONARY:
			device_id = str(parsed.get("device_id", ""))
			player_name = str(parsed.get("player_name", ""))
	if device_id.length() < 16:
		device_id = "%08x%08x%08x%08x" % [randi(), randi(), randi(), randi()]
	if player_name.length() < 2:
		player_name = "Player" + str(1000 + randi() % 9000)
	_save_identity()

func _save_identity() -> void:
	var file = File.new()
	if file.open(SAVE_PATH, File.WRITE) == OK:
		file.store_string(to_json({"device_id": device_id, "player_name": player_name}))
		file.close()

func set_player_name(new_name: String) -> void:
	player_name = new_name.strip_edges().left(16)
	_save_identity()

# ----------------------------------------------------------------- public API
func status_text() -> String:
	match status:
		Status.CONNECTING:
			return "CONNECTING"
		Status.CONNECTED:
			return "CONNECTED"
		Status.RECONNECTING:
			return "RECONNECTING"
	return "OFFLINE"

func get_server_url() -> String:
	for arg in OS.get_cmdline_args():
		if str(arg).begins_with("--server="):
			return str(arg).substr(9)
	var file = File.new()
	if file.file_exists("user://server_url.txt") and file.open("user://server_url.txt", File.READ) == OK:
		var u = file.get_as_text().strip_edges()
		file.close()
		if u != "":
			return u
	return Config.SERVER_URL

func is_server_configured() -> bool:
	return get_server_url().find("YOUR-SERVER-DOMAIN") == -1

func quick_play() -> void:
	want_quick_play = true
	searching_match = true
	if status == Status.CONNECTED:
		_send({"t": "quick_play"})
		emit_signal("searching")
	else:
		_connect()

func cancel() -> void:
	want_quick_play = false
	searching_match = false
	if status == Status.CONNECTED:
		_send({"t": "cancel"})
	elif status == Status.CONNECTING or status == Status.RECONNECTING:
		disconnect_from_server()

func leave_match() -> void:
	if in_match and status == Status.CONNECTED:
		_send({"t": "leave"})
	in_match = false
	searching_match = false
	want_quick_play = false

func send_input(angle: float, boost: bool) -> void:
	if status == Status.CONNECTED and in_match:
		_send({"t": "inp", "a": stepify(angle, 0.01), "b": 1 if boost else 0})

func request_leaderboard() -> void:
	pending_leaderboard = true
	if status == Status.CONNECTED:
		_send({"t": "lb"})
		pending_leaderboard = false
	else:
		_connect()

func disconnect_from_server() -> void:
	_manual_close = true
	_welcomed = false
	_attempt = 0
	_retry_in = -1.0
	_destroy_client()
	_set_status(Status.OFFLINE)
	_manual_close = false

# ----------------------------------------------------------------- connection
func _connect() -> void:
	if status != Status.OFFLINE:
		return
	if not is_server_configured():
		searching_match = false
		want_quick_play = false
		emit_signal("fatal_error", "The online server address is not set up yet.\nThe game developer must set SERVER_URL in scripts/OnlineConfig.gd.")
		return
	_attempt = 0
	_open_socket(Status.CONNECTING)

func _open_socket(new_status: int) -> void:
	_destroy_client()
	_client = WebSocketClient.new()
	_client.connect("connection_established", self, "_on_established")
	_client.connect("connection_closed", self, "_on_closed")
	_client.connect("connection_error", self, "_on_error")
	_client.connect("data_received", self, "_on_data")
	var err = _client.connect_to_url(get_server_url(), PoolStringArray(), false)
	_connect_elapsed = 0.0
	_last_rx_ms = OS.get_ticks_msec()
	if err != OK:
		_destroy_client()
		_on_link_lost()
		return
	_set_status(new_status)

func _destroy_client() -> void:
	if _client != null:
		_client.disconnect("connection_established", self, "_on_established")
		_client.disconnect("connection_closed", self, "_on_closed")
		_client.disconnect("connection_error", self, "_on_error")
		_client.disconnect("data_received", self, "_on_data")
		_client.disconnect_from_host()
		_client = null

func _set_status(new_status: int) -> void:
	if status != new_status:
		status = new_status
		emit_signal("status_changed", status)

func _on_established(_proto) -> void:
	_client.get_peer(1).set_write_mode(WebSocketPeer.WRITE_MODE_TEXT)
	_send({"t": "hello", "v": Config.PROTOCOL, "device": device_id, "token": token, "name": player_name, "skin": GameManager.equipped_skin_id})

func _on_closed(_clean) -> void:
	_on_link_lost()

func _on_error() -> void:
	_on_link_lost()

func _on_link_lost() -> void:
	_destroy_client()
	if _manual_close:
		return
	var needs_link = in_match or searching_match or want_quick_play or pending_leaderboard
	# before the first successful handshake we retry once; after a working connection we retry several times
	var max_attempts = RETRY_DELAYS.size() if _welcomed else 1
	if needs_link and _attempt < max_attempts:
		_retry_in = RETRY_DELAYS[_attempt]
		_attempt += 1
		_set_status(Status.RECONNECTING)
		return
	if needs_link:
		_give_up()
	else:
		_welcomed = false
		_attempt = 0
		_retry_in = -1.0
		_set_status(Status.OFFLINE)

func _give_up() -> void:
	var was_in_match = in_match
	in_match = false
	searching_match = false
	want_quick_play = false
	pending_leaderboard = false
	_attempt = 0
	_welcomed = false
	_retry_in = -1.0
	_set_status(Status.OFFLINE)
	if was_in_match:
		emit_signal("session_lost", "Connection to the server was lost.")
	else:
		emit_signal("fatal_error", "Could not reach the online server.\nCheck your internet connection and try again.")

func _process(delta: float) -> void:
	if _client != null:
		_client.poll()
	if status == Status.CONNECTING and _client != null:
		_connect_elapsed += delta
		if _connect_elapsed > CONNECT_TIMEOUT:
			_destroy_client()
			_on_link_lost()
	if _retry_in >= 0.0:
		_retry_in -= delta
		if _retry_in < 0.0:
			_retry_in = -1.0
			_open_socket(Status.RECONNECTING)
	if status == Status.CONNECTED and _client != null:
		_ping_timer -= delta
		if _ping_timer <= 0.0:
			_ping_timer = 4.0
			_send({"t": "ping", "c": OS.get_ticks_msec()})
		if OS.get_ticks_msec() - _last_rx_ms > RX_TIMEOUT_MS:
			_destroy_client()
			_on_link_lost()

func _send(obj: Dictionary) -> void:
	if _client != null and _client.get_peer(1).is_connected_to_host():
		_client.get_peer(1).put_packet(to_json(obj).to_utf8())

# ----------------------------------------------------------------- messages
func _on_data() -> void:
	_last_rx_ms = OS.get_ticks_msec()
	var text = _client.get_peer(1).get_packet().get_string_from_utf8()
	var msg = parse_json(text)
	if typeof(msg) != TYPE_DICTIONARY:
		return
	match str(msg.get("t", "")):
		"welcome":
			_on_welcome(msg)
		"mm":
			if msg.get("s", "") == "searching":
				emit_signal("searching")
		"match":
			_on_match(msg)
		"roster":
			roster.clear()
			for p in msg.get("p", []):
				roster[int(p["id"])] = p
			emit_signal("roster_changed")
		"s":
			last_snapshot = msg
			if in_match:
				emit_signal("snapshot", msg)
		"ev":
			emit_signal("kill_event", msg)
		"died":
			_on_died(msg)
		"lb":
			emit_signal("leaderboard_received", msg)
		"pong":
			rtt_ms = OS.get_ticks_msec() - int(msg.get("c", 0))
		"error":
			searching_match = false
			want_quick_play = false
			emit_signal("fatal_error", str(msg.get("msg", "Server error.")))

func _on_welcome(msg: Dictionary) -> void:
	token = str(msg.get("token", ""))
	_welcomed = true
	if str(msg.get("name", "")) != "":
		player_name = str(msg["name"])
		_save_identity()
	_attempt = 0
	_retry_in = -1.0
	_set_status(Status.CONNECTED)
	if in_match and not bool(msg.get("resumed", false)):
		in_match = false
		emit_signal("session_lost", "The match ended while you were disconnected.")
		return
	if want_quick_play and not in_match:
		_send({"t": "quick_play"})
		emit_signal("searching")
	if pending_leaderboard:
		pending_leaderboard = false
		_send({"t": "lb"})

func _on_match(msg: Dictionary) -> void:
	match_info = msg
	last_snapshot = {}
	roster.clear()
	for p in msg.get("roster", []):
		roster[int(p["id"])] = p
	in_match = true
	searching_match = false
	want_quick_play = false
	emit_signal("match_ready", msg)

func _on_died(msg: Dictionary) -> void:
	in_match = false
	last_died = msg
	var did = int(msg.get("did", 0))
	if did != _credited_death_id:
		_credited_death_id = did
		# Coins are computed by the server from real pickups/eliminations; the client only credits them once.
		var coins = int(msg.get("coins", 0))
		if coins > 0:
			GameManager.add_coins(coins)
			GameManager.save_game_data()
		emit_signal("died", msg)
