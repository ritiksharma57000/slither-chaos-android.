extends Reference

# ---------------------------------------------------------------------------
# ONLINE SERVER ADDRESS - set this ONCE as the developer, then export the game.
# Players never see or type this. It is a public address, not a secret.
#   Hosted server with HTTPS (recommended):  "wss://your-domain.example"
#   Local test on your own PC:               "ws://127.0.0.1:8080"
#
# For testing you can also override it without editing this file:
#   * command line:  --server=ws://127.0.0.1:8080
#   * or a text file  user://server_url.txt  containing the URL
# ---------------------------------------------------------------------------
const SERVER_URL = "wss://confusion-compassionate-monkey.abasthan.app"
const PROTOCOL = 1
