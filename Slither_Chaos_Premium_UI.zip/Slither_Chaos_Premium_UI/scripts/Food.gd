extends Area2D

signal collected(food_ref)

export var food_type: String = "berry" # berry, orb, crystal, coin
export var points: int = 10
export var length_gain: int = 1
export var time_bonus: float = 2.0
export var coin_reward: int = 0

onready var sprite = $Sprite
onready var collision_shape = $CollisionShape2D

const TEXTURE_BERRY = preload("res://assets/textures/food_berry.png")
const TEXTURE_ORB = preload("res://assets/textures/food_orb.png")
const TEXTURE_CRYSTAL = preload("res://assets/textures/food_crystal.png")

var float_offset: float = 0.0
var is_collected: bool = false
var pulse_time: float = 0.0

func _ready() -> void:
	float_offset = rand_range(0.0, PI * 2.0)
	apply_type_properties()

func configure(type_name: String) -> void:
	food_type = type_name
	apply_type_properties()

func apply_type_properties() -> void:
	if not sprite:
		return
	match food_type:
		"berry":
			sprite.texture = TEXTURE_BERRY
			sprite.modulate = Color(1, 1, 1)
			points = 10
			length_gain = 1
			time_bonus = 2.0
			coin_reward = 0
			scale = Vector2(1.0, 1.0)
		"orb":
			sprite.texture = TEXTURE_ORB
			sprite.modulate = Color(0.2, 0.9, 1.0)
			points = 25
			length_gain = 2
			time_bonus = 3.5
			coin_reward = 1
			scale = Vector2(1.1, 1.1)
		"crystal":
			sprite.texture = TEXTURE_CRYSTAL
			sprite.modulate = Color(1.0, 0.85, 0.2)
			points = 50
			length_gain = 3
			time_bonus = 5.0
			coin_reward = 2
			scale = Vector2(1.2, 1.2)
		"coin":
			sprite.texture = TEXTURE_CRYSTAL
			sprite.modulate = Color(1.0, 0.95, 0.1)
			points = 30
			length_gain = 1
			time_bonus = 1.5
			coin_reward = 5
			scale = Vector2(1.1, 1.1)

func _process(delta: float) -> void:
	pulse_time += delta * 3.5
	var bob = sin(pulse_time + float_offset) * 3.5
	sprite.position.y = bob
	if food_type == "orb" or food_type == "coin":
		sprite.rotation += delta * 1.8
	elif food_type == "crystal":
		var s = 1.2 + sin(pulse_time * 1.5) * 0.08
		sprite.scale = Vector2(s, s)

func collect(collector_ref) -> void:
	if is_collected:
		return
	is_collected = true
	collision_shape.set_deferred("disabled", true)
	emit_signal("collected", self)
	if coin_reward > 0:
		GameManager.add_coins(coin_reward)
	if collector_ref.has_method("on_food_eaten"):
		collector_ref.on_food_eaten(points, length_gain, time_bonus)
	queue_free()
