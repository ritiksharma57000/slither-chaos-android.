extends Node2D

# Online match scene. All gameplay (movement, food, growth, collisions, scores, bots) is decided by the
# server. This script only (1) sends the player's desired direction/boost and (2) draws what the server reports.

const ARENA_SIZE: float = 8000.0
const FoodScene = preload("res://scenes/Food.tscn")
const OnlineSnakeScript = preload("res://scripts/OnlineSnake.gd")
const OnlineOverlayScript = preload("res://scripts/OnlineOverlay.gd")
const HUDScene = preload("res://scenes/HUD.tscn")
const GameOverScene = preload("res://scenes/GameOverMenu.tscn")
const ParticleBurstScene = preload("res://scenes/ParticleBurst.tscn")
const FenceScript = preload("res://scripts/BoundaryFenceDraw.gd")
const BG_TEX = preload("res://assets/textures/bg_tile.png")
const DECOR_TEXTURES = [
	preload("res://assets/textures/decor_flower.png"),
	preload("res://assets/textures/decor_mushroom.png"),
	preload("res://assets/textures/decor_rock.png"),
	preload("res://assets/textures/decor_grass.png")
]
const BOT_COLORS = [
	Color(0.2, 0.8, 1.0), Color(1.0, 0.3, 0.6), Color(1.0, 0.85, 0.2),
	Color(0.7, 0.2, 1.0), Color(0.2, 1.0, 0.4), Color(1.0, 0.4, 0.1)
]

class MiniProxy extends Node2D:
	var is_alive: bool = true

var decor_holder: Node2D
var food_holder: Node2D
var segments_holder: Node2D
var snakes_holder: Node2D
var mini_holder: Node2D
var hud
var game_over_menu
var overlay = null
var status_badge: Label
var board_labels: Array = []
var board_panel: PanelContainer

var my_id: int = 0
var snakes: Dictionary = {}     # id -> OnlineSnake (only snakes near the player are drawn)
var proxies: Dictionary = {}    # id -> MiniProxy (minimap dots for every snake)
var foods: Dictionary = {}      # id -> Food node
var local_snake = null
var is_dead: bool = false
var joystick_direction: Vector2 = Vector2.ZERO
var touch_boosting: bool = false
var last_sent_angle: float = 999.0
var last_sent_boost: bool = false
var send_timer: float = 0.0
var last_score: int = 0
var leave_armed_until: int = 0
var last_energy: float = 100.0

func _ready() -> void:
	if not OnlineClient.in_match:
		get_tree().change_scene("res://scenes/MainMenu.tscn")
		return
	my_id = int(OnlineClient.match_info.get("you", 0))
	_build_world()
	_build_ui()
	OnlineClient.connect("snapshot", self, "_on_snapshot")
	OnlineClient.connect("kill_event", self, "_on_kill_event")
	OnlineClient.connect("died", self, "_on_died")
	OnlineClient.connect("status_changed", self, "_on_status_changed")
	OnlineClient.connect("session_lost", self, "_on_session_lost")
	OnlineClient.connect("fatal_error", self, "_on_session_lost")
	_on_status_changed(OnlineClient.status)
	if not OnlineClient.last_snapshot.empty():
		_on_snapshot(OnlineClient.last_snapshot)

func _exit_tree() -> void:
	for pair in [["snapshot", "_on_snapshot"], ["kill_event", "_on_kill_event"], ["died", "_on_died"], ["status_changed", "_on_status_changed"], ["session_lost", "_on_session_lost"], ["fatal_error", "_on_session_lost"]]:
		if OnlineClient.is_connected(pair[0], self, pair[1]):
			OnlineClient.disconnect(pair[0], self, pair[1])
	if OnlineClient.in_match:
		OnlineClient.leave_match()

# ------------------------------------------------------------------ world
func _build_world() -> void:
	var bg = TextureRect.new()
	bg.texture = BG_TEX
	bg.stretch_mode = TextureRect.STRETCH_TILE
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.rect_size = Vector2(ARENA_SIZE, ARENA_SIZE)
	add_child(bg)

	decor_holder = Node2D.new()
	add_child(decor_holder)
	# same seed per match => every client sees the same decoration; purely cosmetic
	seed(int(OnlineClient.match_info.get("id", 1)) * 7919)
	var decor_count = 100 if GameManager.low_performance_mode else 280
	for _i in range(decor_count):
		var spr = Sprite.new()
		spr.texture = DECOR_TEXTURES[randi() % DECOR_TEXTURES.size()]
		spr.position = Vector2(rand_range(160.0, ARENA_SIZE - 160.0), rand_range(160.0, ARENA_SIZE - 160.0))
		var s = rand_range(0.85, 1.3)
		spr.scale = Vector2(s, s)
		spr.rotation = rand_range(0.0, PI * 2.0)
		decor_holder.add_child(spr)
	randomize()

	var fence = Node2D.new()
	fence.set_script(FenceScript)
	add_child(fence)

	food_holder = Node2D.new()
	add_child(food_holder)
	segments_holder = Node2D.new()
	add_child(segments_holder)
	snakes_holder = Node2D.new()
	add_child(snakes_holder)
	mini_holder = Node2D.new()
	add_child(mini_holder)

func _build_ui() -> void:
	var hud_layer = CanvasLayer.new()
	hud_layer.layer = 10
	add_child(hud_layer)
	hud = HUDScene.instance()
	hud_layer.add_child(hud)
	hud.connect("pause_requested", self, "_on_leave_requested")
	hud.connect("boost_state_changed", self, "_on_boost_state_changed")
	var joystick = hud.get_node("Control/MobileControls/VirtualJoystick")
	if joystick:
		joystick.connect("joystick_moved", self, "_on_joystick_moved")
		joystick.connect("joystick_released", self, "_on_joystick_released")
	hud.get_node("Control/TopBar/Margin/HBox/PauseButton").text = "LEAVE"
	hud.set_zone_name("ONLINE MATCH #" + str(int(OnlineClient.match_info.get("id", 0))))

	var over_layer = CanvasLayer.new()
	over_layer.layer = 25
	add_child(over_layer)
	game_over_menu = GameOverScene.instance()
	over_layer.add_child(game_over_menu)
	game_over_menu.connect("play_again", self, "_on_play_again")

	var root = hud.get_node("Control")
	status_badge = Label.new()
	status_badge.anchor_left = 1.0
	status_badge.anchor_right = 1.0
	status_badge.margin_left = -250.0
	status_badge.margin_right = -16.0
	status_badge.margin_top = 82.0
	status_badge.margin_bottom = 100.0
	status_badge.align = Label.ALIGN_RIGHT
	root.add_child(status_badge)

	board_panel = PanelContainer.new()
	board_panel.anchor_left = 1.0
	board_panel.anchor_right = 1.0
	board_panel.margin_left = -250.0
	board_panel.margin_right = -16.0
	board_panel.margin_top = 104.0
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.08, 0.15, 0.7)
	sb.set_corner_radius_all(10)
	sb.content_margin_left = 10
	sb.content_margin_right = 10
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6
	board_panel.add_stylebox_override("panel", sb)
	board_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(board_panel)
	var vb = VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	board_panel.add_child(vb)
	for _i in range(8):
		var l = Label.new()
		l.clip_text = true
		vb.add_child(l)
		board_labels.append(l)

	var minimap = hud.get_node("Control/Minimap")
	if minimap:
		var placeholder = MiniProxy.new()   # stands in for the local snake until the first snapshot arrives
		placeholder.is_alive = false
		add_child(placeholder)
		minimap.setup(placeholder, mini_holder, Vector2(ARENA_SIZE, ARENA_SIZE))

# ------------------------------------------------------------------ input -> server
func _process(delta: float) -> void:
	var now = OS.get_ticks_msec()
	for id in snakes.keys():
		snakes[id].render(now, delta)
	if local_snake != null and is_instance_valid(local_snake):
		var cam = local_snake.camera
		if cam != null:
			var target = Vector2(1.35, 1.35) if local_snake.boosting else Vector2(1.18, 1.18)
			cam.zoom = cam.zoom.linear_interpolate(target, delta * 4.0)
	if is_dead or local_snake == null:
		return
	send_timer -= delta
	var dir = _read_direction()
	var boost = touch_boosting or Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_SHIFT) or Input.is_mouse_button_pressed(BUTTON_RIGHT)
	if dir.length_squared() > 0.01:
		var ang = dir.angle()
		if send_timer <= 0.0 and (abs(angle_difference(ang, last_sent_angle)) > 0.03 or boost != last_sent_boost or send_timer < -0.2):
			OnlineClient.send_input(ang, boost)
			last_sent_angle = ang
			last_sent_boost = boost
			send_timer = 0.05
	elif boost != last_sent_boost and send_timer <= 0.0:
		OnlineClient.send_input(last_sent_angle if last_sent_angle < 100.0 else 0.0, boost)
		last_sent_boost = boost
		send_timer = 0.05

func angle_difference(a: float, b: float) -> float:
	return wrapf(a - b + PI, 0.0, TAU) - PI

func _read_direction() -> Vector2:
	if joystick_direction.length_squared() > 0.04:
		return joystick_direction.normalized()
	var kx = 0.0
	var ky = 0.0
	if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
		kx += 1.0
	if Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A):
		kx -= 1.0
	if Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S):
		ky += 1.0
	if Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W):
		ky -= 1.0
	var key_dir = Vector2(kx, ky)
	if key_dir.length_squared() > 0.01:
		return key_dir.normalized()
	if Input.is_mouse_button_pressed(BUTTON_LEFT) and local_snake != null:
		var to_mouse = get_global_mouse_position() - local_snake.global_position
		if to_mouse.length_squared() > 400.0:
			return to_mouse.normalized()
	return Vector2.ZERO

func _on_joystick_moved(vec: Vector2) -> void:
	joystick_direction = vec

func _on_joystick_released() -> void:
	joystick_direction = Vector2.ZERO

func _on_boost_state_changed(is_boosting: bool) -> void:
	touch_boosting = is_boosting

# ------------------------------------------------------------------ server -> screen
func _skin_colors(skin_id: String) -> Array:
	var info = GameManager.SKINS_CATALOG.get(skin_id, GameManager.SKINS_CATALOG["neon_viper"])
	return [info["head_color"], info["body_color"]]

func _roster_entry(id: int) -> Dictionary:
	return OnlineClient.roster.get(id, {"n": "Player", "b": 0, "sk": "neon_viper", "ci": 0})

func _create_snake(id: int):
	var info = _roster_entry(id)
	var is_bot = int(info.get("b", 0)) == 1
	var head_col: Color
	var body_col: Color
	if is_bot:
		head_col = BOT_COLORS[int(info.get("ci", 0)) % BOT_COLORS.size()]
		body_col = head_col.linear_interpolate(Color(0.1, 0.1, 0.1), 0.25)
	elif id == my_id:
		var c = _skin_colors(GameManager.equipped_skin_id)
		head_col = c[0]
		body_col = c[1]
	else:
		var c2 = _skin_colors(str(info.get("sk", "neon_viper")))
		head_col = c2[0]
		body_col = c2[1]
	var sn = Node2D.new()
	sn.set_script(OnlineSnakeScript)
	snakes_holder.add_child(sn)
	sn.setup(id, str(info.get("n", "Player")), is_bot, head_col, body_col, id == my_id, segments_holder)
	snakes[id] = sn
	if id == my_id:
		local_snake = sn
		var minimap = hud.get_node("Control/Minimap")
		if minimap:
			minimap.setup(sn, mini_holder, Vector2(ARENA_SIZE, ARENA_SIZE))
	return sn

func _on_snapshot(data: Dictionary) -> void:
	if is_dead:
		return
	var now = OS.get_ticks_msec()
	var seen = {}
	for e in data.get("sn", []):
		var id = int(e[0])
		seen[id] = true
		var sn = snakes.get(id)
		if sn == null:
			sn = _create_snake(id)
		var flat = e[7]
		var segs = PoolVector2Array()
		for i in range(0, flat.size() - 1, 2):
			segs.append(Vector2(flat[i], flat[i + 1]))
		sn.push_state(now, Vector2(e[1], e[2]), float(e[3]) / 100.0, segs, int(e[4]))
	for id in snakes.keys():
		if not seen.has(id) and id != my_id:
			snakes[id].destroy()
			snakes.erase(id)
	_update_minimap_proxies(data.get("mm", []))
	_update_food(data.get("f", []))
	_update_hud(data)

func _update_minimap_proxies(mm: Array) -> void:
	var present = {}
	for m in mm:
		var id = int(m[0])
		if id == my_id:
			continue
		present[id] = true
		var p = proxies.get(id)
		if p == null:
			p = MiniProxy.new()
			mini_holder.add_child(p)
			proxies[id] = p
		p.position = Vector2(m[1], m[2])
	for id in proxies.keys():
		if not present.has(id):
			proxies[id].queue_free()
			proxies.erase(id)

func _update_food(list: Array) -> void:
	var present = {}
	var types = ["berry", "orb", "crystal", "coin"]
	for f in list:
		var id = int(f[0])
		present[id] = true
		if not foods.has(id):
			var food = FoodScene.instance()
			food.position = Vector2(f[1], f[2])
			food.configure(types[int(f[3]) % 4])
			food_holder.add_child(food)
			food.monitoring = false      # visual only: the server decides who eats what
			food.monitorable = false
			foods[id] = food
	for id in foods.keys():
		if not present.has(id):
			var node = foods[id]
			if is_instance_valid(node):
				if local_snake != null and node.position.distance_to(local_snake.position) < 160.0:
					_pickup_effect(node)
				node.queue_free()
			foods.erase(id)

func _pickup_effect(food) -> void:
	var burst = ParticleBurstScene.instance()
	burst.global_position = food.global_position
	var col = Color(1.0, 0.3, 0.6)
	if food.food_type == "orb":
		col = Color(0.2, 0.9, 1.0)
	elif food.food_type == "crystal":
		col = Color(1.0, 0.9, 0.2)
	elif food.food_type == "coin":
		col = Color(1.0, 1.0, 0.3)
	burst.set_burst_color(col)
	add_child(burst)
	GameManager.play_sfx(GameManager.SFX_PICKUP, rand_range(0.95, 1.25))

func _update_hud(data: Dictionary) -> void:
	var you = data.get("you", {})
	var score = int(you.get("sc", 0))
	hud.update_stats(score, int(you.get("ln", 1)), float(you.get("tm", 0)), GameManager.total_coins)
	hud.get_node("Control/TopBar/Margin/HBox/TimerLabel").modulate = Color(1, 1, 1)   # the clock shows time survived online
	hud.update_energy(float(you.get("e", 100)), 100.0)
	var gained = score - last_score
	if gained >= 150:
		hud.show_toast("ELIMINATION! +%d" % gained, Color(1.0, 0.5, 0.2))
	elif gained >= 50:
		hud.show_toast("+%d CHAOS CRYSTAL!" % gained, Color(1.0, 0.85, 0.2))
	elif gained >= 25:
		hud.show_toast("+%d ENERGY ORB!" % gained, Color(0.3, 0.95, 1.0))
	last_score = score
	if data.has("lb"):
		_update_board(data["lb"])

func _update_board(rows: Array) -> void:
	for i in range(board_labels.size()):
		var l = board_labels[i]
		if i >= rows.size():
			l.text = ""
			continue
		var id = int(rows[i][0])
		var info = _roster_entry(id)
		var is_bot = int(info.get("b", 0)) == 1
		l.text = "%d. %s%s  %d" % [i + 1, "[BOT] " if is_bot else "", str(info.get("n", "?")), int(rows[i][1])]
		if id == my_id:
			l.add_color_override("font_color", Color(1.0, 0.9, 0.3))
		elif is_bot:
			l.add_color_override("font_color", Color(1.0, 0.55, 0.55))
		else:
			l.add_color_override("font_color", Color(1, 1, 1))

func _on_kill_event(ev: Dictionary) -> void:
	if int(ev.get("k", 0)) == my_id and int(ev.get("v", 0)) != my_id:
		var victim = _roster_entry(int(ev.get("v", 0)))
		hud.show_toast("YOU ELIMINATED " + str(victim.get("n", "A RIVAL")).to_upper() + "!", Color(1.0, 0.5, 0.2))

func _on_status_changed(_status) -> void:
	if status_badge == null:
		return
	status_badge.text = "● " + OnlineClient.status_text()
	var st = OnlineClient.status_text()
	if st == "CONNECTED":
		status_badge.add_color_override("font_color", Color(0.3, 1.0, 0.5))
	elif st == "OFFLINE":
		status_badge.add_color_override("font_color", Color(1.0, 0.35, 0.35))
	else:
		status_badge.add_color_override("font_color", Color(1.0, 0.85, 0.2))
	if st == "RECONNECTING" and hud != null:
		hud.show_toast("CONNECTION LOST - RECONNECTING...", Color(1.0, 0.85, 0.2))

# ------------------------------------------------------------------ end of round / leaving
func _on_died(res: Dictionary) -> void:
	if is_dead:
		return
	is_dead = true
	if local_snake != null and is_instance_valid(local_snake):
		var burst = ParticleBurstScene.instance()
		burst.global_position = local_snake.global_position
		add_child(burst)
		if local_snake.camera != null:
			UISettings.shake(local_snake.camera, 14.0, 0.4)
		local_snake.visible = false
	game_over_menu.display(
		str(res.get("reason", "ELIMINATED")),
		int(res.get("score", 0)),
		int(res.get("len", 1)),
		float(res.get("time", 0)),
		int(res.get("best", 0)),
		int(res.get("len", 1)),
		int(res.get("coins", 0))
	)
	GameManager.play_sfx(GameManager.SFX_GAMEOVER)

func _on_play_again() -> void:
	# PLAY AGAIN: automatically search for another online match
	_open_overlay()
	overlay.start_quick_play()

func _open_overlay() -> void:
	if overlay != null and is_instance_valid(overlay):
		overlay.queue_free()
	overlay = OnlineOverlayScript.new()
	add_child(overlay)
	overlay.connect("match_found", self, "_on_new_match_found")
	overlay.connect("closed", self, "_on_overlay_closed")

func _on_new_match_found(_info) -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_overlay_closed() -> void:
	get_tree().paused = false
	get_tree().change_scene("res://scenes/MainMenu.tscn")

func _on_session_lost(msg: String) -> void:
	if is_dead:
		return
	is_dead = true
	_open_overlay()
	overlay._on_error(msg)

func _on_leave_requested() -> void:
	# the HUD button doubles as LEAVE; tap twice within 2 seconds so it is not triggered by accident
	var now = OS.get_ticks_msec()
	if now < leave_armed_until:
		OnlineClient.leave_match()
		get_tree().change_scene("res://scenes/MainMenu.tscn")
	else:
		leave_armed_until = now + 2000
		hud.show_toast("TAP LEAVE AGAIN TO QUIT THE MATCH", Color(1.0, 0.85, 0.2))
