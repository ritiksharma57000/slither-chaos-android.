extends Control

# Live preview of a snake skin: the snake slithers in place with its real colours.
# Used by the Customize screen. Pure 2D drawing, very light.

var head_color: Color = Color(0.0, 0.95, 0.65)
var body_color: Color = Color(0.0, 0.75, 0.5)
var locked: bool = false
var _t: float = 0.0

func set_skin(skin_id: String, is_locked: bool) -> void:
	var info = GameManager.SKINS_CATALOG.get(skin_id, {})
	head_color = info.get("head_color", head_color)
	body_color = info.get("body_color", body_color)
	locked = is_locked
	update()

func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	_t += delta
	update()

func _path(tt: float, w: float, h: float) -> Vector2:
	return Vector2(w * 0.5 + sin(tt * 0.9) * w * 0.3, h * 0.5 + sin(tt * 1.8) * h * 0.22)

func _draw() -> void:
	var w: float = rect_size.x
	var h: float = rect_size.y
	# arena floor with subtle grid
	draw_rect(Rect2(0, 0, w, h), Color(0.03, 0.05, 0.11, 0.9), true)
	var gx: int = 0
	while gx < int(w):
		draw_line(Vector2(gx, 0), Vector2(gx, h), Color(0.1, 0.5, 0.8, 0.12), 1.0)
		gx += 32
	var gy: int = 0
	while gy < int(h):
		draw_line(Vector2(0, gy), Vector2(w, gy), Color(0.1, 0.5, 0.8, 0.12), 1.0)
		gy += 32
	var seg: int = 16
	var step: float = 0.16
	var tint: float = 0.35 if locked else 1.0
	for i in range(seg - 1, 0, -1):
		var p: Vector2 = _path(_t - float(i) * step, w, h)
		var f: float = float(i) / float(seg)
		var r: float = lerp(17.0, 9.0, f)
		var c: Color = body_color
		if UISettings.glow_enabled and (i % 2) == 0:
			draw_circle(p, r * 1.8, Color(c.r, c.g, c.b, 0.08 * tint))
		draw_circle(p + Vector2(3, 8), r, Color(0, 0, 0, 0.3))
		draw_circle(p, r, Color(c.r * 0.45 * tint, c.g * 0.45 * tint, c.b * 0.45 * tint, 1.0))
		draw_circle(p + Vector2(-r * 0.15, -r * 0.15), r * 0.8, Color(c.r * tint, c.g * tint, c.b * tint, 1.0))
		draw_circle(p + Vector2(-r * 0.35, -r * 0.35), r * 0.25, Color(1, 1, 1, 0.5 * tint))
	var hp: Vector2 = _path(_t, w, h)
	var dir: Vector2 = (_path(_t + 0.05, w, h) - hp).normalized()
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var hc: Color = head_color
	if UISettings.glow_enabled:
		draw_circle(hp, 40.0, Color(hc.r, hc.g, hc.b, 0.12 * tint))
	draw_circle(hp + Vector2(3, 8), 22.0, Color(0, 0, 0, 0.3))
	draw_circle(hp, 22.0, Color(hc.r * 0.45 * tint, hc.g * 0.45 * tint, hc.b * 0.45 * tint, 1.0))
	draw_circle(hp + Vector2(-3, -3), 19.0, Color(hc.r * tint, hc.g * tint, hc.b * tint, 1.0))
	draw_circle(hp + Vector2(-8, -9), 6.0, Color(1, 1, 1, 0.5 * tint))
	for s in [-1.0, 1.0]:
		var e: Vector2 = hp + dir * 8.0 + side * 9.0 * s
		draw_circle(e, 5.5, Color(1, 1, 1, 1))
		draw_circle(e + dir * 1.8, 2.8, Color(0.05, 0.07, 0.15, 1))
	draw_rect(Rect2(0, 0, w, h), Color(0.3, 0.9, 1.0, 0.6), false, 2.0)
