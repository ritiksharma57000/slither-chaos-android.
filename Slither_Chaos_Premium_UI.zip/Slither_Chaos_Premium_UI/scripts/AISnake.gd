extends KinematicBody2D

signal ai_died(ai_ref, drop_positions)

export var snake_name: String = "NeonBot"
export var personality: String = "collector"
export var base_speed: float = 210.0
export var boost_speed: float = 350.0
export var turn_speed: float = 6.5
export var segment_spacing: float = 23.0
export var initial_length: int = 8

onready var head_sprite = $HeadSprite
onready var name_label = $NameLabel
onready var detection_area = $DetectionArea
onready var collection_area = $CollectionArea
onready var head_hurt_area = $HeadHurtArea

const BodySegmentScene = preload("res://scenes/BodySegment.tscn")

var segments_container: Node2D = null
var segments: Array = []
var current_direction: Vector2 = Vector2.RIGHT
var target_direction: Vector2 = Vector2.RIGHT
var is_boosting: bool = false
var is_alive: bool = true

var head_color: Color = Color(1.0, 0.4, 0.2)
var body_color: Color = Color(0.9, 0.2, 0.1)

var decision_timer: float = 0.0
var boost_timer: float = 0.0
var wander_angle: float = 0.0
var arena_bounds: Rect2 = Rect2(80, 80, 7840, 7840)

var nearby_foods: Array = []
var nearby_obstacles: Array = []

func _ready() -> void:
	detection_area.connect("area_entered", self, "_on_detection_area_entered")
	detection_area.connect("area_exited", self, "_on_detection_area_exited")
	collection_area.connect("area_entered", self, "_on_collection_area_entered")
	head_hurt_area.connect("area_entered", self, "_on_head_hit_area")
	
	wander_angle = rand_range(0.0, PI * 2.0)
	current_direction = Vector2(cos(wander_angle), sin(wander_angle))
	target_direction = current_direction
	name_label.text = snake_name

func configure(p_name: String, p_type: String, p_head_col: Color, p_body_col: Color, p_bounds: Rect2) -> void:
	snake_name = p_name
	personality = p_type
	head_color = p_head_col
	body_color = p_body_col
	arena_bounds = p_bounds
	if is_instance_valid(name_label):
		name_label.text = snake_name
	if is_instance_valid(head_sprite):
		head_sprite.modulate = head_color

func initialize_segments(container: Node2D) -> void:
	segments_container = container
	for _i in range(initial_length):
		add_segment()

func add_segment() -> void:
	if not segments_container:
		return
	var seg = BodySegmentScene.instance()
	var spawn_pos = global_position
	if segments.size() > 0:
		var last_seg = segments[segments.size() - 1]
		spawn_pos = last_seg.global_position - current_direction * segment_spacing
	else:
		spawn_pos = global_position - current_direction * segment_spacing
		
	seg.global_position = spawn_pos
	seg.set_owner_snake(self)
	segments_container.add_child(seg)
	segments.append(seg)
	_refresh_segment_visuals()

func _refresh_segment_visuals() -> void:
	var total = segments.size()
	for i in range(total):
		var is_tail = (i == total - 1)
		segments[i].setup_custom_segment(i, total, is_tail, body_color)

func _physics_process(delta: float) -> void:
	if not is_alive:
		return
		
	decision_timer -= delta
	if decision_timer <= 0.0:
		decision_timer = rand_range(0.2, 0.4)
		_think_ai()
		
	if is_boosting:
		boost_timer -= delta
		if boost_timer <= 0.0:
			is_boosting = false
			
	var speed = boost_speed if is_boosting else base_speed
	current_direction = current_direction.linear_interpolate(target_direction, turn_speed * delta).normalized()
	rotation = current_direction.angle()
	
	var collision = move_and_collide(current_direction * speed * delta)
	if collision:
		current_direction = current_direction.slide(collision.normal).normalized()
		target_direction = current_direction
		
	_update_segments(delta)
	_check_arena_bounds()

func _think_ai() -> void:
	var pos = global_position
	
	# 1. High priority: Avoid walls
	var margin = 350.0
	var avoid_vec = Vector2.ZERO
	if pos.x < arena_bounds.position.x + margin:
		avoid_vec.x += 1.0
	elif pos.x > arena_bounds.position.x + arena_bounds.size.x - margin:
		avoid_vec.x -= 1.0
	if pos.y < arena_bounds.position.y + margin:
		avoid_vec.y += 1.0
	elif pos.y > arena_bounds.position.y + arena_bounds.size.y - margin:
		avoid_vec.y -= 1.0
		
	if avoid_vec != Vector2.ZERO:
		target_direction = avoid_vec.normalized()
		return

	# 2. Obstacle evasion (detect other snakes ahead)
	for obs in nearby_obstacles:
		if is_instance_valid(obs):
			var to_obs = obs.global_position - global_position
			if to_obs.length_squared() < 30000.0: # ~170 px
				var dot = current_direction.dot(to_obs.normalized())
				if dot > 0.4:
					var avoid = -to_obs.normalized()
					target_direction = avoid
					return
		
	# 3. Personality steering
	match personality:
		"collector":
			_seek_closest_food()
		"aggressive":
			if randf() < 0.35 and not is_boosting:
				is_boosting = true
				boost_timer = rand_range(0.8, 1.8)
			_seek_closest_food()
		"survivor":
			_seek_closest_food()
		"tricky":
			wander_angle += rand_range(-1.2, 1.2)
			target_direction = Vector2(cos(wander_angle), sin(wander_angle)).normalized()
		_:
			if randf() < 0.4:
				_seek_closest_food()
			else:
				wander_angle += rand_range(-0.5, 0.5)
				target_direction = Vector2(cos(wander_angle), sin(wander_angle)).normalized()

func _seek_closest_food() -> void:
	var closest_pos = Vector2.ZERO
	var min_dist_sq = 9999999.0
	for food in nearby_foods:
		if is_instance_valid(food):
			var d = global_position.distance_squared_to(food.global_position)
			if d < min_dist_sq:
				min_dist_sq = d
				closest_pos = food.global_position
				
	if min_dist_sq < 9000000.0:
		target_direction = (closest_pos - global_position).normalized()
	else:
		wander_angle += rand_range(-0.6, 0.6)
		target_direction = Vector2(cos(wander_angle), sin(wander_angle)).normalized()

func _update_segments(delta: float) -> void:
	var target_pos = global_position
	for i in range(segments.size()):
		var seg = segments[i]
		if not is_instance_valid(seg):
			continue
		var diff = seg.global_position - target_pos
		var dist = diff.length()
		if dist > segment_spacing:
			seg.global_position = target_pos + diff.normalized() * segment_spacing
		var target_angle = (target_pos - seg.global_position).angle()
		seg.rotation = lerp_angle(seg.rotation, target_angle, delta * 16.0)
		target_pos = seg.global_position

func _check_arena_bounds() -> void:
	if not arena_bounds.has_point(global_position):
		die("barrier")

func _on_head_hit_area(area: Area2D) -> void:
	if not is_alive:
		return
		
	# Hit another snake's body -> Instant Death!
	if area.name == "SegmentArea":
		var seg = area.get_parent()
		if seg.has_method("get_owner_snake"):
			var other = seg.get_owner_snake()
			if is_instance_valid(other) and other != self:
				if other.name == "Player":
					GameManager.record_elimination()
				die("CRASHED INTO " + other.name.to_upper())
				return
				
	# Head-to-Head collision
	elif area.name == "HeadHurtArea":
		var other_head = area.get_parent()
		if is_instance_valid(other_head) and other_head != self:
			if segments.size() < other_head.segments.size():
				die("HEAD-ON LOSS")

func _on_detection_area_entered(area: Area2D) -> void:
	if area.has_method("collect") and not nearby_foods.has(area):
		nearby_foods.append(area)
	elif area.name == "SegmentArea":
		var seg = area.get_parent()
		if seg.has_method("get_owner_snake") and seg.get_owner_snake() != self:
			nearby_obstacles.append(seg)

func _on_detection_area_exited(area: Area2D) -> void:
	if nearby_foods.has(area):
		nearby_foods.erase(area)
	elif area.name == "SegmentArea":
		var seg = area.get_parent()
		if nearby_obstacles.has(seg):
			nearby_obstacles.erase(seg)

func _on_collection_area_entered(area: Area2D) -> void:
	if not is_alive:
		return
	if area.has_method("collect"):
		area.collect(self)

func on_food_eaten(_points: int, length_gain: int, _time_bonus: float = 0.0) -> void:
	for _i in range(length_gain):
		add_segment()

func die(reason: String = "") -> void:
	if not is_alive:
		return
	is_alive = false
	var drop_positions = []
	drop_positions.append(global_position)
	var step = max(1, int(segments.size() / 8))
	for i in range(0, segments.size(), step):
		var seg = segments[i]
		if is_instance_valid(seg):
			drop_positions.append(seg.global_position)
	for seg in segments:
		if is_instance_valid(seg):
			seg.queue_free()
	segments.clear()
	emit_signal("ai_died", self, drop_positions)
	queue_free()
