extends CanvasLayer

signal pause_requested()
signal boost_state_changed(is_boosting)

onready var score_label = $Control/TopBar/Margin/HBox/ScoreLabel
onready var length_label = $Control/TopBar/Margin/HBox/LengthLabel
onready var timer_label = $Control/TopBar/Margin/HBox/TimerLabel
onready var coins_label = $Control/TopBar/Margin/HBox/CoinsLabel
onready var pause_button = $Control/TopBar/Margin/HBox/PauseButton
onready var energy_bar = $Control/TopBar/EnergyBar
onready var joystick = $Control/MobileControls/VirtualJoystick
onready var boost_button = $Control/MobileControls/BoostButton
onready var toast_label = $Control/ToastLabel
onready var zone_label = $Control/ZoneLabel
onready var minimap = $Control/Minimap

const BoostRingScript = preload("res://scripts/BoostRing.gd")
var boost_ring = null

func _ready() -> void:
	_apply_neon_style()
	pause_button.connect("pressed", self, "_on_pause_pressed")
	if boost_button:
		boost_button.connect("button_down", self, "_on_boost_down")
		boost_button.connect("button_up", self, "_on_boost_up")
	toast_label.modulate.a = 0.0

func _on_pause_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	emit_signal("pause_requested")

func _on_boost_down() -> void:
	_boost_visual(true)
	emit_signal("boost_state_changed", true)

func _on_boost_up() -> void:
	_boost_visual(false)
	emit_signal("boost_state_changed", false)

func update_stats(score: int, length: int, time_left: float, coins: int) -> void:
	if score_label:
		score_label.text = "SCORE: " + str(score)
	if length_label:
		length_label.text = "LENGTH: " + str(length)
	if coins_label:
		coins_label.text = "COINS: " + str(coins)
	if timer_label:
		var mins = int(time_left) / 60
		var secs = int(time_left) % 60
		timer_label.text = "TIME: %02d:%02d" % [mins, secs]
		if time_left < 15.0:
			timer_label.modulate = Color(1.0, 0.3, 0.3)
		else:
			timer_label.modulate = Color(1.0, 1.0, 1.0)

func update_energy(current: float, max_val: float) -> void:
	if energy_bar:
		energy_bar.value = (current / max_val) * 100.0
	if boost_ring != null:
		boost_ring.set_state(current / max_val, boost_ring.pressed_state)

func set_zone_name(zone_name: String) -> void:
	if zone_label:
		zone_label.text = "SECTOR: " + zone_name

func show_toast(text: String, color: Color = Color(1, 1, 0)) -> void:
	if toast_label:
		toast_label.text = text
		toast_label.modulate = color
		toast_label.modulate.a = 1.0
		var timer = get_tree().create_timer(1.2)
		timer.connect("timeout", self, "_fade_toast")

func _fade_toast() -> void:
	if toast_label:
		toast_label.modulate.a = 0.0

# ---------------------------------------------------------------- neon look (styling only, no gameplay logic)
func _apply_neon_style() -> void:
	var bar = $Control/TopBar
	bar.add_stylebox_override("panel", UISettings.make_box(Color(0.03, 0.05, 0.12, 0.9), Color(0.0, 0.9, 1.0, 0.75), 16, 2, 10, Color(0.0, 0.9, 1.0, 0.2)))
	UISettings.style_label(score_label, 21, Color(1.0, 0.9, 0.3))
	UISettings.style_label(length_label, 21, Color(0.3, 1.0, 0.8))
	UISettings.style_label(coins_label, 21, Color(1.0, 0.85, 0.2))
	UISettings.style_label(timer_label, 26, Color(1.0, 1.0, 1.0))
	score_label.rect_min_size = Vector2(170, 0)
	length_label.rect_min_size = Vector2(140, 0)
	coins_label.rect_min_size = Vector2(130, 0)
	timer_label.rect_min_size = Vector2(150, 0)
	UISettings.style_button(pause_button, Color(1.0, 0.3, 0.8), 18)
	pause_button.rect_min_size = Vector2(110, 38)
	UISettings.style_label(zone_label, 16, Color(0.2, 0.9, 1.0, 0.9), false)
	UISettings.style_label(toast_label, 24, Color(1.0, 1.0, 1.0))
	if boost_button:
		boost_button.rect_pivot_offset = boost_button.rect_size * 0.5
		boost_ring = BoostRingScript.new()
		boost_ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
		boost_button.add_child(boost_ring)
		boost_ring.set_anchors_and_margins_preset(Control.PRESET_WIDE)

func _boost_visual(down: bool) -> void:
	if boost_button == null:
		return
	boost_button.rect_pivot_offset = boost_button.rect_size * 0.5
	if down:
		boost_button.rect_scale = Vector2(0.92, 0.92)
		boost_button.modulate = Color(1.3, 1.15, 0.9, 1.0)
	else:
		boost_button.rect_scale = Vector2(1.0, 1.0)
		boost_button.modulate = Color(1, 1, 1, 1)
	if boost_ring != null:
		boost_ring.set_state(boost_ring.fraction, down)
