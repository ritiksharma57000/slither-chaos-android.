extends Node

# Autoload singleton: UISettings
# - extra settings (volume, graphics quality, particles, glow, screen shake, sensitivity)
#   stored in their OWN file so the existing save file (slither_chaos_save.json) is never touched
# - background music player (uses the existing GameManager.music_enabled flag)
# - fonts and small neon style helpers shared by all menus
# - holds references to resources pre-loaded by the loading screen

const SETTINGS_PATH: String = "user://slither_ui_settings.json"
const FONT_BOLD: String = "res://assets/fonts/Poppins-Bold.ttf"
const FONT_MED: String = "res://assets/fonts/Poppins-Medium.ttf"
const MUSIC_PATH: String = "res://assets/audio/music_loop.wav"
const QUALITY_NAMES: Array = ["LOW", "MEDIUM", "HIGH"]

var master_volume: float = 1.0
var quality: int = 1
var particles_enabled: bool = true
var glow_enabled: bool = true
var shake_enabled: bool = true
var sensitivity: float = 1.0

# resources pre-loaded by Boot.gd are kept alive here
var keep: Array = []

var _fonts: Dictionary = {}
var _fallback_ctrl: Control = null
var _music: AudioStreamPlayer = null
var _shake_cam = null
var _shake_left: float = 0.0
var _shake_total: float = 1.0
var _shake_strength: float = 0.0

func _ready() -> void:
	pause_mode = PAUSE_MODE_PROCESS
	var had_file: bool = load_settings()
	if not had_file:
		quality = 0 if GameManager.low_performance_mode else 1
	else:
		# keep in step with the existing "low performance" flag that the game itself reads
		if GameManager.low_performance_mode and quality != 0:
			quality = 0
		elif (not GameManager.low_performance_mode) and quality == 0:
			quality = 1
	apply_audio()
	apply_music()

# ------------------------------------------------------------------ persistence
func load_settings() -> bool:
	var file = File.new()
	if not file.file_exists(SETTINGS_PATH):
		return false
	if file.open(SETTINGS_PATH, File.READ) != OK:
		return false
	var parsed = parse_json(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return false
	master_volume = clamp(float(parsed.get("master_volume", 1.0)), 0.0, 1.0)
	quality = int(clamp(int(parsed.get("quality", 1)), 0, 2))
	particles_enabled = bool(parsed.get("particles_enabled", true))
	glow_enabled = bool(parsed.get("glow_enabled", true))
	shake_enabled = bool(parsed.get("shake_enabled", true))
	sensitivity = clamp(float(parsed.get("sensitivity", 1.0)), 0.5, 1.5)
	return true

func save_settings() -> void:
	var d = {
		"master_volume": master_volume,
		"quality": quality,
		"particles_enabled": particles_enabled,
		"glow_enabled": glow_enabled,
		"shake_enabled": shake_enabled,
		"sensitivity": sensitivity
	}
	var file = File.new()
	if file.open(SETTINGS_PATH, File.WRITE) == OK:
		file.store_string(to_json(d))
		file.close()

# ------------------------------------------------------------------ setters
func set_volume(v: float) -> void:
	master_volume = clamp(v, 0.0, 1.0)
	apply_audio()
	save_settings()

func set_quality(q: int) -> void:
	quality = int(clamp(q, 0, 2))
	# the existing gameplay code only knows "low performance mode" on/off
	GameManager.low_performance_mode = (quality == 0)
	GameManager.save_game_data()
	save_settings()

func set_particles(on: bool) -> void:
	particles_enabled = on
	save_settings()

func set_glow(on: bool) -> void:
	glow_enabled = on
	save_settings()

func set_shake(on: bool) -> void:
	shake_enabled = on
	save_settings()

func set_sensitivity(v: float) -> void:
	sensitivity = clamp(v, 0.5, 1.5)
	save_settings()

# ------------------------------------------------------------------ audio
func apply_audio() -> void:
	if master_volume <= 0.001:
		AudioServer.set_bus_mute(0, true)
	else:
		AudioServer.set_bus_mute(0, false)
		AudioServer.set_bus_volume_db(0, linear2db(master_volume))

func apply_music() -> void:
	if _music == null:
		var stream = load(MUSIC_PATH)
		if stream == null:
			return
		if stream is AudioStreamSample:
			var bytes_per_frame: int = 2 if stream.format == AudioStreamSample.FORMAT_16_BITS else 1
			if stream.stereo:
				bytes_per_frame *= 2
			stream.loop_mode = AudioStreamSample.LOOP_FORWARD
			stream.loop_begin = 0
			stream.loop_end = int(stream.data.size() / bytes_per_frame)
		_music = AudioStreamPlayer.new()
		_music.stream = stream
		_music.volume_db = -15.0
		_music.pause_mode = PAUSE_MODE_PROCESS
		add_child(_music)
	if GameManager.music_enabled:
		if not _music.playing:
			_music.play()
	else:
		if _music.playing:
			_music.stop()

# ------------------------------------------------------------------ fonts
func font(size: int, bold: bool = true) -> Font:
	var key: String = str(size) + ("b" if bold else "m")
	if _fonts.has(key):
		return _fonts[key]
	var data = load(FONT_BOLD if bold else FONT_MED)
	if data == null:
		return _default_font()
	var f = DynamicFont.new()
	f.font_data = data
	f.size = size
	f.use_filter = true
	_fonts[key] = f
	return f

func glow_font(size: int, outline_px: int, outline_color: Color) -> Font:
	var data = load(FONT_BOLD)
	if data == null:
		return _default_font()
	var f = DynamicFont.new()
	f.font_data = data
	f.size = size
	f.use_filter = true
	if glow_enabled:
		f.outline_size = outline_px
		f.outline_color = outline_color
	return f

func _default_font() -> Font:
	if _fallback_ctrl == null:
		_fallback_ctrl = Control.new()
	return _fallback_ctrl.get_font("font")

# ------------------------------------------------------------------ style helpers
func make_box(bg: Color, border: Color, radius: int, border_w: int = 2, glow_px: int = 0, glow_col: Color = Color(0, 0, 0, 0)) -> StyleBoxFlat:
	var sb = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(border_w)
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	sb.anti_aliasing = true
	if glow_enabled and glow_px > 0:
		sb.shadow_size = glow_px
		sb.shadow_color = glow_col
	return sb

func style_panel(panel: Control, accent: Color, radius: int = 18) -> void:
	panel.add_stylebox_override("panel", make_box(Color(0.04, 0.06, 0.13, 0.94), Color(accent.r, accent.g, accent.b, 0.75), radius, 2, 14, Color(accent.r, accent.g, accent.b, 0.22)))

func style_button(btn: Button, accent: Color, font_size: int = 20) -> void:
	var normal = make_box(Color(0.06, 0.09, 0.18, 0.95), Color(accent.r, accent.g, accent.b, 0.7), 14, 2, 6, Color(accent.r, accent.g, accent.b, 0.18))
	var hover = make_box(Color(accent.r * 0.28, accent.g * 0.28, accent.b * 0.28 + 0.08, 0.98), Color(accent.r, accent.g, accent.b, 1.0), 14, 2, 10, Color(accent.r, accent.g, accent.b, 0.35))
	var pressed = make_box(Color(accent.r * 0.45, accent.g * 0.45, accent.b * 0.45 + 0.05, 1.0), Color(1, 1, 1, 0.9), 14, 2, 4, Color(accent.r, accent.g, accent.b, 0.3))
	var disabled = make_box(Color(0.05, 0.06, 0.1, 0.8), Color(0.3, 0.33, 0.4, 0.5), 14, 1)
	btn.add_stylebox_override("normal", normal)
	btn.add_stylebox_override("hover", hover)
	btn.add_stylebox_override("pressed", pressed)
	btn.add_stylebox_override("disabled", disabled)
	btn.add_stylebox_override("focus", StyleBoxEmpty.new())
	btn.add_font_override("font", font(font_size))
	btn.add_color_override("font_color", Color(0.92, 0.97, 1.0))
	btn.add_color_override("font_color_hover", Color(1, 1, 1))
	btn.add_color_override("font_color_pressed", Color(1, 1, 1))
	btn.add_color_override("font_color_disabled", Color(0.5, 0.55, 0.62))

func style_label(lbl: Label, size: int, color: Color, bold: bool = true) -> void:
	lbl.add_font_override("font", font(size, bold))
	lbl.add_color_override("font_color", color)

# ------------------------------------------------------------------ screen shake (respects the setting)
func shake(camera, strength: float, duration: float) -> void:
	if not shake_enabled or camera == null:
		return
	if not is_instance_valid(camera):
		return
	_shake_cam = camera
	_shake_strength = strength
	_shake_left = duration
	_shake_total = max(duration, 0.01)

func _process(delta: float) -> void:
	if _shake_cam == null:
		return
	if not is_instance_valid(_shake_cam):
		_shake_cam = null
		return
	_shake_left -= delta
	if _shake_left <= 0.0:
		_shake_cam.offset = Vector2.ZERO
		_shake_cam = null
		return
	var k: float = _shake_left / _shake_total
	_shake_cam.offset = Vector2(rand_range(-1.0, 1.0), rand_range(-1.0, 1.0)) * _shake_strength * k
