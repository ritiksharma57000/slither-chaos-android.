extends Control

signal joystick_moved(direction_vector)
signal joystick_released()

onready var base = $Base
onready var knob = $Knob

export var clamp_radius: float = 55.0

var touch_id: int = -1
var is_dragging: bool = false
var output_vector: Vector2 = Vector2.ZERO

func _ready() -> void:
	reset_knob()

func reset_knob() -> void:
	knob.rect_position = base.rect_position + (base.rect_size / 2.0) - (knob.rect_size / 2.0)
	output_vector = Vector2.ZERO

func _gui_input(event: InputEvent) -> void:
	var center = base.rect_position + (base.rect_size / 2.0)
	
	if event is InputEventScreenTouch:
		if event.pressed:
			if touch_id == -1:
				touch_id = event.index
				is_dragging = true
				_handle_input_pos(event.position, center)
		else:
			if event.index == touch_id:
				_release_joystick()
				
	elif event is InputEventScreenDrag:
		if event.index == touch_id:
			_handle_input_pos(event.position, center)
			
	elif event is InputEventMouseButton:
		if event.button_index == BUTTON_LEFT:
			if event.pressed:
				is_dragging = true
				_handle_input_pos(event.position, center)
			else:
				_release_joystick()
				
	elif event is InputEventMouseMotion:
		if is_dragging and touch_id == -1:
			_handle_input_pos(event.position, center)

func _handle_input_pos(pos: Vector2, center: Vector2) -> void:
	var offset = pos - center
	var dist = offset.length()
	if dist > clamp_radius:
		offset = offset.normalized() * clamp_radius
	
	knob.rect_position = center + offset - (knob.rect_size / 2.0)
	output_vector = offset / clamp_radius
	emit_signal("joystick_moved", output_vector)

func _release_joystick() -> void:
	touch_id = -1
	is_dragging = false
	reset_knob()
	emit_signal("joystick_released")
