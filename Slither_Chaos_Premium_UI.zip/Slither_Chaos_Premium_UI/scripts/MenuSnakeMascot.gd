extends Control

var time: float = 0.0
var segment_count: int = 14
var segments: Array = []

func _ready() -> void:
	for _i in range(segment_count):
		segments.append(Vector2(640, 480))

func _process(delta: float) -> void:
	time += delta * 2.2
	
	# Figure-8 3D Path
	var head_target = Vector2(
		640.0 + sin(time) * 360.0,
		460.0 + sin(time * 2.0) * 85.0
	)
	
	segments[0] = segments[0].linear_interpolate(head_target, delta * 14.0)
	for i in range(1, segment_count):
		var prev = segments[i - 1]
		var curr = segments[i]
		var diff = curr - prev
		if diff.length() > 22.0:
			segments[i] = prev + diff.normalized() * 22.0
			
	update()

func _draw() -> void:
	var skin_info = GameManager.SKINS_CATALOG.get(GameManager.equipped_skin_id, {})
	var h_col = skin_info.get("head_color", Color(0.0, 0.95, 0.65))
	var b_col = skin_info.get("body_color", Color(0.0, 0.75, 0.5))
	
	# 1. 3D Drop Shadows
	for i in range(segment_count - 1, -1, -1):
		var pos = segments[i] + Vector2(6, 20)
		var r = lerp(16.0, 10.0, float(i) / float(segment_count))
		draw_circle(pos, r * 1.1, Color(0.0, 0.0, 0.0, 0.35))
		
	# 2. 3D Spherical Segments
	for i in range(segment_count - 1, 0, -1):
		var pos = segments[i]
		var r = lerp(18.0, 11.0, float(i) / float(segment_count))
		_draw_3d_sphere(pos, r, b_col)
		
	# 3. 3D Snake Head
	var head_pos = segments[0]
	_draw_3d_sphere(head_pos, 23.0, h_col)
	
	# 4. Glossy Eyes looking at mouse
	var mouse_dir = (get_global_mouse_position() - head_pos).normalized()
	var eye_l = head_pos + Vector2(-9, -7)
	var eye_r = head_pos + Vector2(9, -7)
	
	draw_circle(eye_l, 6.0, Color(1, 1, 1))
	draw_circle(eye_r, 6.0, Color(1, 1, 1))
	
	draw_circle(eye_l + mouse_dir * 2.5, 3.0, Color(0.08, 0.1, 0.15))
	draw_circle(eye_r + mouse_dir * 2.5, 3.0, Color(0.08, 0.1, 0.15))
	
	draw_circle(eye_l + Vector2(-1, -1), 1.5, Color(1, 1, 1, 0.9))
	draw_circle(eye_r + Vector2(-1, -1), 1.5, Color(1, 1, 1, 0.9))

func _draw_3d_sphere(pos: Vector2, radius: float, base_color: Color) -> void:
	# Shaded base
	draw_circle(pos, radius, base_color.linear_interpolate(Color(0.05, 0.05, 0.1), 0.35))
	# Mid light
	draw_circle(pos + Vector2(-radius * 0.2, -radius * 0.2), radius * 0.8, base_color)
	# Specular highlight
	draw_circle(pos + Vector2(-radius * 0.35, -radius * 0.35), radius * 0.35, Color(1, 1, 1, 0.8))
	draw_circle(pos + Vector2(-radius * 0.38, -radius * 0.38), radius * 0.15, Color(1, 1, 1, 0.95))
