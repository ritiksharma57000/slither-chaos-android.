extends Node2D

var glow_timer: float = 0.0
const ARENA_WIDTH: float = 8000.0
const ARENA_HEIGHT: float = 8000.0

func _process(delta: float) -> void:
	glow_timer += delta * 4.0
	update()

func _draw() -> void:
	var alpha = 0.75 + sin(glow_timer) * 0.25
	var border_color = Color(0.0, 0.95, 1.0, alpha)
	var glow_color = Color(0.0, 0.5, 1.0, alpha * 0.35)
	
	var rect_outer = Rect2(Vector2(20, 20), Vector2(ARENA_WIDTH - 40, ARENA_HEIGHT - 40))
	var rect_inner = Rect2(Vector2(55, 55), Vector2(ARENA_WIDTH - 110, ARENA_HEIGHT - 110))
	
	draw_rect(rect_outer, glow_color, false, 16.0)
	draw_rect(rect_outer, border_color, false, 6.0)
	draw_rect(rect_inner, Color(1.0, 0.2, 0.6, 0.6), false, 2.0)
	
	# 4 Zone Center Divider Lines
	var mid_x = ARENA_WIDTH * 0.5
	var mid_y = ARENA_HEIGHT * 0.5
	draw_line(Vector2(mid_x, 60), Vector2(mid_x, ARENA_HEIGHT - 60), Color(0.2, 0.5, 0.8, 0.25), 3.0)
	draw_line(Vector2(60, mid_y), Vector2(ARENA_WIDTH - 60, mid_y), Color(0.2, 0.5, 0.8, 0.25), 3.0)
	
	# Zone corner beacons
	var corners = [
		Vector2(60, 60),
		Vector2(ARENA_WIDTH - 60, 60),
		Vector2(ARENA_WIDTH - 60, ARENA_HEIGHT - 60),
		Vector2(60, ARENA_HEIGHT - 60)
	]
	for corner in corners:
		draw_circle(corner, 22.0, Color(0.0, 0.9, 1.0, alpha))
		draw_circle(corner, 9.0, Color(1.0, 1.0, 1.0, 0.9))
