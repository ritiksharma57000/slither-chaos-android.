extends CanvasLayer

signal play_again()

onready var menu_root = $Control
onready var reason_label = $Control/CenterContainer/Panel/VBox/ReasonLabel
onready var new_hs_label = $Control/CenterContainer/Panel/VBox/NewHighScoreLabel
onready var stats_label = $Control/CenterContainer/Panel/VBox/StatsLabel
onready var best_stats_label = $Control/CenterContainer/Panel/VBox/BestStatsLabel
onready var btn_play_again = $Control/CenterContainer/Panel/VBox/BtnPlayAgain
onready var btn_main_menu = $Control/CenterContainer/Panel/VBox/BtnMainMenu

func _ready() -> void:
	pause_mode = PAUSE_MODE_PROCESS
	menu_root.visible = false
	_apply_style()
	btn_play_again.connect("pressed", self, "_on_play_again_pressed")
	btn_main_menu.connect("pressed", self, "_on_main_menu_pressed")

func display(reason: String, score: int, length: int, time_survived: float, best_score: int, longest: int, coins: int) -> void:
	get_tree().paused = true
	menu_root.visible = true
	
	if reason_label:
		reason_label.text = reason
		
	var is_new_hs = (score >= best_score and score > 0)
	if new_hs_label:
		new_hs_label.visible = is_new_hs
		
	var mins = int(time_survived) / 60
	var secs = int(time_survived) % 60
	
	if stats_label:
		stats_label.text = "Final Score: %d\nLength Reached: %d\nCoins Earned: +%d\nTime Survived: %02d:%02d" % [score, length, coins, mins, secs]
		
	if best_stats_label:
		best_stats_label.text = "All-Time Best: %d pts  |  Total Coins: %d" % [best_score, GameManager.total_coins]

func _on_play_again_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	menu_root.visible = false
	get_tree().paused = false
	emit_signal("play_again")

func _on_main_menu_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	menu_root.visible = false
	get_tree().paused = false
	get_tree().change_scene("res://scenes/MainMenu.tscn")

func _apply_style() -> void:
	var panel = $Control/CenterContainer/Panel
	UISettings.style_panel(panel, Color(1.0, 0.25, 0.5), 22)
	panel.rect_min_size = Vector2(460, 440)
	UISettings.style_label($Control/CenterContainer/Panel/VBox/Title, 42, Color(1.0, 0.3, 0.5))
	UISettings.style_label(reason_label, 20, Color(1.0, 0.8, 0.3))
	UISettings.style_label(new_hs_label, 24, Color(1.0, 0.9, 0.3))
	UISettings.style_label(stats_label, 20, Color(0.95, 0.97, 1.0), false)
	UISettings.style_label(best_stats_label, 16, Color(0.6, 0.85, 1.0), false)
	UISettings.style_button(btn_play_again, Color(0.2, 1.0, 0.7), 22)
	UISettings.style_button(btn_main_menu, Color(0.7, 0.45, 1.0), 22)
	btn_play_again.rect_min_size = Vector2(0, 52)
	btn_main_menu.rect_min_size = Vector2(0, 52)
