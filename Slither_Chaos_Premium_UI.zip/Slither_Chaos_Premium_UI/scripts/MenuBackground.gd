extends Control

# Lightweight animated neon arena used behind the loading screen and every menu:
# gradient sky, perspective grid with depth, floating food orbs, drifting motes and
# (optionally) a snake mascot swimming behind the interface. 100% procedural 2D.
# Particle counts depend on the graphics quality (LOW / MEDIUM / HIGH).

export var show_mascot: bool = true

var _t: float = 0.0
var _orbs: Array = []        # each: [x(0..1), y(0..1), vx, vy, radius, color_index, depth, phase]
var _motes: Array = []       # each: [x, y, vx, vy, size, depth, phase]
var _parallax: Vector2 = Vector2.ZERO
var _parallax_target: Vector2 = Vector2.ZERO
var _frame: int = 0
var _built_quality: int = -1
var _grid_scroll: float = 0.0

const ORB_COLORS = [
	Color(0.1, 0.9, 1.0), Color(1.0, 0.25, 0.75), Color(0.65, 0.35, 1.0),
	Color(1.0, 0.85, 0.2), Color(0.25, 1.0, 0.55)
]

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_margins_preset(Control.PRESET_WIDE)
	_rebuild()

func _rebuild() -> void:
	_built_quality = UISettings.quality
	var orb_n: int = [8, 16, 26][UISettings.quality]
	var mote_n: int = [18, 40, 70][UISettings.quality]
	_orbs.clear()
	_motes.clear()
	for i in range(orb_n):
		_orbs.append([randf(), randf(), rand_range(-0.012, 0.012), rand_range(-0.03, -0.008), rand_range(5.0, 12.0), randi() % ORB_COLORS.size(), rand_range(0.3, 1.0), rand_range(0.0, 6.28)])
	for i in range(mote_n):
		_motes.append([randf(), randf(), rand_range(-0.01, 0.01), rand_range(-0.02, -0.004), rand_range(1.0, 2.4), rand_range(0.2, 1.0), rand_range(0.0, 6.28)])

func _input(event: InputEvent) -> void:
	# subtle parallax: follows the pointer / finger; never consumes the event
	if event is InputEventMouseMotion or event is InputEventScreenDrag:
		var sz: Vector2 = rect_size
		if sz.x > 1.0 and sz.y > 1.0:
			_parallax_target = ((event.position / sz) - Vector2(0.5, 0.5)) * 2.0

func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	if _built_quality != UISettings.quality:
		_rebuild()
	_t += delta
	_frame += 1
	_grid_scroll = fmod(_grid_scroll + delta * 0.18, 1.0)
	_parallax = _parallax.linear_interpolate(_parallax_target, clamp(delta * 2.5, 0.0, 1.0))
	for o in _orbs:
		o[0] += o[2] * delta
		o[1] += o[3] * delta
		if o[1] < -0.05:
			o[1] = 1.05
			o[0] = randf()
		if o[0] < -0.05:
			o[0] = 1.05
		elif o[0] > 1.05:
			o[0] = -0.05
	for m in _motes:
		m[0] += m[2] * delta
		m[1] += m[3] * delta
		if m[1] < -0.02:
			m[1] = 1.02
			m[0] = randf()
	# LOW quality redraws every other frame to stay light on integrated graphics
	if UISettings.quality == 0 and (_frame % 2) == 1:
		return
	update()

func _draw() -> void:
	var w: float = rect_size.x
	var h: float = rect_size.y
	if w < 2.0 or h < 2.0:
		return
	# 1. background gradient (single polygon, vertex colours)
	draw_polygon(
		PoolVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h), Vector2(0, h)]),
		PoolColorArray([Color(0.01, 0.015, 0.05), Color(0.01, 0.015, 0.05), Color(0.05, 0.03, 0.16), Color(0.05, 0.03, 0.16)])
	)
	var horizon: float = h * 0.52 + _parallax.y * 6.0
	var vx: float = w * 0.5 + _parallax.x * 22.0
	# soft horizon glow
	if UISettings.glow_enabled:
		draw_polygon(
			PoolVector2Array([Vector2(0, horizon - 90), Vector2(w, horizon - 90), Vector2(w, horizon + 6), Vector2(0, horizon + 6)]),
			PoolColorArray([Color(0.4, 0.1, 0.8, 0.0), Color(0.4, 0.1, 0.8, 0.0), Color(0.55, 0.15, 0.9, 0.22), Color(0.55, 0.15, 0.9, 0.22)])
		)
	# 2. perspective grid with depth
	var rays: int = [8, 12, 16][UISettings.quality]
	for i in range(-rays, rays + 1):
		var bx: float = vx + (float(i) / float(rays)) * w * 1.7
		var a: float = 0.28 * (1.0 - abs(float(i)) / float(rays + 2))
		draw_line(Vector2(vx, horizon), Vector2(bx, h), Color(0.1, 0.8, 1.0, a), 1.2)
	var rows: int = [7, 10, 13][UISettings.quality]
	for i in range(rows):
		var f: float = (float(i) + _grid_scroll) / float(rows)
		var depth: float = f * f
		var y: float = horizon + (h - horizon) * depth
		var al: float = 0.1 + 0.4 * depth
		draw_line(Vector2(0, y), Vector2(w, y), Color(0.85, 0.25, 0.95, al), 1.0 + depth * 1.5)
	draw_line(Vector2(0, horizon), Vector2(w, horizon), Color(0.2, 0.95, 1.0, 0.55), 2.0)
	# 3. far motes
	for m in _motes:
		var p: Vector2 = Vector2(m[0] * w, m[1] * h) + _parallax * (-14.0 * m[5])
		var tw: float = 0.35 + 0.35 * sin(_t * 1.3 + m[6])
		draw_circle(p, m[4], Color(0.7, 0.9, 1.0, tw * (0.4 + 0.6 * m[5])))
	# 4. mascot snake swimming behind the interface
	if show_mascot:
		_draw_mascot(w, h)
	# 5. floating food orbs
	for o in _orbs:
		var p2: Vector2 = Vector2(o[0] * w, o[1] * h) + _parallax * (-30.0 * o[6]) + Vector2(0, sin(_t * 1.2 + o[7]) * 5.0)
		var col: Color = ORB_COLORS[o[5]]
		var r: float = o[4] * (0.55 + 0.45 * o[6])
		var br: float = 0.8 + 0.2 * sin(_t * 1.8 + o[7])
		if UISettings.glow_enabled:
			draw_circle(p2, r * 2.6, Color(col.r, col.g, col.b, 0.07 * br))
			draw_circle(p2, r * 1.6, Color(col.r, col.g, col.b, 0.16 * br))
		draw_circle(p2, r, Color(col.r, col.g, col.b, 0.95))
		draw_circle(p2 + Vector2(-r * 0.3, -r * 0.3), r * 0.35, Color(1, 1, 1, 0.8))

func _mascot_pos(tt: float, w: float, h: float) -> Vector2:
	return Vector2(
		w * 0.5 + sin(tt * 0.55) * w * 0.42,
		h * 0.56 + sin(tt * 0.95 + 1.0) * h * 0.2 + sin(tt * 2.1) * 16.0
	)

func _draw_mascot(w: float, h: float) -> void:
	var info = GameManager.SKINS_CATALOG.get(GameManager.equipped_skin_id, {})
	var head_col: Color = info.get("head_color", Color(0.0, 0.95, 0.65))
	var body_col: Color = info.get("body_color", Color(0.0, 0.75, 0.5))
	var seg: int = [14, 20, 26][UISettings.quality]
	var step: float = 0.075
	var off: Vector2 = _parallax * -18.0
	# body: tail first so the head ends up on top
	for i in range(seg - 1, 0, -1):
		var p: Vector2 = _mascot_pos(_t - float(i) * step, w, h) + off
		var f: float = float(i) / float(seg)
		var r: float = lerp(22.0, 7.0, f)
		var c: Color = body_col.linear_interpolate(head_col, 0.25 * (1.0 - f))
		if UISettings.glow_enabled and (i % 2) == 0:
			draw_circle(p, r * 1.9, Color(c.r, c.g, c.b, 0.07))
		draw_circle(p, r, Color(c.r * 0.45, c.g * 0.45, c.b * 0.45, 0.85))
		draw_circle(p + Vector2(-r * 0.15, -r * 0.15), r * 0.8, Color(c.r, c.g, c.b, 0.85))
		draw_circle(p + Vector2(-r * 0.35, -r * 0.35), r * 0.25, Color(1, 1, 1, 0.45))
	var hp: Vector2 = _mascot_pos(_t, w, h) + off
	var hp2: Vector2 = _mascot_pos(_t + 0.05, w, h) + off
	var dir: Vector2 = (hp2 - hp).normalized()
	if UISettings.glow_enabled:
		draw_circle(hp, 46.0, Color(head_col.r, head_col.g, head_col.b, 0.10))
		draw_circle(hp, 34.0, Color(head_col.r, head_col.g, head_col.b, 0.14))
	draw_circle(hp, 26.0, Color(head_col.r * 0.45, head_col.g * 0.45, head_col.b * 0.45, 0.9))
	draw_circle(hp + Vector2(-3, -3), 22.0, Color(head_col.r, head_col.g, head_col.b, 0.92))
	draw_circle(hp + Vector2(-9, -10), 7.0, Color(1, 1, 1, 0.5))
	var side: Vector2 = Vector2(-dir.y, dir.x)
	for s in [-1.0, 1.0]:
		var e: Vector2 = hp + dir * 9.0 + side * 10.0 * s
		draw_circle(e, 6.5, Color(1, 1, 1, 0.95))
		draw_circle(e + dir * 2.0, 3.2, Color(0.05, 0.07, 0.15, 1.0))
