extends Node

# Autoload singleton: GameManager
# Slither Chaos - Complete Upgrade

var current_score: int = 0
var current_length: int = 6
var time_survived: float = 0.0
var coins_collected_this_round: int = 0
var snakes_eliminated_this_round: int = 0
var food_eaten_this_round: int = 0

# Persistent data
var high_score: int = 0
var best_time: float = 0.0
var longest_length: int = 6
var total_coins: int = 50
var total_games_played: int = 0
var total_food_collected: int = 0
var total_snakes_eliminated: int = 0

# Settings
var sound_enabled: bool = true
var music_enabled: bool = true
var low_performance_mode: bool = false
var game_over_reason: String = ""

# Skins System
var equipped_skin_id: String = "neon_viper"
var unlocked_skins: Dictionary = {
	"neon_viper": true,
	"cyber_cyan": false,
	"solar_flare": false,
	"cosmic_purple": false,
	"crimson_phantom": false
}

const SKINS_CATALOG: Dictionary = {
	"neon_viper": {"name": "Neon Viper", "cost": 0, "head_color": Color(0.0, 0.95, 0.65), "body_color": Color(0.0, 0.75, 0.5)},
	"cyber_cyan": {"name": "Cyber Cyan", "cost": 100, "head_color": Color(0.0, 0.85, 1.0), "body_color": Color(0.1, 0.45, 0.95)},
	"solar_flare": {"name": "Solar Flare", "cost": 250, "head_color": Color(1.0, 0.8, 0.1), "body_color": Color(1.0, 0.4, 0.0)},
	"cosmic_purple": {"name": "Cosmic Violet", "cost": 400, "head_color": Color(0.75, 0.2, 1.0), "body_color": Color(0.45, 0.1, 0.8)},
	"crimson_phantom": {"name": "Crimson Phantom", "cost": 600, "head_color": Color(1.0, 0.15, 0.35), "body_color": Color(0.65, 0.05, 0.2)}
}

# Missions System
var missions: Array = [
	{"id": "m1", "title": "Orchard Harvester", "desc": "Eat 60 food orbs or berries", "target": 60, "reward": 80, "stat": "food", "progress": 0, "claimed": false},
	{"id": "m2", "title": "Mega Growth", "desc": "Reach a length of 30 segments", "target": 30, "reward": 120, "stat": "length", "progress": 0, "claimed": false},
	{"id": "m3", "title": "Apex Predator", "desc": "Eliminate 3 rival AI snakes", "target": 3, "reward": 150, "stat": "eliminations", "progress": 0, "claimed": false},
	{"id": "m4", "title": "Survival Master", "desc": "Survive for 120 seconds", "target": 120, "reward": 200, "stat": "time", "progress": 0, "claimed": false}
]

const SAVE_FILE_PATH: String = "user://slither_chaos_save.json"

var SFX_PICKUP: AudioStream = null
var SFX_BOOST: AudioStream = null
var SFX_CLICK: AudioStream = null
var SFX_GAMEOVER: AudioStream = null

func _ready() -> void:
	pause_mode = PAUSE_MODE_PROCESS
	_load_audio_resources()
	load_game_data()

func _load_audio_resources() -> void:
	SFX_PICKUP = load("res://assets/audio/pickup.wav") as AudioStream
	SFX_BOOST = load("res://assets/audio/boost.wav") as AudioStream
	SFX_CLICK = load("res://assets/audio/click.wav") as AudioStream
	SFX_GAMEOVER = load("res://assets/audio/gameover.wav") as AudioStream

func start_new_game() -> void:
	current_score = 0
	current_length = 6
	time_survived = 0.0
	coins_collected_this_round = 0
	snakes_eliminated_this_round = 0
	food_eaten_this_round = 0
	game_over_reason = ""
	total_games_played += 1
	get_tree().paused = false

func add_score(points: int) -> void:
	current_score += points
	if current_score > high_score:
		high_score = current_score

func add_coins(amount: int) -> void:
	coins_collected_this_round += amount
	total_coins += amount

func record_food_eaten() -> void:
	food_eaten_this_round += 1
	total_food_collected += 1
	_update_mission_progress("food", total_food_collected)

func record_elimination() -> void:
	snakes_eliminated_this_round += 1
	total_snakes_eliminated += 1
	add_score(150)
	add_coins(25)
	_update_mission_progress("eliminations", total_snakes_eliminated)

func set_length(new_length: int) -> void:
	current_length = new_length
	if current_length > longest_length:
		longest_length = current_length
	_update_mission_progress("length", longest_length)

func update_survival_time(delta: float) -> void:
	time_survived += delta
	if time_survived > best_time:
		best_time = time_survived
	_update_mission_progress("time", int(time_survived))

func _update_mission_progress(stat_type: String, current_val: int) -> void:
	for m in missions:
		if m["stat"] == stat_type and not m["claimed"]:
			if current_val > m["progress"]:
				m["progress"] = min(current_val, m["target"])

func claim_mission_reward(mission_id: String) -> bool:
	for m in missions:
		if m["id"] == mission_id and not m["claimed"] and m["progress"] >= m["target"]:
			m["claimed"] = true
			total_coins += m["reward"]
			save_game_data()
			return true
	return false

func unlock_skin(skin_id: String) -> bool:
	if SKINS_CATALOG.has(skin_id) and not unlocked_skins.get(skin_id, false):
		var cost = SKINS_CATALOG[skin_id]["cost"]
		if total_coins >= cost:
			total_coins -= cost
			unlocked_skins[skin_id] = true
			equipped_skin_id = skin_id
			save_game_data()
			return true
	return false

func equip_skin(skin_id: String) -> bool:
	if unlocked_skins.get(skin_id, false):
		equipped_skin_id = skin_id
		save_game_data()
		return true
	return false

func trigger_game_over(reason: String) -> void:
	game_over_reason = reason
	if current_score > high_score:
		high_score = current_score
	if time_survived > best_time:
		best_time = time_survived
	if current_length > longest_length:
		longest_length = current_length
	save_game_data()
	play_sfx(SFX_GAMEOVER)

func play_sfx(stream: AudioStream, pitch: float = 1.0) -> void:
	if not sound_enabled or stream == null:
		return
	var player = AudioStreamPlayer.new()
	player.stream = stream
	player.pitch_scale = pitch
	player.bus = "Master"
	player.pause_mode = PAUSE_MODE_PROCESS
	add_child(player)
	player.play()
	player.connect("finished", player, "queue_free")

func toggle_sound() -> bool:
	sound_enabled = not sound_enabled
	save_game_data()
	return sound_enabled

func toggle_music() -> bool:
	music_enabled = not music_enabled
	save_game_data()
	return music_enabled

func toggle_low_performance() -> bool:
	low_performance_mode = not low_performance_mode
	save_game_data()
	return low_performance_mode

func save_game_data() -> void:
	var save_dict = {
		"high_score": high_score,
		"best_time": best_time,
		"longest_length": longest_length,
		"total_coins": total_coins,
		"total_games_played": total_games_played,
		"total_food_collected": total_food_collected,
		"total_snakes_eliminated": total_snakes_eliminated,
		"equipped_skin_id": equipped_skin_id,
		"unlocked_skins": unlocked_skins,
		"sound_enabled": sound_enabled,
		"music_enabled": music_enabled,
		"low_performance_mode": low_performance_mode,
		"missions": missions
	}
	var file = File.new()
	var error = file.open(SAVE_FILE_PATH, File.WRITE)
	if error == OK:
		file.store_string(to_json(save_dict))
		file.close()

func load_game_data() -> void:
	var file = File.new()
	if not file.file_exists(SAVE_FILE_PATH):
		return
	var error = file.open(SAVE_FILE_PATH, File.READ)
	if error == OK:
		var content = file.get_as_text()
		file.close()
		var parsed = parse_json(content)
		if typeof(parsed) == TYPE_DICTIONARY:
			high_score = int(parsed.get("high_score", 0))
			best_time = float(parsed.get("best_time", 0.0))
			longest_length = int(parsed.get("longest_length", 6))
			total_coins = int(parsed.get("total_coins", 50))
			total_games_played = int(parsed.get("total_games_played", 0))
			total_food_collected = int(parsed.get("total_food_collected", 0))
			total_snakes_eliminated = int(parsed.get("total_snakes_eliminated", 0))
			equipped_skin_id = str(parsed.get("equipped_skin_id", "neon_viper"))
			sound_enabled = bool(parsed.get("sound_enabled", true))
			music_enabled = bool(parsed.get("music_enabled", true))
			low_performance_mode = bool(parsed.get("low_performance_mode", false))
			
			var loaded_skins = parsed.get("unlocked_skins", {})
			if typeof(loaded_skins) == TYPE_DICTIONARY:
				for k in loaded_skins.keys():
					unlocked_skins[k] = bool(loaded_skins[k])
					
			var loaded_missions = parsed.get("missions", [])
			if typeof(loaded_missions) == TYPE_ARRAY and loaded_missions.size() == missions.size():
				for i in range(missions.size()):
					missions[i]["progress"] = int(loaded_missions[i].get("progress", 0))
					missions[i]["claimed"] = bool(loaded_missions[i].get("claimed", false))
