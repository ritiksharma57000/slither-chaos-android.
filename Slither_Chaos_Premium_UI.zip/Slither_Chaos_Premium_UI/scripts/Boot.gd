extends Control

# Cinematic loading screen shown once when the game starts.
#
# TRUTHFUL PROGRESS: the percentage is the real share of work finished. Every game scene, texture,
# sound and font is loaded with ResourceLoader.load_interactive() (stage by stage) and kept in
# memory (UISettings.keep). When the last resource is ready the screen shows READY and moves on
# immediately (short fade). Nothing is faked: if loading is quick, this screen is quick.
# A watchdog guarantees the player is never stuck here.

const MenuBackgroundScript = preload("res://scripts/MenuBackground.gd")
const NEXT_SCENE: String = "res://scenes/MainMenu.tscn"
const WATCHDOG_SECONDS: float = 25.0

const ASSETS: Array = [
	"res://assets/fonts/Poppins-Bold.ttf",
	"res://assets/fonts/Poppins-Medium.ttf",
	"res://assets/audio/click.wav",
	"res://assets/audio/pickup.wav",
	"res://assets/audio/boost.wav",
	"res://assets/audio/gameover.wav",
	"res://assets/audio/music_loop.wav",
	"res://assets/textures/head.png",
	"res://assets/textures/body_segment.png",
	"res://assets/textures/tail.png",
	"res://assets/textures/food_berry.png",
	"res://assets/textures/food_crystal.png",
	"res://assets/textures/food_orb.png",
	"res://assets/textures/particle_spark.png",
	"res://assets/textures/bg_tile.png",
	"res://assets/textures/decor_flower.png",
	"res://assets/textures/decor_mushroom.png",
	"res://assets/textures/decor_rock.png",
	"res://assets/textures/decor_grass.png",
	"res://assets/textures/joystick_base.png",
	"res://assets/textures/joystick_knob.png",
	"res://assets/textures/btn_boost.png",
	"res://scenes/BodySegment.tscn",
	"res://scenes/Food.tscn",
	"res://scenes/ParticleBurst.tscn",
	"res://scenes/VirtualJoystick.tscn",
	"res://scenes/HUD.tscn",
	"res://scenes/PauseMenu.tscn",
	"res://scenes/GameOverMenu.tscn",
	"res://scenes/Player.tscn",
	"res://scenes/AISnake.tscn",
	"res://scenes/MainGame.tscn",
	"res://scenes/OnlineGame.tscn",
	"res://scenes/MainMenu.tscn"
]

const TIPS: Array = [
	"Cut across a rival so its head strikes your body.",
	"Never touch another snake's body with your head.",
	"Hold boost to surge ahead. It drains your energy bar.",
	"Chaos crystals are worth the most points.",
	"Stay away from the map edge. The electric barrier ends your run.",
	"Eating food adds time to your survival clock.",
	"Complete missions to earn coins for new skins.",
	"Online Quick Play finds a match for you. No room codes needed."
]

enum Phase { INIT, ASSETS, READY, LEAVING }

var _phase: int = Phase.INIT
var _t: float = 0.0
var _queue: Array = []
var _total_steps: int = 1
var _done_steps: int = 0
var _loader = null
var _current_path: String = ""
var _current_frac: float = 0.0
var _failed: Array = []
var _real: float = 0.0
var _shown: float = 0.0
var _status: String = "INITIALIZING"
var _detail: String = ""
var _ready_time: float = 0.0
var _fade: float = 1.0          # 1 = black, 0 = visible
var _leaving: bool = false
var _tip_index: int = 0
var _tip_time: float = 0.0
var _bg = null

# sparks following the snake (fixed pool, reused)
const SPARK_COUNT: int = 36
var _spark_pos: Array = []
var _spark_vel: Array = []
var _spark_life: Array = []
var _spark_next: int = 0

func _ready() -> void:
	set_anchors_and_margins_preset(Control.PRESET_WIDE)
	_bg = MenuBackgroundScript.new()
	_bg.show_mascot = false
	_bg.show_behind_parent = true   # background is drawn BEHIND this node's own drawing (logo, bar)
	add_child(_bg)
	# last-resort guard that does not depend on _process: never leave the player stuck here
	get_tree().create_timer(WATCHDOG_SECONDS + 5.0).connect("timeout", self, "_force_exit")
	for i in range(SPARK_COUNT):
		_spark_pos.append(Vector2.ZERO)
		_spark_vel.append(Vector2.ZERO)
		_spark_life.append(0.0)
	for p in ASSETS:
		if ResourceLoader.exists(p):
			_queue.append(p)
		else:
			_failed.append(p)
	_total_steps = 1 + _queue.size()
	_tip_index = randi() % TIPS.size()

func _process(delta: float) -> void:
	_t += delta
	_tip_time += delta
	if _tip_time > 3.4:
		_tip_time = 0.0
		_tip_index = (_tip_index + 1) % TIPS.size()
	_step_loading()
	# smooth bar: follows the real value but never runs ahead of it
	_shown = min(_real, lerp(_shown, _real, clamp(delta * 8.0, 0.0, 1.0)))
	if _real >= 0.999 and _shown > 0.995:
		_shown = 1.0
	# fade in at start, fade out when leaving
	if _phase == Phase.LEAVING:
		_fade = min(1.0, _fade + delta / 0.4)
		if _fade >= 1.0 and not _leaving:
			_leaving = true
			_go_next()
	else:
		_fade = max(0.0, _fade - delta / 0.5)
	_update_sparks(delta)
	if _t > WATCHDOG_SECONDS and _phase < Phase.READY:
		push_warning("Boot: loading watchdog fired, continuing to the menu")
		_enter_ready()
	update()

func _step_loading() -> void:
	if _phase == Phase.INIT:
		# step 1: saved data + settings were loaded by the GameManager / UISettings autoloads
		_done_steps = 1
		_real = float(_done_steps) / float(_total_steps)
		_status = "LOADING ASSETS"
		_phase = Phase.ASSETS
		return
	if _phase == Phase.ASSETS:
		var stop_at: int = OS.get_ticks_msec() + 10
		while OS.get_ticks_msec() < stop_at:
			if _loader == null:
				if _queue.empty():
					_enter_ready()
					return
				_current_path = _queue.pop_front()
				_detail = _current_path.get_file()
				_loader = ResourceLoader.load_interactive(_current_path)
				_current_frac = 0.0
				if _loader == null:
					_failed.append(_current_path)
					_done_steps += 1
					continue
			var err: int = _loader.poll()
			if err == ERR_FILE_EOF:
				var res = _loader.get_resource()
				if res != null:
					UISettings.keep.append(res)
				_loader = null
				_done_steps += 1
			elif err != OK:
				_failed.append(_current_path)
				push_warning("Boot: could not load " + _current_path)
				_loader = null
				_done_steps += 1
			else:
				var stages: int = _loader.get_stage_count()
				if stages > 0:
					_current_frac = float(_loader.get_stage()) / float(stages)
		var partial: float = _current_frac if _loader != null else 0.0
		_real = clamp((float(_done_steps) + partial) / float(_total_steps), 0.0, 1.0)
	elif _phase == Phase.READY:
		_ready_time += get_process_delta_time()
		if _ready_time > 0.45:
			_phase = Phase.LEAVING

func _enter_ready() -> void:
	_real = 1.0
	_status = "READY"
	_detail = ""
	_loader = null
	_phase = Phase.READY
	_ready_time = 0.0
	if _failed.size() > 0:
		push_warning("Boot: " + str(_failed.size()) + " resource(s) were missing or failed to load")

func _force_exit() -> void:
	if not _leaving:
		_leaving = true
		push_warning("Boot: forced exit to the menu")
		_go_next()

func _go_next() -> void:
	var err: int = get_tree().change_scene(NEXT_SCENE)
	if err != OK:
		push_error("Boot: could not open " + NEXT_SCENE)

func _head_pos(angle: float, c: Vector2) -> Vector2:
	return c + Vector2(0.0, 22.0) + Vector2(cos(angle) * 490.0, sin(angle) * 140.0)

func _update_sparks(delta: float) -> void:
	var sz: Vector2 = rect_size
	var c: Vector2 = Vector2(sz.x * 0.5, sz.y * 0.36)
	var hp: Vector2 = _head_pos(_t * 1.15, c)
	var per: int = [1, 1, 2][UISettings.quality]
	if UISettings.particles_enabled:
		for k in range(per):
			var i: int = _spark_next
			_spark_next = (_spark_next + 1) % SPARK_COUNT
			_spark_pos[i] = hp
			_spark_vel[i] = Vector2(rand_range(-40.0, 40.0), rand_range(-60.0, 20.0))
			_spark_life[i] = rand_range(0.5, 0.9)
	for i in range(SPARK_COUNT):
		if _spark_life[i] > 0.0:
			_spark_life[i] -= delta
			_spark_pos[i] += _spark_vel[i] * delta

func _draw() -> void:
	var w: float = rect_size.x
	var h: float = rect_size.y
	var c: Vector2 = Vector2(w * 0.5, h * 0.36)
	var head_font: Font = UISettings.font(104)
	var pulse: float = 0.5 + 0.5 * sin(_t * 1.6)
	# --- logo with soft glow
	var f1: Font = head_font
	var s1: String = "SLITHER"
	var s2: String = "CHAOS"
	var w1: float = f1.get_string_size(s1).x
	var w2: float = f1.get_string_size(s2).x
	var gap: float = 30.0
	var total: float = w1 + w2 + gap
	var x0: float = c.x - total * 0.5
	var base_y: float = c.y + 36.0
	if UISettings.glow_enabled:
		for k in range(8):
			var a: float = float(k) * TAU / 8.0
			var o: Vector2 = Vector2(cos(a), sin(a)) * (5.0 + 2.0 * pulse)
			draw_string(f1, Vector2(x0, base_y) + o, s1, Color(0.0, 0.9, 1.0, 0.09))
			draw_string(f1, Vector2(x0 + w1 + gap, base_y) + o, s2, Color(1.0, 0.2, 0.8, 0.09))
	draw_string(f1, Vector2(x0, base_y), s1, Color(0.55, 1.0, 1.0, 1.0))
	draw_string(f1, Vector2(x0 + w1 + gap, base_y), s2, Color(1.0, 0.5, 0.95, 1.0))
	var sub: String = "NEON ARCADE SURVIVAL"
	var sf: Font = UISettings.font(24, false)
	var sw: float = sf.get_string_size(sub).x
	draw_string(sf, Vector2(c.x - sw * 0.5, base_y + 50.0), sub, Color(0.75, 0.6, 1.0, 0.9))
	# --- neon snake circling the logo
	_draw_orbit_snake(c)
	# --- sparks
	for i in range(SPARK_COUNT):
		var life: float = _spark_life[i]
		if life > 0.0:
			var al: float = clamp(life * 1.6, 0.0, 1.0)
			draw_circle(_spark_pos[i], 2.0 + 1.5 * al, Color(0.6, 1.0, 1.0, al * 0.9))
	# --- loading interface
	var bar_w: float = min(680.0, w * 0.7)
	var bar_h: float = 16.0
	var bx: float = c.x - bar_w * 0.5
	var by: float = h * 0.74
	var stf: Font = UISettings.font(20)
	# status text + spinner
	draw_string(stf, Vector2(bx + 34.0, by - 16.0), _status, Color(0.7, 0.95, 1.0, 1.0))
	_draw_spinner(Vector2(bx + 12.0, by - 23.0), 10.0)
	var pct: String = str(int(round(_shown * 100.0))) + "%"
	var pw: float = stf.get_string_size(pct).x
	draw_string(stf, Vector2(bx + bar_w - pw, by - 16.0), pct, Color(1.0, 0.85, 1.0, 1.0))
	# bar frame
	draw_rect(Rect2(bx - 3.0, by - 3.0, bar_w + 6.0, bar_h + 6.0), Color(0.05, 0.08, 0.18, 0.95), true)
	draw_rect(Rect2(bx - 3.0, by - 3.0, bar_w + 6.0, bar_h + 6.0), Color(0.3, 0.8, 1.0, 0.7), false, 2.0)
	var fw: float = bar_w * _shown
	if fw > 1.0:
		draw_polygon(
			PoolVector2Array([Vector2(bx, by), Vector2(bx + fw, by), Vector2(bx + fw, by + bar_h), Vector2(bx, by + bar_h)]),
			PoolColorArray([Color(0.0, 0.9, 1.0), Color(1.0, 0.2, 0.85), Color(1.0, 0.2, 0.85), Color(0.0, 0.9, 1.0)])
		)
		draw_rect(Rect2(bx, by, fw, bar_h * 0.4), Color(1, 1, 1, 0.18), true)
		if UISettings.glow_enabled:
			draw_circle(Vector2(bx + fw, by + bar_h * 0.5), 12.0, Color(1.0, 0.5, 1.0, 0.18))
	# detail (current file) - truthful
	if _detail != "":
		var df: Font = UISettings.font(15, false)
		draw_string(df, Vector2(bx, by + bar_h + 26.0), _detail, Color(0.5, 0.65, 0.85, 0.8))
	# rotating tip (cross-fade)
	var tf: Font = UISettings.font(20, false)
	var tip: String = "TIP: " + TIPS[_tip_index]
	var ta: float = 1.0
	if _tip_time < 0.5:
		ta = _tip_time / 0.5
	elif _tip_time > 2.9:
		ta = clamp((3.4 - _tip_time) / 0.5, 0.0, 1.0)
	var tw: float = tf.get_string_size(tip).x
	draw_string(tf, Vector2(c.x - tw * 0.5, h * 0.9), tip, Color(0.85, 0.9, 1.0, 0.85 * ta))
	# --- fade to / from black
	if _fade > 0.001:
		draw_rect(Rect2(0, 0, w, h), Color(0.0, 0.0, 0.02, _fade), true)

func _draw_orbit_snake(c: Vector2) -> void:
	var segs: int = [22, 30, 38][UISettings.quality]
	var angle: float = _t * 1.15
	for i in range(segs - 1, -1, -1):
		var a: float = angle - float(i) * 0.062
		var p: Vector2 = _head_pos(a, c)
		var f: float = float(i) / float(segs)
		var r: float = lerp(13.0, 4.5, f)
		var col: Color = Color(0.0, 0.95, 1.0).linear_interpolate(Color(0.7, 0.3, 1.0), clamp(f * 2.0, 0.0, 1.0))
		col = col.linear_interpolate(Color(1.0, 0.2, 0.8), clamp(f * 2.0 - 1.0, 0.0, 1.0))
		if UISettings.glow_enabled and (i % 2) == 0:
			draw_circle(p, r * 2.2, Color(col.r, col.g, col.b, 0.1))
		draw_circle(p, r, Color(col.r, col.g, col.b, 0.95))
		if i < 6:
			draw_circle(p + Vector2(-r * 0.3, -r * 0.3), r * 0.3, Color(1, 1, 1, 0.6))
	var hp: Vector2 = _head_pos(angle, c)
	var nx: Vector2 = _head_pos(angle + 0.05, c)
	var dir: Vector2 = (nx - hp).normalized()
	var side: Vector2 = Vector2(-dir.y, dir.x)
	for s in [-1.0, 1.0]:
		var e: Vector2 = hp + dir * 5.0 + side * 6.0 * s
		draw_circle(e, 4.0, Color(1, 1, 1, 1))
		draw_circle(e + dir * 1.2, 2.0, Color(0.05, 0.07, 0.15, 1))

func _draw_spinner(c: Vector2, r: float) -> void:
	if _phase >= Phase.READY:
		draw_circle(c, r * 0.55, Color(0.3, 1.0, 0.6, 1.0))
		return
	draw_arc(c, r, 0.0, TAU, 20, Color(0.0, 0.9, 1.0, 0.2), 3.0)
	draw_arc(c, r, _t * 5.0, _t * 5.0 + 2.0, 12, Color(0.0, 0.95, 1.0, 1.0), 3.0)
