extends KinematicBody2D

signal food_eaten(points, length_gain, time_bonus)
signal died(reason)
signal energy_changed(current_energy, max_energy)

export var base_speed: float = 230.0
export var boost_speed: float = 400.0
export var turn_speed: float = 8.5
export var segment_spacing: float = 24.0
export var initial_length: int = 6

export var max_energy: float = 100.0
var current_energy: float = 100.0
var boost_cost_per_sec: float = 32.0
var recharge_rate_per_sec: float = 22.0

onready var head_sprite = $HeadSprite
onready var camera = $Camera2D
onready var boost_particles = $BoostParticles
onready var collection_area = $CollectionArea
onready var head_hurt_area = $HeadHurtArea

const BodySegmentScene = preload("res://scenes/BodySegment.tscn")
const ParticleBurstScene = preload("res://scenes/ParticleBurst.tscn")

var segments_container: Node2D = null
var segments: Array = []
var current_direction: Vector2 = Vector2.RIGHT
var target_direction: Vector2 = Vector2.RIGHT
var is_boosting: bool = false
var is_alive: bool = true
var boost_sfx_timer: float = 0.0

var joystick_direction: Vector2 = Vector2.ZERO
var touch_boosting: bool = false

func _ready() -> void:
	collection_area.connect("area_entered", self, "_on_collection_area_entered")
	head_hurt_area.connect("area_entered", self, "_on_head_hit_area")
	boost_particles.emitting = false
	apply_skin_colors()

func apply_skin_colors() -> void:
	var skin_info = GameManager.SKINS_CATALOG.get(GameManager.equipped_skin_id, {})
	var h_col = skin_info.get("head_color", Color(0.0, 0.95, 0.65))
	if is_instance_valid(head_sprite):
		head_sprite.modulate = h_col

func initialize_segments(container: Node2D) -> void:
	segments_container = container
	for _i in range(initial_length):
		add_segment()

func add_segment() -> void:
	if not segments_container:
		return
	var seg = BodySegmentScene.instance()
	var spawn_pos = global_position
	if segments.size() > 0:
		var last_seg = segments[segments.size() - 1]
		spawn_pos = last_seg.global_position - current_direction * segment_spacing
	else:
		spawn_pos = global_position - current_direction * segment_spacing
		
	seg.global_position = spawn_pos
	seg.set_owner_snake(self)
	segments_container.add_child(seg)
	segments.append(seg)
	_refresh_segment_visuals()
	GameManager.set_length(segments.size() + 1)

func _refresh_segment_visuals() -> void:
	var total = segments.size()
	for i in range(total):
		var is_tail = (i == total - 1)
		segments[i].setup_segment(i, total, is_tail)

func _process(delta: float) -> void:
	if not is_alive:
		return
	_handle_input()
	_update_energy_and_boost(delta)

func _physics_process(delta: float) -> void:
	if not is_alive:
		return
	
	if target_direction.length_squared() > 0.01:
		current_direction = current_direction.linear_interpolate(target_direction, clamp(turn_speed * UISettings.sensitivity * delta, 0.0, 1.0)).normalized()
	
	rotation = current_direction.angle()
	var speed = boost_speed if (is_boosting and current_energy > 0) else base_speed
	var velocity = current_direction * speed
	
	var collision = move_and_collide(velocity * delta)
	if collision:
		current_direction = current_direction.slide(collision.normal).normalized()
		target_direction = current_direction
	
	_update_segments(delta)

func _handle_input() -> void:
	if joystick_direction.length_squared() > 0.04:
		target_direction = joystick_direction.normalized()
	else:
		var kx = 0.0
		var ky = 0.0
		if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
			kx += 1.0
		if Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A):
			kx -= 1.0
		if Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S):
			ky += 1.0
		if Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W):
			ky -= 1.0
			
		var key_dir = Vector2(kx, ky)
		if key_dir.length_squared() > 0.01:
			target_direction = key_dir.normalized()
		elif Input.is_mouse_button_pressed(BUTTON_LEFT):
			var mouse_pos = get_global_mouse_position()
			var to_mouse = mouse_pos - global_position
			if to_mouse.length_squared() > 400.0:
				target_direction = to_mouse.normalized()
	
	var key_boost = Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_SHIFT) or Input.is_mouse_button_pressed(BUTTON_RIGHT)
	is_boosting = (touch_boosting or key_boost) and current_energy > 5.0

func _update_energy_and_boost(delta: float) -> void:
	if is_boosting and current_energy > 0.0:
		current_energy = max(0.0, current_energy - boost_cost_per_sec * delta)
		boost_particles.emitting = UISettings.particles_enabled
		boost_sfx_timer -= delta
		if boost_sfx_timer <= 0.0:
			GameManager.play_sfx(GameManager.SFX_BOOST, rand_range(1.1, 1.3))
			boost_sfx_timer = 0.35
		camera.zoom = camera.zoom.linear_interpolate(Vector2(1.35, 1.35), delta * 4.0)
	else:
		current_energy = min(max_energy, current_energy + recharge_rate_per_sec * delta)
		boost_particles.emitting = false
		boost_sfx_timer = 0.0
		camera.zoom = camera.zoom.linear_interpolate(Vector2(1.18, 1.18), delta * 4.0)
		
	emit_signal("energy_changed", current_energy, max_energy)

func _update_segments(delta: float) -> void:
	var target_pos = global_position
	for i in range(segments.size()):
		var seg = segments[i]
		if not is_instance_valid(seg):
			continue
		var diff = seg.global_position - target_pos
		var dist = diff.length()
		if dist > segment_spacing:
			seg.global_position = target_pos + diff.normalized() * segment_spacing
		var target_angle = (target_pos - seg.global_position).angle()
		seg.rotation = lerp_angle(seg.rotation, target_angle, delta * 18.0)
		target_pos = seg.global_position

func _on_head_hit_area(area: Area2D) -> void:
	if not is_alive:
		return
		
	# 1. Hitting another snake's body segment -> Instant Death!
	if area.name == "SegmentArea":
		var seg = area.get_parent()
		if seg.has_method("get_owner_snake"):
			var other_snake = seg.get_owner_snake()
			if is_instance_valid(other_snake) and other_snake != self:
				var rival_name = other_snake.snake_name if "snake_name" in other_snake else "RIVAL"
				die("CRASHED INTO " + rival_name.to_upper() + "'S BODY!")
				return
				
	# 2. Head-to-Head collision
	elif area.name == "HeadHurtArea":
		var other_head_snake = area.get_parent()
		if is_instance_valid(other_head_snake) and other_head_snake != self:
			if segments.size() < other_head_snake.segments.size():
				die("HEAD-ON COLLISION WITH LARGER RIVAL!")
			elif segments.size() == other_head_snake.segments.size():
				die("MUTUAL HEAD-ON ELIMINATION!")

func _on_collection_area_entered(area: Area2D) -> void:
	if not is_alive:
		return
	if area.has_method("collect"):
		area.collect(self)

func on_food_eaten(points: int, length_gain: int, time_bonus: float) -> void:
	for _i in range(length_gain):
		add_segment()
	GameManager.record_food_eaten()
	emit_signal("food_eaten", points, length_gain, time_bonus)

func set_joystick_vector(vec: Vector2) -> void:
	joystick_direction = vec

func set_touch_boosting(state: bool) -> void:
	touch_boosting = state

func die(reason: String) -> void:
	if not is_alive:
		return
	is_alive = false
	boost_particles.emitting = false
	UISettings.shake(camera, 14.0, 0.4)
	var burst = ParticleBurstScene.instance()
	burst.global_position = global_position
	get_parent().add_child(burst)
	head_sprite.visible = false
	emit_signal("died", reason)
