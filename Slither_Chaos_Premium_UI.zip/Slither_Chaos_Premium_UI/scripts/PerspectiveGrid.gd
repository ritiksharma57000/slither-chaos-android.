extends Control

var scroll_offset: float = 0.0
export var grid_speed: float = 75.0
export var horizon_y: float = 270.0
export var vanishing_point_x: float = 640.0

func _process(delta: float) -> void:
	scroll_offset = fmod(scroll_offset + delta * grid_speed, 48.0)
	update()

func _draw() -> void:
	var w = rect_size.x
	var h = rect_size.y
	
	# 1. Deep Space Sky
	draw_rect(Rect2(0, 0, w, horizon_y), Color(0.04, 0.03, 0.09, 1.0), true)
	
	# 2. Glowing Synthwave Sun
	var sun_pos = Vector2(vanishing_point_x, horizon_y - 20)
	draw_circle(sun_pos, 100.0, Color(1.0, 0.1, 0.5, 0.2))
	draw_circle(sun_pos, 75.0, Color(1.0, 0.2, 0.6, 0.55))
	draw_circle(sun_pos, 55.0, Color(1.0, 0.6, 0.1, 0.85))
	draw_circle(sun_pos, 35.0, Color(1.0, 0.9, 0.3, 0.95))
	
	# Sun scanlines
	for sy in range(int(horizon_y - 65), int(horizon_y - 8), 8):
		draw_line(Vector2(vanishing_point_x - 75, sy), Vector2(vanishing_point_x + 75, sy), Color(0.04, 0.03, 0.09, 0.85), 2.5)

	# 3. Ground Plane
	draw_rect(Rect2(0, horizon_y, w, h - horizon_y), Color(0.02, 0.03, 0.08, 1.0), true)
	
	# 4. 3D Radiating Perspective Lines
	var spread_x = 2400.0
	for i in range(-16, 17):
		var bottom_x = vanishing_point_x + (float(i) / 16.0) * spread_x
		draw_line(Vector2(vanishing_point_x, horizon_y), Vector2(bottom_x, h), Color(0.0, 0.85, 1.0, 0.35), 1.5)
		
	# 5. Forward-scrolling 3D horizontal lines
	var num_h_lines = 14
	for i in range(num_h_lines):
		var t = float(i) / float(num_h_lines)
		var persp = pow((t + scroll_offset / 48.0 / float(num_h_lines)), 2.6)
		if persp > 1.0:
			persp = fmod(persp, 1.0)
		var line_y = lerp(horizon_y, h, persp)
		var alpha = clamp((line_y - horizon_y) / (h - horizon_y), 0.0, 1.0) * 0.75
		draw_line(Vector2(0, line_y), Vector2(w, line_y), Color(1.0, 0.15, 0.6, alpha), 1.5 + alpha * 1.5)
		
	# 6. Glowing Horizon Beams
	draw_line(Vector2(0, horizon_y), Vector2(w, horizon_y), Color(0.0, 1.0, 0.8, 0.9), 3.0)
	draw_line(Vector2(0, horizon_y), Vector2(w, horizon_y), Color(1.0, 0.2, 0.8, 0.35), 7.0)
