extends CanvasLayer

signal resumed()
signal restarted()

onready var menu_root = $Control
onready var btn_resume = $Control/CenterContainer/Panel/VBox/BtnResume
onready var btn_restart = $Control/CenterContainer/Panel/VBox/BtnRestart
onready var btn_sound = $Control/CenterContainer/Panel/VBox/BtnSound
onready var btn_home = $Control/CenterContainer/Panel/VBox/BtnHome

var _tween: Tween = null

func _ready() -> void:
	pause_mode = PAUSE_MODE_PROCESS
	menu_root.visible = false
	_tween = Tween.new()
	_tween.pause_mode = PAUSE_MODE_PROCESS
	add_child(_tween)
	_apply_style()
	btn_resume.connect("pressed", self, "_on_resume_pressed")
	btn_restart.connect("pressed", self, "_on_restart_pressed")
	btn_sound.connect("pressed", self, "_on_sound_pressed")
	btn_home.connect("pressed", self, "_on_home_pressed")
	_update_sound_button_label()

func open() -> void:
	get_tree().paused = true
	menu_root.visible = true
	menu_root.modulate = Color(1, 1, 1, 0.0)
	_tween.interpolate_property(menu_root, "modulate", Color(1, 1, 1, 0.0), Color(1, 1, 1, 1.0), 0.18, Tween.TRANS_QUAD, Tween.EASE_OUT)
	_tween.start()
	_update_sound_button_label()

func close() -> void:
	menu_root.modulate = Color(1, 1, 1, 1)
	menu_root.visible = false
	get_tree().paused = false
	emit_signal("resumed")

func _on_resume_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	close()

func _on_restart_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	menu_root.visible = false
	get_tree().paused = false
	emit_signal("restarted")

func _on_sound_pressed() -> void:
	var state = GameManager.toggle_sound()
	_update_sound_button_label()
	if state:
		GameManager.play_sfx(GameManager.SFX_CLICK)

func _update_sound_button_label() -> void:
	if btn_sound:
		btn_sound.text = "SOUND: " + ("ON" if GameManager.sound_enabled else "OFF")

func _on_home_pressed() -> void:
	GameManager.play_sfx(GameManager.SFX_CLICK)
	menu_root.visible = false
	get_tree().paused = false
	get_tree().change_scene("res://scenes/MainMenu.tscn")

func _apply_style() -> void:
	var panel = $Control/CenterContainer/Panel
	UISettings.style_panel(panel, Color(0.0, 0.9, 1.0), 22)
	panel.rect_min_size = Vector2(400, 350)
	UISettings.style_label($Control/CenterContainer/Panel/VBox/Title, 36, Color(0.5, 1.0, 1.0))
	UISettings.style_button(btn_resume, Color(0.2, 1.0, 0.7), 22)
	UISettings.style_button(btn_restart, Color(1.0, 0.8, 0.3), 22)
	UISettings.style_button(btn_sound, Color(0.7, 0.45, 1.0), 22)
	UISettings.style_button(btn_home, Color(1.0, 0.3, 0.6), 22)
	for b in [btn_resume, btn_restart, btn_sound, btn_home]:
		b.rect_min_size = Vector2(0, 52)
