extends Node2D

onready var sprite = $Sprite
onready var segment_area = $SegmentArea

const TEXTURE_BODY = preload("res://assets/textures/body_segment.png")
const TEXTURE_TAIL = preload("res://assets/textures/tail.png")

var segment_index: int = 0
var owner_snake: Node = null

func set_owner_snake(snake_node: Node) -> void:
	owner_snake = snake_node

func get_owner_snake() -> Node:
	return owner_snake

func setup_custom_segment(index: int, total_count: int, is_tail: bool, base_color: Color) -> void:
	segment_index = index
	if sprite:
		if is_tail:
			sprite.texture = TEXTURE_TAIL
			sprite.scale = Vector2(0.85, 0.85)
		else:
			sprite.texture = TEXTURE_BODY
			var taper = lerp(1.0, 0.78, float(index) / float(max(total_count, 1)))
			sprite.scale = Vector2(taper, taper)
		
		var shade = 1.0 - (float(index) / float(max(total_count, 1))) * 0.28
		sprite.modulate = Color(base_color.r * shade, base_color.g * shade, base_color.b * shade, 1.0)

func setup_segment(index: int, total_count: int, is_tail: bool) -> void:
	var skin_info = GameManager.SKINS_CATALOG.get(GameManager.equipped_skin_id, {})
	var b_col = skin_info.get("body_color", Color(0.0, 0.75, 0.5))
	setup_custom_segment(index, total_count, is_tail, b_col)
