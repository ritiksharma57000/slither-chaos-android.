# Slither Chaos - Online Multiplayer Update

Only online features were added. Offline gameplay, graphics, homepage layout, map and all existing scenes/scripts are unchanged except three small additive edits (listed below).

## IMPORTANT - what has and has not been tested
| Part | Status |
|---|---|
| Dedicated server (Node.js): matchmaking, authoritative simulation, bots, reconnect, leaderboard | **Tested** with real WebSocket connections from independent clients (see "Test results") |
| Godot client (menu button, connecting screen, online scene, interpolation, HUD, play again) | **Written but NOT run.** No Godot engine was available where this was built, so the GDScript has never been executed or syntax-checked by Godot 3.5.3. Expect to fix small typos/mismatches on first run. Test steps below. |
| Two real Godot clients playing together through the server | **Not tested** (needs your machine) |
| Deployed public server | **Not deployed.** You must host it (see `server/DEPLOY.md`). The game cannot go online until you do. |

## What was added
* **QUICK PLAY ONLINE** button (one extra row under PLAY SURVIVAL) + **LEADERBOARD** button. One tap: connect -> matchmaking queue -> join/create a server-side match -> play. No rooms, codes or addresses. **CANCEL** at any time on the Connecting screen.
* Connecting screen with spinner, connection status (CONNECTING / CONNECTED / RECONNECTING / OFFLINE), error text + **RETRY**.
* Authoritative server: positions, food, growth, collisions, eliminations, scores, boost energy. Client sends only a direction angle + boost flag. Forged scores/positions are ignored; messages are rate-limited.
* Server-side AI bots fill empty slots (10 snakes per match by default), leave when humans join, and are labelled **[BOT]** in the live scoreboard and over their heads. They are never presented as humans.
* Automatic reconnect (up to 8 tries); server keeps your snake alive for 12 s so you resume the same match. If the match is gone you get an error + Retry.
* **PLAY AGAIN** after dying searches for a new match automatically. LEAVE button (tap twice) quits a match.
* Online leaderboard stored on the server (best score per device), survives server restarts.
* Interpolated rendering (110 ms buffer), state snapshots at 15 Hz with per-player interest filtering (only nearby snakes/food are sent), so traffic stays small.

## Files
New client files: `scripts/OnlineConfig.gd`, `OnlineClient.gd` (autoload), `OnlineOverlay.gd`, `OnlineSnake.gd`, `OnlineArena.gd`, `scenes/OnlineGame.tscn`.
Edited originals (additive only):
1. `project.godot` - one line registering the `OnlineClient` autoload.
2. `scripts/MainMenu.gd` - preload + `_setup_online_ui()` and handlers (adds the button row, shifts the button stack up 70 px).
3. `export_presets.cfg` - Android `permissions/internet` and `access_network_state` (required for any network play).
Server: `server/` (has a `.gdignore`, so Godot ignores it). Config template: `server/.env.example`. No credentials exist anywhere.

## Setup steps that still need YOU
1. Host the server (`server/DEPLOY.md`): always-on host, persistent disk, HTTPS. Costs: a small VPS/container is typically a few USD per month; free sleeping tiers will not work. Verify current prices with the provider.
2. Set `SERVER_URL` in `scripts/OnlineConfig.gd` to your `wss://...` address, re-export.
3. Run the two-client test below before releasing.

## Testing with two clients on your own PC (no hosting needed)
1. Install Node.js 18+. In `server/`: `npm install`, then `node server.js` (listens on port 8080). Check http://127.0.0.1:8080/health.
2. Open the project in Godot 3.5.3. Fix any parser errors the editor shows (see the note above).
3. Run two game instances pointing at the local server, either:
   * start the project twice from a terminal: `godot --path . --server=ws://127.0.0.1:8080` (run the command in two windows), or export a Windows build and launch it twice with `--server=ws://127.0.0.1:8080`, or
   * put the text `ws://127.0.0.1:8080` in the file `user://server_url.txt` (Godot's user folder).
4. In both: tap QUICK PLAY ONLINE. Expected: both land in the same match ("ONLINE MATCH #1" in the sector label), see each other plus bots, food disappears for both when eaten, a crash into a body kills the crasher on both screens, LEAVE/close one instance and rejoin within ~12 s to resume.
5. To test bots with a single client: just play alone (you are never alone: bots fill the match).
6. Offline check: PLAY SURVIVAL must behave exactly as before, with the server turned off.

## Test results (server, automated: `cd server && npm test`)
Unit tests (6): food/growth, body collision + kill credit, head-on rules, walls, spawn shield, speed cap, bot fill/make-room.
Integration tests (33 checks, real sockets, independent clients) all passed in the final run:
matchmaking joins the same match and creates a new one at capacity - both clients report identical positions/length per tick - food removal and growth agree on both - elimination event and kill credit agree - forged messages ignored, flooding closed - reconnect inside grace resumes the same snake, late reconnect does not - disconnected player removed, abandoned match destroyed - bots move, eat and grow, step aside for a joining human and return when one leaves - cancel during matchmaking - leaderboard stored and survives restart.
These tests used a Node.js test client speaking the same protocol, not the Godot client.

## Known limitations
* TCP/WebSocket transport (no UDP); no client-side prediction for your own snake, so steering has about one round-trip of latency.
* A client that is offline mid-match for more than the grace period loses that match.
* One server process; see `server/DEPLOY.md` for scaling and capacity notes. Not load-tested at high player counts.
* Online coins: the server computes coins from pickups/eliminations and the client credits them once per round to your normal coin balance. Online rounds do not change offline high score, missions or stats.
* Player names are auto-generated ("Player1234"); there is no rename screen. Name changes can be made via `OnlineClient.set_player_name()`.
