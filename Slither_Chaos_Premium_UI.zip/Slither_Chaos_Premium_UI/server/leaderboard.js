'use strict';
const fs = require('fs');
const path = require('path');

// Server-stored results. One best entry per device id. Scores come only from the authoritative simulation.
class Leaderboard {
  constructor(dir) {
    this.file = path.join(dir, 'leaderboard.json');
    this.entries = new Map(); // device -> {name, score, length, kills, time, at}
    this.saveTimer = null;
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { /* ignore */ }
    try {
      const data = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      for (const e of data.entries || []) this.entries.set(e.device, e);
    } catch (e) { /* first run */ }
  }
  submit(device, name, score, length, kills, time) {
    score = Math.max(0, Math.floor(score));
    const prev = this.entries.get(device);
    const isBest = !prev || score > prev.score;
    if (isBest) {
      this.entries.set(device, { device, name, score, length, kills, time: Math.floor(time), at: Date.now() });
      this._scheduleSave();
    } else if (prev.name !== name) { prev.name = name; this._scheduleSave(); }
    return isBest;
  }
  sorted() { return [...this.entries.values()].sort((a, b) => b.score - a.score || a.at - b.at); }
  top(n) { return this.sorted().slice(0, n).map((e, i) => ({ rank: i + 1, name: e.name, score: e.score, length: e.length, kills: e.kills })); }
  rankOf(device) { const i = this.sorted().findIndex(e => e.device === device); return i < 0 ? 0 : i + 1; }
  bestOf(device) { const e = this.entries.get(device); return e ? e.score : 0; }
  _scheduleSave() {
    if (this.saveTimer) return;
    this.saveTimer = setTimeout(() => { this.saveTimer = null; this.flush(); }, 1500);
  }
  flush() {
    try {
      const list = this.sorted().slice(0, 1000); // keep file small
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify({ entries: list }));
      fs.renameSync(tmp, this.file);
    } catch (e) { console.error('leaderboard save failed:', e.message); }
  }
}
module.exports = Leaderboard;
