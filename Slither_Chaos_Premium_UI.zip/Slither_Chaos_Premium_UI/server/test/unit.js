'use strict';
process.env.FILL_BOTS = '1'; process.env.TARGET_SNAKES = '5';
const assert = require('assert');
const { Match, Snake } = require('../game');
let pass = 0; const ok = (name, fn) => { fn(); pass++; console.log('  ok -', name); };
const mk = () => { const deaths = []; const m = new Match(1, { onDeath: (s, i) => deaths.push([s, i]) }); for (const b of m.bots()) m.removeSnake(b, false); m.botRespawns.length = 0; m.food.clear(); return { m, deaths }; };
const human = (m, name, x, y, a, segs = 6) => { const s = new Snake(m.nextSnake++, { name, session: { name } }); s.place(x, y, a, segs); s.setTarget(a); m.snakes.set(s.id, s); return s; };

ok('food is eaten once, score and growth are server-computed', () => {
  const { m } = mk(); const a = human(m, 'A', 1000, 1000, 0);
  m.spawnFood(1030, 1000, 'crystal');
  const before = a.len; m.update(1 / 30);
  assert.strictEqual(a.score, 50); assert.strictEqual(a.len, before + 3); assert.strictEqual(m.food.size, 1, 'replacement food spawned');
});
ok('head into another body = death + killer credit', () => {
  const { m, deaths } = mk(); const b = human(m, 'B', 3000, 3000, 0); const a = human(m, 'A', 2900, 2950, Math.PI / 2);
  for (let i = 0; i < 90 && a.alive; i++) m.update(1 / 30);
  assert.strictEqual(a.alive, false); assert.strictEqual(deaths.length, 1); assert.ok(/CRASHED INTO B/.test(deaths[0][1].reason));
  assert.strictEqual(b.kills, 1); assert.ok(b.score >= 150);
});
ok('head-on: smaller dies, bigger lives; equal both die', () => {
  let { m, deaths } = mk(); let big = human(m, 'Big', 2000, 2000, 0, 12), small = human(m, 'Small', 2100, 2000, Math.PI, 5);
  for (let i = 0; i < 30; i++) m.update(1 / 30);
  assert.strictEqual(small.alive, false); assert.strictEqual(big.alive, true);
  ({ m, deaths } = mk()); const x = human(m, 'X', 2000, 2000, 0, 8), y = human(m, 'Y', 2100, 2000, Math.PI, 8);
  for (let i = 0; i < 30; i++) m.update(1 / 30);
  assert.strictEqual(x.alive || y.alive, false); assert.strictEqual(deaths.length, 2);
});
ok('wall kills; spawn shield protects', () => {
  let { m, deaths } = mk(); const a = human(m, 'A', 100, 4000, Math.PI);
  for (let i = 0; i < 20; i++) m.update(1 / 30);
  assert.strictEqual(a.alive, false); assert.ok(/BARRIER/.test(deaths[0][1].reason));
  ({ m, deaths } = mk()); const b = human(m, 'B', 100, 4000, Math.PI); b.shield = 5;
  for (let i = 0; i < 20; i++) m.update(1 / 30); assert.strictEqual(b.alive, true);
});
ok('speed is capped by the server (boost needs energy)', () => {
  const { m } = mk(); const a = human(m, 'A', 4000, 4000, 0); a.wantBoost = true;
  const x0 = a.x; for (let i = 0; i < 30; i++) m.update(1 / 30);
  assert.ok(a.x - x0 <= 400 * 1.02 + 1, 'moved ' + (a.x - x0)); assert.ok(a.energy < 100);
});
ok('bots fill empty slots and make room for humans', () => {
  const m = new Match(2, {}); m.rebalanceBots(); assert.strictEqual(m.bots().length, 5);
  m.addHuman({ name: 'H1', skin: 'neon_viper' }); assert.strictEqual(m.bots().length, 4);
  m.addHuman({ name: 'H2', skin: 'neon_viper' }); assert.strictEqual(m.bots().length, 3);
  for (let i = 0; i < 600; i++) m.update(1 / 30);       // 20s of sim, bots must not crash the server
  assert.ok(m.bots().length + m.botRespawns.length === 3);
});
console.log('unit tests passed:', pass);
