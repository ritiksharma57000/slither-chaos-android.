'use strict';
// Real-socket test: spawns the actual server process and connects independent WebSocket clients.
const { spawn } = require('child_process');
const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const results = []; const check = (name, cond, extra) => { results.push([name, !!cond]); console.log((cond ? '  PASS ' : '  FAIL ') + name + (extra ? '  [' + extra + ']' : '')); if (!cond) process.exitCode = 1; };
const hex = () => [...Array(32)].map(() => Math.floor(Math.random() * 16).toString(16)).join('');

function startServer(port, env) {
  const dir = env.DATA_DIR;
  const p = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: Object.assign({}, process.env, { PORT: String(port), QUIET: '1' }, env), stdio: ['ignore', 'inherit', 'inherit'] });
  return p;
}
function getJSON(port, p) { return new Promise((res, rej) => http.get({ port, path: p, host: '127.0.0.1' }, r => { let d = ''; r.on('data', c => d += c); r.on('end', () => res(JSON.parse(d))); }).on('error', rej)); }
async function waitUp(port) { for (let i = 0; i < 50; i++) { try { await getJSON(port, '/health'); return; } catch (e) { await sleep(100); } } throw new Error('server did not start'); }

class Client {
  constructor(port, name) { this.port = port; this.name = name; this.device = hex(); this.token = null; this.snaps = []; this.events = []; this.msgs = []; this.roster = new Map(); this.closed = false; }
  connect() {
    return new Promise((res, rej) => {
      this.ws = new WebSocket('ws://127.0.0.1:' + this.port);
      this.ws.on('open', () => { this.send({ t: 'hello', v: 1, device: this.device, token: this.token, name: this.name, skin: 'neon_viper' }); });
      this.ws.on('message', (d) => {
        const m = JSON.parse(d.toString()); this.msgs.push(m);
        if (m.t === 'welcome') { this.token = m.token; this.welcome = m; res(m); }
        else if (m.t === 'match') { this.match = m; this.you = m.you; for (const p of m.roster) this.roster.set(p.id, p); }
        else if (m.t === 'roster') { this.roster.clear(); for (const p of m.p) this.roster.set(p.id, p); this.rosterMsg = m; }
        else if (m.t === 's') { this.snaps.push(m); if (this.snaps.length > 400) this.snaps.shift(); this.last = m; }
        else if (m.t === 'ev') this.events.push(m);
        else if (m.t === 'died') this.died = m;
        else if (m.t === 'lb') this.lb = m;
      });
      this.ws.on('close', (code) => { this.closed = true; this.closeCode = code; });
      this.ws.on('error', rej);
    });
  }
  send(o) { if (this.ws.readyState === 1) this.ws.send(JSON.stringify(o)); }
  async waitFor(fn, ms, what) { const t = Date.now(); while (Date.now() - t < ms) { const v = fn(); if (v) return v; await sleep(40); } throw new Error('timeout waiting for ' + what); }
  async quickPlay() { this.match = null; this.send({ t: 'quick_play' }); return this.waitFor(() => this.match, 4000, this.name + ' match'); }
  me(snap) { snap = snap || this.last; return snap && snap.sn.find(s => s[0] === this.you); }
  find(id, snap) { snap = snap || this.last; return snap && snap.sn.find(s => s[0] === id); }
  close() { try { this.ws.close(); } catch (e) { /* */ } }
  kill() { try { this.ws.terminate(); } catch (e) { /* */ } }
}

async function scenarioMain() {
  console.log('\n== Scenario 1: matchmaking, sync, food, collisions, reconnect, anti-cheat, leaderboard ==');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'slither-'));
  const env = { DATA_DIR: dir, FILL_BOTS: '0', MAX_HUMANS: '2', GRACE_MS: '1500', ABANDON_MS: '2500', SLITHER_TEST: '1', MM_INTERVAL_MS: '100' };
  let srv = startServer(8101, env); await waitUp(8101);
  const A = new Client(8101, 'AliceTest'), B = new Client(8101, 'BobTest'), Cc = new Client(8101, 'CarolTest');
  await A.connect(); await B.connect(); await Cc.connect();
  // A searches first -> a new match is created; B joins the SAME match; C exceeds capacity -> NEW match
  const ma = await A.quickPlay(); const mb = await B.quickPlay(); const mc = await Cc.quickPlay();
  check('A and B are matched into the same server-side match', ma.id === mb.id, 'match ' + ma.id);
  check('Third player (capacity 2) gets a different new match', mc.id !== ma.id, 'match ' + mc.id);
  let h = await getJSON(8101, '/health');
  check('/health reports 2 matches and 3 players', h.matches === 2 && h.players === 3, JSON.stringify(h));
  check('roster lists both humans, none flagged as bots', A.roster.size === 2 && [...A.roster.values()].every(p => p.b === 0));
  Cc.close();

  // both see each other moving, and agree on positions at the same server tick
  A.send({ t: 'test_place', x: 4000, y: 4000, a: 0, shield: 6 }); B.send({ t: 'test_place', x: 4000, y: 4300, a: 0, shield: 6 });
  await sleep(1400);
  const bFromA = A.snaps.filter(s => A.find(B.you, s)).map(s => A.find(B.you, s));
  const moved = Math.hypot(bFromA[bFromA.length - 1][1] - bFromA[0][1], bFromA[bFromA.length - 1][2] - bFromA[0][2]);
  check("A sees B's snake moving", moved > 50, 'moved ' + moved.toFixed(0) + 'px');
  // put them in a known spot near each other so they stay in view of each other
  A.send({ t: 'test_place', x: 4000, y: 4000, a: 0, shield: 6 }); B.send({ t: 'test_place', x: 4000, y: 4300, a: 0, shield: 6 });
  await sleep(600);
  let agree = 0, total = 0;
  for (const sa of A.snaps.slice(-8)) { const sb = B.snaps.find(x => x.k === sa.k); if (!sb) continue; for (const id of [A.you, B.you]) { const ea = A.find(id, sa), eb = B.find(id, sb); if (ea && eb) { total++; if (ea[1] === eb[1] && ea[2] === eb[2] && ea[5] === eb[5]) agree++; } } }
  check('Both clients report identical positions/length for every snake at the same tick', total >= 6 && agree === total, agree + '/' + total);

  // food: A steers to the nearest food, grows; both clients see the food vanish and agree on A's length
  A.send({ t: 'test_place', x: 4000, y: 4000, a: 0, shield: 8 }); B.send({ t: 'test_place', x: 4000, y: 4250, a: 0, shield: 8 });
  await sleep(400);
  const food0 = A.last.f.slice().sort((p, q) => Math.hypot(p[1] - 4000, p[2] - 4000) - Math.hypot(q[1] - 4000, q[2] - 4000))[0];
  const len0 = A.me()[5], score0 = A.last.you.sc;
  let ate = false;
  for (let i = 0; i < 120 && !ate; i++) { const me = A.me(); A.send({ t: 'inp', a: Math.atan2(food0[2] - me[2], food0[1] - me[1]), b: 0 }); await sleep(50); ate = !A.last.f.some(f => f[0] === food0[0]); }
  await sleep(300);
  check('Food collected on the server: it disappears for A', ate);
  check("A's length and score grew (server-computed)", A.me()[5] > len0 && A.last.you.sc > score0, 'len ' + len0 + '->' + A.me()[5] + ', score ' + score0 + '->' + A.last.you.sc);
  const sa = A.last, sb = B.snaps.find(x => x.k === sa.k) || B.last;
  check("B sees the same food removed and A's new length", !B.last.f.some(f => f[0] === food0[0]) && B.find(A.you)[5] === A.me()[5], 'B sees len ' + B.find(A.you)[5]);

  // anti-cheat
  const sc = A.last.you.sc; const spamBefore = A.me();
  A.send({ t: 'inp', a: 1e308, b: 1, score: 999999, x: 0, y: 0, len: 500 }); A.send({ t: 'inp', a: 'NaN', score: 1e9 }); A.send({ t: 'score', v: 1e9 });
  await sleep(1000);
  check('Forged score/position fields are ignored', A.last.you.sc >= sc && A.last.you.sc < sc + 400 && A.me()[1] > 100, 'score ' + A.last.you.sc);
  const spam = new Client(8101, 'Spammer'); await spam.connect(); for (let i = 0; i < 400; i++) spam.send({ t: 'ping', c: i }); await sleep(500);
  check('Message flooding is rate-limited (socket closed)', spam.closed && spam.closeCode === 1008, 'close code ' + spam.closeCode);

  // collision: B moves east, A boosts and steers into B's body
  B.send({ t: 'test_place', x: 2000, y: 4000, a: 0, shield: 0 }); A.send({ t: 'test_place', x: 1700, y: 4000, a: 0, shield: 0 });
  B.send({ t: 'inp', a: 0, b: 0 });
  await sleep(200);
  let killedTick = null;
  for (let i = 0; i < 200 && !A.died; i++) {
    const me = A.me(), tb = A.find(B.you);
    if (me && tb) { const seg = tb[7].length >= 8 ? [tb[7][6], tb[7][7]] : [tb[1], tb[2]]; A.send({ t: 'inp', a: Math.atan2(seg[1] - me[2], seg[0] - me[1]), b: 1 }); }
    await sleep(40);
  }
  await sleep(300);
  check('A was eliminated by the server after hitting B (received "died")', !!A.died, A.died && A.died.reason);
  const evA = A.events.find(e => e.e === 'kill'), evB = B.events.find(e => e.e === 'kill');
  check('Both clients received the same elimination event', evA && evB && evA.v === evB.v && evA.k === evB.k && evA.v === A.you && evA.k === B.you, JSON.stringify(evB));
  check('B got server-awarded kill credit (150+ score, 1 kill)', B.last.you.kl === 1 && B.last.you.sc >= 150, 'kills ' + B.last.you.kl + ' score ' + B.last.you.sc);
  check('Dead player stops receiving the match and the roster updates', B.roster.size === 1 || (B.rosterMsg && B.rosterMsg.p.length === 1));

  // reconnect: B drops its socket and comes back with its token inside the grace period
  const bId = B.you, bTok = B.token, bSnapsBefore = B.snaps.length; B.kill(); await sleep(500);
  h = await getJSON(8101, '/health');
  const B2 = new Client(8101, 'BobTest'); B2.device = B.device; B2.token = bTok; B2.roster = new Map();
  const w = await B2.connect();
  const rm = await B2.waitFor(() => B2.match, 3000, 'resumed match');
  check('Reconnect inside grace period resumes the same snake in the same match', w.resumed === true && rm.resumed === true && rm.you === bId && rm.id === mb.id);
  await B2.waitFor(() => B2.last, 2000, 'snapshot after resume');
  check('Snapshots continue after reconnect', B2.me() && B2.me()[1] > 0);
  // drop again and do NOT come back: snake removed after grace, match abandoned after ABANDON_MS
  B2.kill(); await sleep(2500);
  h = await getJSON(8101, '/health');
  check('Disconnected player is removed after the grace period', h.players === 0, JSON.stringify(h));
  await sleep(3500);
  h = await getJSON(8101, '/health');
  check('Abandoned matches are destroyed', h.matches === 0, JSON.stringify(h));
  const B3 = new Client(8101, 'BobTest'); B3.device = B.device; B3.token = bTok; await B3.connect();
  check('Late reconnect gets a fresh lobby (no match is resurrected)', B3.welcome.state === 'lobby' && !B3.match);

  // leaderboard (server-stored) and persistence across server restart
  A.send({ t: 'lb' }); await A.waitFor(() => A.lb, 2000, 'leaderboard');
  const mine = A.lb.top.find(e => e.name === 'AliceTest');
  check('Online leaderboard contains A\'s server-recorded result', mine && mine.score === A.died.score, JSON.stringify(mine));
  check('Leaderboard also contains B (recorded when B left)', A.lb.top.some(e => e.name === 'BobTest'));
  A.close(); B3.close(); await sleep(300);
  srv.kill('SIGINT'); await sleep(600);
  srv = startServer(8101, env); await waitUp(8101);
  const lbAfter = await getJSON(8101, '/leaderboard');
  check('Leaderboard survives a server restart', lbAfter.top.some(e => e.name === 'AliceTest' && e.score === mine.score), 'entries ' + lbAfter.top.length);
  srv.kill('SIGINT'); await sleep(300);
}

async function scenarioBots() {
  console.log('\n== Scenario 2: AI bots when humans are scarce ==');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'slither-')); 
  const srv = startServer(8102, { DATA_DIR: dir, FILL_BOTS: '1', TARGET_SNAKES: '5', MAX_HUMANS: '5', MM_INTERVAL_MS: '100' }); await waitUp(8102);
  const A = new Client(8102, 'SoloTest'); await A.connect(); await A.quickPlay();
  await sleep(500);
  const bots = () => [...A.roster.values()].filter(p => p.b === 1);
  check('One human alone: server adds 4 bots, flagged as bots', bots().length === 4 && A.match.bots === 4, 'bots ' + bots().length);
  check('Bots are never presented as humans (humans=1)', [...A.roster.values()].filter(p => p.b === 0).length === 1);
  const botIds = bots().map(b => b.id); const first = {}, maxMove = {}; let grew = false; const t0 = Date.now();
  while (Date.now() - t0 < 30000 && !grew) {
    await sleep(500);
    for (const snap of A.snaps) {
      for (const m of snap.mm) if (botIds.includes(m[0])) { if (!first[m[0]]) first[m[0]] = [m[1], m[2]]; maxMove[m[0]] = Math.max(maxMove[m[0]] || 0, Math.hypot(m[1] - first[m[0]][0], m[2] - first[m[0]][1])); }
      for (const s of snap.sn) if (botIds.includes(s[0]) && s[5] > 9) grew = true;
      if (snap.lb && snap.lb.some(e => botIds.includes(e[0]) && e[2] > 9)) grew = true;
    }
  }
  const movedBots = Object.values(maxMove).filter(d => d > 100).length;
  check('Bots move around the arena (server-driven, seen by the client)', movedBots >= 2, movedBots + ' bots moved >100px');
  check('Bots collect food and grow', grew);
  const B = new Client(8102, 'SecondTest'); await B.connect(); await B.quickPlay(); await sleep(700);
  check('A second human joins the same match', B.match.id === A.match.id);
  await A.waitFor(() => bots().length === 3, 3000, 'bots to make room').catch(() => {});
  check('Bots make room: 3 bots remain with 2 humans', bots().length === 3 && [...A.roster.values()].filter(p => p.b === 0).length === 2, 'bots ' + bots().length);
  const bSees = B.last && B.last.mm.length;
  check('Both players see the same bot set', bots().length === [...B.roster.values()].filter(p => p.b === 1).length && bSees >= 4 && bSees <= 5, 'minimap entries ' + bSees);
  B.send({ t: 'leave' }); await A.waitFor(() => bots().length === 4, 3000, 'bot to refill').catch(() => {});
  check('When a human leaves, a bot fills the slot again', bots().length === 4, 'bots ' + bots().length);
  A.close(); B.close(); srv.kill('SIGINT'); await sleep(300);
}

async function scenarioCancel() {
  console.log('\n== Scenario 3: cancel during matchmaking ==');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'slither-'));
  const srv = startServer(8103, { DATA_DIR: dir, FILL_BOTS: '0', MM_INTERVAL_MS: '1500' }); await waitUp(8103);
  const A = new Client(8103, 'CancelTest'); await A.connect();
  A.send({ t: 'quick_play' }); await sleep(200); A.send({ t: 'cancel' }); await sleep(300);
  check('Server acknowledges cancel', A.msgs.some(m => m.t === 'mm' && m.s === 'cancelled'));
  await sleep(1800);
  const h = await getJSON(8103, '/health');
  check('Cancelled player is not placed into a match', h.players === 0 && h.matches === 0, JSON.stringify(h));
  A.close(); srv.kill('SIGINT'); await sleep(200);
}

(async () => {
  const only = process.argv[2];
  try { if (!only || only === '1') await scenarioMain(); if (!only || only === '2') await scenarioBots(); if (!only || only === '3') await scenarioCancel(); }
  catch (e) { console.error('TEST ERROR:', e.message); process.exitCode = 1; }
  const failed = results.filter(r => !r[1]).length;
  console.log('\nintegration: ' + (results.length - failed) + '/' + results.length + ' checks passed');
  process.exit(process.exitCode || 0);
})();
