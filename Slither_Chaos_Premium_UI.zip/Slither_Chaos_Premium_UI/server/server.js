'use strict';
// Slither Chaos online server: WebSocket gateway, matchmaking queue, authoritative matches, leaderboard.
const http = require('http');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const C = require('./config');
const { Match, SKINS } = require('./game');
const Leaderboard = require('./leaderboard');

const PROTOCOL = 1;
const board = new Leaderboard(C.DATA_DIR);
const matches = new Map();   // id -> Match
const sessions = new Map();  // token -> session
const queue = [];            // sessions waiting for a match
let nextMatchId = 1;
let deathCounter = 0;

const log = (...a) => { if (!process.env.QUIET) console.log(new Date().toISOString(), ...a); };
const now = () => Date.now();

function send(sess, obj) {
  const ws = sess.ws;
  if (ws && ws.readyState === 1) { try { ws.send(JSON.stringify(obj)); } catch (e) { /* socket closing */ } }
}
function cleanName(n, fallback) {
  n = String(n || '').replace(/[^A-Za-z0-9 _.\-]/g, '').trim().slice(0, 16);
  return n.length >= 2 ? n : fallback;
}

// ---------- matchmaking ----------
function createMatch() {
  const m = new Match(nextMatchId++, { onDeath: handleDeath, onEvent: broadcastEvent });
  matches.set(m.id, m);
  m.rebalanceBots();
  log('match created', m.id, 'matches:', matches.size);
  return m;
}
function pickMatch() {
  let best = null;
  for (const m of matches.values()) {
    const h = m.humans().length;
    if (h >= C.MAX_HUMANS) continue;
    if (!best || h > best.humans().length) best = m;   // fill existing matches first
  }
  if (best) return best;
  if (matches.size < C.MAX_MATCHES) return createMatch();
  return null;
}
function processQueue() {
  while (queue.length) {
    const sess = queue[0];
    if (sess.state !== 'searching') { queue.shift(); continue; }
    const m = pickMatch();
    if (!m) { // everything full: tell the client and drop it from the queue
      queue.shift(); sess.state = 'lobby';
      send(sess, { t: 'error', code: 'server_full', msg: 'All matches are full. Please try again in a moment.' });
      continue;
    }
    queue.shift();
    joinMatch(sess, m);
  }
}
function joinMatch(sess, m) {
  const sn = m.addHuman(sess);
  sess.state = 'playing'; sess.matchId = m.id; sess.snake = sn; sess.lastDied = null;
  send(sess, matchMsg(sess, m, false));
  log('join', sess.name, '-> match', m.id, 'humans', m.humans().length, 'bots', m.bots().length);
}
function matchMsg(sess, m, resumed) {
  return { t: 'match', id: m.id, you: sess.snake.id, arena: C.ARENA, resumed, tick: C.TICK_HZ, snap: C.SNAP_HZ, humans: m.humans().length, bots: m.bots().length, roster: m.roster() };
}

// ---------- match lifecycle hooks ----------
function handleDeath(snake, info) {
  const sess = snake.session;
  if (!sess) return;
  const m = matches.get(sess.matchId);
  const time = m ? m.time - snake.born : 0;
  const isBest = board.submit(sess.device, sess.name, snake.score, snake.len, snake.kills, time);
  const res = { t: 'died', did: ++deathCounter, reason: info.reason, score: snake.score, len: snake.len, kills: snake.kills, coins: snake.coins, time: Math.floor(time), best: board.bestOf(sess.device), newBest: isBest, rank: board.rankOf(sess.device) };
  sess.state = 'lobby'; sess.matchId = 0; sess.snake = null;
  sess.lastDied = res;
  send(sess, res);
  log('death', sess.name, 'score', snake.score, info.reason);
}
function leaveMatch(sess, why) {
  if (sess.state === 'searching') { const i = queue.indexOf(sess); if (i >= 0) queue.splice(i, 1); }
  if (sess.state === 'playing' && sess.snake) {
    const m = matches.get(sess.matchId);
    const sn = sess.snake;
    if (m) {
      board.submit(sess.device, sess.name, sn.score, sn.len, sn.kills, m.time - sn.born);
      m.removeSnake(sn, true);
    }
    log('leave', sess.name, why);
  }
  sess.state = 'lobby'; sess.matchId = 0; sess.snake = null;
}
function broadcastEvent(m, ev, victim) {
  for (const s of m.humans()) send(s.session, ev);
  if (victim && !victim.bot && victim.session) send(victim.session, ev); // the eliminated player gets it too
}
function sendRoster(m) {
  const msg = { t: 'roster', p: m.roster() };
  for (const s of m.humans()) send(s.session, msg);
}

// ---------- main loops ----------
let last = now();
setInterval(() => {
  const t = now(); const dt = Math.min(0.1, (t - last) / 1000); last = t;
  const snapEvery = Math.max(1, Math.round(C.TICK_HZ / C.SNAP_HZ));
  for (const m of matches.values()) {
    m.update(dt);
    if (m.rosterDirty) { m.rosterDirty = false; sendRoster(m); }
    if (m.tick % snapEvery === 0) {
      const withBoard = m.tick % (snapEvery * C.SNAP_HZ) === 0;
      for (const s of m.humans()) send(s.session, m.snapshotFor(s, withBoard));
    }
    if (!m.humans().length && m.emptySince && t - m.emptySince > C.ABANDON_MS) {
      matches.delete(m.id); log('match closed (abandoned)', m.id, 'matches:', matches.size);
    }
  }
}, Math.round(1000 / C.TICK_HZ));
setInterval(processQueue, C.MM_INTERVAL_MS);
setInterval(() => { // sessions: reconnect grace + expiry
  const t = now();
  for (const [tok, s] of sessions) {
    if (s.ws) continue;
    const away = t - s.discAt;
    if (s.state !== 'lobby' && away > C.GRACE_MS) leaveMatch(s, 'disconnect timeout');
    if (away > C.SESSION_TTL_MS) sessions.delete(tok);
  }
}, 500);
setInterval(() => { // heartbeat for dead TCP connections
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false; try { ws.ping(); } catch (e) { /* ignore */ }
  }
}, 10000);

// ---------- http + websocket ----------
const server = http.createServer((req, res) => {
  const url = (req.url || '').split('?')[0];
  res.setHeader('Content-Type', 'application/json'); res.setHeader('Access-Control-Allow-Origin', '*');
  if (url === '/health') {
    let players = 0; for (const m of matches.values()) players += m.humans().length;
    return res.end(JSON.stringify({ ok: true, protocol: PROTOCOL, matches: matches.size, players, queued: queue.length }));
  }
  if (url === '/leaderboard') return res.end(JSON.stringify({ top: board.top(20) }));
  res.statusCode = 404; res.end('{"error":"not found"}');
});
const wss = new WebSocketServer({ server, maxPayload: 4096, perMessageDeflate: false });

wss.on('connection', (ws) => {
  ws.isAlive = true; ws.sess = null;
  ws.on('pong', () => { ws.isAlive = true; });
  const bucket = { n: 60, t: now() };
  ws.on('message', (data) => {
    ws.isAlive = true;
    const t = now(); bucket.n = Math.min(80, bucket.n + (t - bucket.t) * 0.06); bucket.t = t; // ~60 msgs/s refill
    if (--bucket.n < 0) { ws.close(1008, 'rate limit'); return; }
    let msg; try { msg = JSON.parse(data.toString()); } catch (e) { return; }
    if (!msg || typeof msg.t !== 'string') return;
    if (msg.t === 'hello') return onHello(ws, msg);
    if (!ws.sess) return;
    onMessage(ws.sess, msg);
  });
  ws.on('close', () => {
    const s = ws.sess;
    if (s && s.ws === ws) { s.ws = null; s.discAt = now(); if (s.state === 'searching') leaveMatch(s, 'closed while searching'); }
  });
  ws.on('error', () => { /* handled by close */ });
  setTimeout(() => { if (!ws.sess) ws.close(1008, 'no hello'); }, 8000);
});

function onHello(ws, msg) {
  if (msg.v !== PROTOCOL) { ws.send(JSON.stringify({ t: 'error', code: 'version', msg: 'Please update the game (protocol mismatch).' })); return ws.close(); }
  const device = String(msg.device || '');
  if (!/^[a-f0-9]{16,64}$/.test(device)) return ws.close(1008, 'bad device id');
  let sess = msg.token ? sessions.get(String(msg.token)) : null;
  let resumed = false;
  if (sess && sess.device === device) {
    if (sess.ws && sess.ws !== ws) { sess.ws.sess = null; try { sess.ws.close(1000, 'replaced'); } catch (e) { /* ignore */ } }
    resumed = true;
  } else {
    sess = { token: crypto.randomBytes(16).toString('hex'), device, state: 'lobby', matchId: 0, snake: null, lastDied: null };
    sessions.set(sess.token, sess);
  }
  sess.ws = ws; ws.sess = sess; sess.discAt = 0;
  sess.name = cleanName(msg.name, sess.name || ('Player' + (1000 + Math.floor(Math.random() * 9000))));
  sess.skin = SKINS.includes(msg.skin) ? msg.skin : 'neon_viper';
  send(sess, { t: 'welcome', token: sess.token, resumed, name: sess.name, protocol: PROTOCOL, state: sess.state });
  if (resumed) {
    const m = matches.get(sess.matchId);
    if (sess.state === 'playing' && m && sess.snake && sess.snake.alive) send(sess, matchMsg(sess, m, true));
    else if (sess.lastDied) { send(sess, sess.lastDied); }
  }
  log('hello', sess.name, resumed ? '(resumed)' : '(new)');
}

function onMessage(sess, msg) {
  switch (msg.t) {
    case 'quick_play':
      if (sess.state === 'lobby') { sess.state = 'searching'; queue.push(sess); send(sess, { t: 'mm', s: 'searching', queued: queue.length }); }
      else if (sess.state === 'playing') { const m = matches.get(sess.matchId); if (m) send(sess, matchMsg(sess, m, true)); }
      break;
    case 'cancel':
      if (sess.state === 'searching') { leaveMatch(sess, 'cancelled'); send(sess, { t: 'mm', s: 'cancelled' }); }
      break;
    case 'leave':
      leaveMatch(sess, 'left'); send(sess, { t: 'left' });
      break;
    case 'inp': {
      const sn = sess.snake;
      if (sess.state !== 'playing' || !sn || !sn.alive) break;
      const a = Number(msg.a);
      if (Number.isFinite(a)) sn.setTarget(a);   // only a direction is accepted; speed/position are server-side
      sn.wantBoost = msg.b === 1 || msg.b === true;
      break;
    }
    case 'lb':
      send(sess, { t: 'lb', top: board.top(20), you: { rank: board.rankOf(sess.device), best: board.bestOf(sess.device) } });
      break;
    case 'ping':
      send(sess, { t: 'pong', c: msg.c });
      break;
    case 'test_place': // test only
      if (C.TEST_MODE && sess.snake && sess.snake.alive) {
        const sn = sess.snake; sn.place(Number(msg.x), Number(msg.y), Number(msg.a) || 0, sn.segs.length); sn.shield = Number(msg.shield) || 0; sn.setTarget(Number(msg.a) || 0);
      }
      break;
  }
}

if (require.main === module) {
  server.listen(C.PORT, () => log('Slither Chaos server listening on port', C.PORT, 'protocol', PROTOCOL, C.TEST_MODE ? '(TEST MODE!)' : ''));
  const shutdown = () => { board.flush(); process.exit(0); };
  process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
}
module.exports = { server, matches, sessions, board, wss };
