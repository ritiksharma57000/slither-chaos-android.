'use strict';
// Authoritative game simulation: snakes, food, growth, collisions, bots.
// Constants mirror the offline game (Player.gd / AISnake.gd / Food.gd).
const C = require('./config');

const FOOD_TYPES = ['berry', 'orb', 'crystal', 'coin']; // index sent to clients
const FOOD_DEF = {
  berry:   { pts: 10, len: 1, coin: 0 },
  orb:     { pts: 25, len: 2, coin: 1 },
  crystal: { pts: 50, len: 3, coin: 2 },
  coin:    { pts: 30, len: 1, coin: 5 }
};
const BOT_NAMES = ['Viper_X','CyberGhost','NeonFang','PixelCobra','VoidHunter','SolarStalker','QuantumWorm','ChronoGlider','NovaDrifter','PulseCrawler','ShadowSerpent','HexaBlade','TitanCoil','AstroStinger','PrismWurm'];
const PERSONALITIES = ['collector', 'explorer', 'aggressive', 'survivor', 'tricky'];
const SKINS = ['neon_viper', 'cyber_cyan', 'solar_flare', 'cosmic_purple', 'crimson_phantom'];

const HEAD_R = 18, SEG_R = 16;
const BODY_HIT2 = (HEAD_R + SEG_R - 2) * (HEAD_R + SEG_R - 2);
const HEAD_HIT2 = (HEAD_R * 2) * (HEAD_R * 2);
const EAT_R2 = 40 * 40;
const WALL = 80;

const rand = (a, b) => a + Math.random() * (b - a);

class Snake {
  constructor(id, opts) {
    this.id = id;
    this.name = opts.name;
    this.bot = !!opts.bot;
    this.personality = opts.personality || 'human';
    this.skin = opts.skin || 'neon_viper';
    this.ci = opts.ci || 0;
    this.session = opts.session || null;
    this.alive = true;
    this.score = 0; this.coins = 0; this.kills = 0;
    this.born = 0; this.shield = 0;
    this.energy = 100; this.boosting = false; this.wantBoost = false;
    // bot / human physics parameters (same as offline)
    this.base = this.bot ? 210 : 230; this.boostSpeed = this.bot ? 350 : 400;
    this.turn = this.bot ? 6.5 : 8.5; this.sp = this.bot ? 23 : 24;
    this.think = 0; this.botBoost = 0; this.wander = rand(0, Math.PI * 2);
  }
  place(x, y, angle, segs) {
    this.x = x; this.y = y;
    this.dx = Math.cos(angle); this.dy = Math.sin(angle);
    this.tx = this.dx; this.ty = this.dy;
    this.segs = [];
    for (let i = 1; i <= segs; i++) this.segs.push({ x: x - this.dx * this.sp * i, y: y - this.dy * this.sp * i });
  }
  get len() { return this.segs.length + 1; }
  setTarget(angle) { this.tx = Math.cos(angle); this.ty = Math.sin(angle); }
  addSegments(n) {
    for (let i = 0; i < n; i++) {
      const last = this.segs[this.segs.length - 1] || { x: this.x, y: this.y };
      this.segs.push({ x: last.x - this.dx * this.sp, y: last.y - this.dy * this.sp });
    }
  }
  step(dt) {
    const k = Math.min(1, this.turn * dt);
    let ndx = this.dx + (this.tx - this.dx) * k, ndy = this.dy + (this.ty - this.dy) * k;
    let l = Math.hypot(ndx, ndy);
    if (l < 1e-4) { ndx = -this.dy; ndy = this.dx; l = 1; }
    this.dx = ndx / l; this.dy = ndy / l;
    this.boosting = this.wantBoost && this.energy > 5;
    if (this.boosting) this.energy = Math.max(0, this.energy - 32 * dt);
    else this.energy = Math.min(100, this.energy + 22 * dt);
    const speed = (this.boosting && this.energy > 0) ? this.boostSpeed : this.base;
    this.x += this.dx * speed * dt; this.y += this.dy * speed * dt;
    let px = this.x, py = this.y;
    for (const s of this.segs) {
      const ddx = s.x - px, ddy = s.y - py, d = Math.hypot(ddx, ddy);
      if (d > this.sp) { s.x = px + ddx / d * this.sp; s.y = py + ddy / d * this.sp; }
      px = s.x; py = s.y;
    }
    if (this.shield > 0) this.shield -= dt;
  }
}

class Match {
  constructor(id, hooks) {
    this.id = id;
    this.hooks = hooks || {};      // onDeath(snake, info), onRoster()
    this.snakes = new Map();       // id -> Snake
    this.food = new Map();         // id -> {id,x,y,t}
    this.nextSnake = 1; this.nextFood = 1;
    this.time = 0; this.tick = 0;
    this.botRespawns = [];         // times (match.time) at which to spawn a bot
    this.emptySince = Date.now();
    this.rosterDirty = true;
    for (let i = 0; i < C.FOOD_TARGET; i++) this.spawnFood();
  }
  humans() { return [...this.snakes.values()].filter(s => !s.bot && s.alive); }
  bots() { return [...this.snakes.values()].filter(s => s.bot); }
  spawnFood(x, y, type) {
    if (type === undefined) {
      const r = Math.random();
      type = r < 0.12 ? 'coin' : r < 0.32 ? 'crystal' : r < 0.60 ? 'orb' : 'berry';
    }
    const f = { id: this.nextFood++, x: x !== undefined ? x : rand(150, C.ARENA - 150), y: y !== undefined ? y : rand(150, C.ARENA - 150), t: FOOD_TYPES.indexOf(type) };
    this.food.set(f.id, f);
    return f;
  }
  spawnPoint() {
    let best = null, bestD = -1;
    for (let i = 0; i < 25; i++) {
      const x = rand(600, C.ARENA - 600), y = rand(600, C.ARENA - 600);
      let md = 1e9;
      for (const s of this.snakes.values()) if (s.alive) md = Math.min(md, Math.hypot(s.x - x, s.y - y));
      if (md > 800) return { x, y };
      if (md > bestD) { bestD = md; best = { x, y }; }
    }
    return best;
  }
  addHuman(session) {
    const sn = new Snake(this.nextSnake++, { name: session.name, skin: session.skin, session });
    const p = this.spawnPoint();
    sn.place(p.x, p.y, rand(0, Math.PI * 2), 6);
    sn.shield = C.SPAWN_SHIELD_MS / 1000; sn.born = this.time;
    this.snakes.set(sn.id, sn);
    this.rosterDirty = true; this.emptySince = 0;
    this.rebalanceBots();
    return sn;
  }
  addBot() {
    const used = new Set(this.bots().map(b => b.name));
    let name = BOT_NAMES.find(n => !used.has(n)) || ('Bot_' + this.nextSnake);
    const sn = new Snake(this.nextSnake++, { name, bot: true, personality: PERSONALITIES[Math.floor(Math.random() * PERSONALITIES.length)], ci: Math.floor(Math.random() * 6) });
    const p = this.spawnPoint();
    sn.place(p.x, p.y, rand(0, Math.PI * 2), 8);
    sn.shield = 2; sn.born = this.time;
    this.snakes.set(sn.id, sn);
    this.rosterDirty = true;
    return sn;
  }
  removeSnake(sn, dropFood) {
    if (!this.snakes.has(sn.id)) return;
    if (dropFood && sn.alive) this.dropFood(sn);
    sn.alive = false;
    this.snakes.delete(sn.id);
    this.rosterDirty = true;
    if (!this.humans().length && !this.emptySince) this.emptySince = Date.now();
    this.rebalanceBots();
  }
  rebalanceBots() {
    if (!C.FILL_BOTS) return;
    const want = Math.max(0, C.TARGET_SNAKES - this.humans().length);
    const have = this.bots().length + this.botRespawns.length;
    if (have < want) { for (let i = have; i < want; i++) this.addBot(); }
    else if (have > want) {
      let extra = have - want;
      this.botRespawns.length = Math.max(0, this.botRespawns.length - extra);
      extra = Math.max(0, this.bots().length + this.botRespawns.length - want);
      const bs = this.bots().sort((a, b) => a.score - b.score);
      for (let i = 0; i < extra && i < bs.length; i++) this.removeSnake(bs[i], true);
    }
  }
  dropFood(sn) {
    this.spawnFood(sn.x, sn.y, 'orb');
    const step = Math.max(1, Math.floor(sn.segs.length / 8));
    for (let i = 0; i < sn.segs.length; i += step) this.spawnFood(sn.segs[i].x, sn.segs[i].y, Math.random() < 0.4 ? 'crystal' : 'orb');
  }
  kill(victim, reason, killer) {
    if (!victim.alive) return;
    victim.alive = false;
    this.dropFood(victim);
    if (killer && killer !== victim && killer.alive) { killer.kills++; killer.score += 150; killer.coins += 25; }
    this.rosterDirty = true;
    this.broadcastEvent({ t: 'ev', e: 'kill', v: victim.id, k: killer ? killer.id : 0, r: reason }, victim);
    if (victim.bot) {
      this.snakes.delete(victim.id);
      if (C.FILL_BOTS) this.botRespawns.push(this.time + C.BOT_RESPAWN_MS / 1000);
    } else if (this.hooks.onDeath) {
      this.snakes.delete(victim.id);
      this.hooks.onDeath(victim, { reason, killer });
      if (!this.humans().length && !this.emptySince) this.emptySince = Date.now();
      this.rebalanceBots();
    }
  }
  broadcastEvent(ev, victim) { if (this.hooks.onEvent) this.hooks.onEvent(this, ev, victim); }

  update(dt) {
    this.time += dt; this.tick++;
    const alive = [...this.snakes.values()].filter(s => s.alive);
    for (const s of alive) { if (s.bot) this.botThink(s, dt); s.step(dt); }
    // food
    for (const s of alive) {
      for (const f of this.food.values()) {
        const dx = f.x - s.x, dy = f.y - s.y;
        if (dx * dx + dy * dy < EAT_R2) {
          const d = FOOD_DEF[FOOD_TYPES[f.t]];
          this.food.delete(f.id);
          s.score += d.pts; s.coins += d.coin; s.addSegments(d.len);
          this.spawnFood();
        }
      }
    }
    // collisions (evaluated together so ordering does not favour anybody)
    const deaths = new Map();
    for (const a of alive) {
      if (a.shield > 0) continue;
      if (a.x < WALL || a.x > C.ARENA - WALL || a.y < WALL || a.y > C.ARENA - WALL) { deaths.set(a, { r: 'ELECTRIC BARRIER COLLISION!', k: null }); continue; }
      for (const b of alive) {
        if (b === a) continue;
        const hx = a.x - b.x, hy = a.y - b.y;
        if (hx * hx + hy * hy < HEAD_HIT2) {
          if (a.len < b.len) { deaths.set(a, { r: 'HEAD-ON COLLISION WITH LARGER RIVAL!', k: b }); break; }
          if (a.len === b.len) { deaths.set(a, { r: 'MUTUAL HEAD-ON ELIMINATION!', k: b }); break; }
        }
        let hit = false;
        for (const sg of b.segs) {
          const dx = a.x - sg.x, dy = a.y - sg.y;
          if (dx * dx + dy * dy < BODY_HIT2) { hit = true; break; }
        }
        if (hit) { deaths.set(a, { r: "CRASHED INTO " + b.name.toUpperCase() + "'S BODY!", k: b }); break; }
      }
    }
    for (const [v, info] of deaths) this.kill(v, info.r, info.k);
    // bot respawns
    while (this.botRespawns.length && this.botRespawns[0] <= this.time) {
      this.botRespawns.shift();
      if (this.bots().length < Math.max(0, C.TARGET_SNAKES - this.humans().length)) this.addBot();
    }
  }

  // ---- bot AI (runs on the server only) ----
  botThink(s, dt) {
    if (s.botBoost > 0) { s.botBoost -= dt; s.wantBoost = s.botBoost > 0; }
    s.think -= dt;
    if (s.think > 0) return;
    s.think = rand(0.2, 0.4);
    const m = 350, A = C.ARENA;
    let ax = 0, ay = 0;
    if (s.x < WALL + m) ax += 1; else if (s.x > A - WALL - m) ax -= 1;
    if (s.y < WALL + m) ay += 1; else if (s.y > A - WALL - m) ay -= 1;
    if (ax || ay) { s.setTarget(Math.atan2(ay, ax)); return; }
    // evade other snakes' bodies/heads ahead
    let worst = null, worstD = 170 * 170;
    for (const o of this.snakes.values()) {
      if (o === s || !o.alive) continue;
      const pts = [o, ...o.segs];
      for (let i = 0; i < pts.length; i += (i === 0 ? 1 : 2)) {
        const dx = pts[i].x - s.x, dy = pts[i].y - s.y, d2 = dx * dx + dy * dy;
        if (d2 < worstD) {
          const d = Math.sqrt(d2) || 1;
          if ((s.dx * dx + s.dy * dy) / d > 0.4) { worstD = d2; worst = { dx, dy, d }; }
        }
      }
    }
    if (worst) { s.setTarget(Math.atan2(-worst.dy, -worst.dx)); return; }
    const seek = () => {
      let bd = 3000 * 3000, bf = null;
      for (const f of this.food.values()) { const dx = f.x - s.x, dy = f.y - s.y, d = dx * dx + dy * dy; if (d < bd) { bd = d; bf = f; } }
      if (bf) s.setTarget(Math.atan2(bf.y - s.y, bf.x - s.x));
      else { s.wander += rand(-0.6, 0.6); s.setTarget(s.wander); }
    };
    switch (s.personality) {
      case 'aggressive': if (Math.random() < 0.35 && s.botBoost <= 0) s.botBoost = rand(0.8, 1.8); seek(); break;
      case 'tricky': s.wander += rand(-1.2, 1.2); s.setTarget(s.wander); break;
      case 'explorer': if (Math.random() < 0.4) seek(); else { s.wander += rand(-0.5, 0.5); s.setTarget(s.wander); } break;
      default: seek();
    }
  }

  // ---- networking views ----
  roster() {
    return [...this.snakes.values()].filter(s => s.alive).map(s => ({ id: s.id, n: s.name, b: s.bot ? 1 : 0, sk: s.bot ? '' : s.skin, ci: s.ci }));
  }
  snapshotFor(me, withBoard) {
    const R2 = C.VIEW_RADIUS * C.VIEW_RADIUS, F2 = C.FOOD_RADIUS * C.FOOD_RADIUS;
    const sn = [], mm = [];
    for (const s of this.snakes.values()) {
      if (!s.alive) continue;
      mm.push([s.id, Math.round(s.x), Math.round(s.y), s.bot ? 1 : 0]);
      let vis = s === me;
      if (!vis) {
        let dx = s.x - me.x, dy = s.y - me.y;
        if (dx * dx + dy * dy < R2) vis = true;
        else for (const sg of s.segs) { dx = sg.x - me.x; dy = sg.y - me.y; if (dx * dx + dy * dy < R2) { vis = true; break; } }
      }
      if (!vis) continue;
      const segs = [];
      for (const sg of s.segs) segs.push(Math.round(sg.x), Math.round(sg.y));
      sn.push([s.id, Math.round(s.x), Math.round(s.y), Math.round(Math.atan2(s.dy, s.dx) * 100), (s.boosting ? 1 : 0) | (s.shield > 0 ? 2 : 0), s.len, s.score, segs]);
    }
    const f = [];
    for (const fo of this.food.values()) { const dx = fo.x - me.x, dy = fo.y - me.y; if (dx * dx + dy * dy < F2) f.push([fo.id, Math.round(fo.x), Math.round(fo.y), fo.t]); }
    const out = { t: 's', k: this.tick, you: { e: Math.round(me.energy), sc: me.score, ln: me.len, kl: me.kills, co: me.coins, tm: Math.floor(this.time - me.born) }, sn, mm, f };
    if (withBoard) out.lb = [...this.snakes.values()].filter(s => s.alive).sort((a, b) => b.score - a.score).slice(0, 8).map(s => [s.id, s.score, s.len]);
    return out;
  }
}

module.exports = { Match, Snake, FOOD_TYPES, FOOD_DEF, SKINS, BOT_NAMES };
