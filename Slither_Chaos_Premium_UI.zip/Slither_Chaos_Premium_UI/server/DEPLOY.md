# Deploying the Slither Chaos server

The server is one small Node.js program (WebSocket + matchmaking + authoritative simulation + leaderboard file).
**Nothing is deployed for you.** Until you host it somewhere, the online buttons will show a "server not set up" / "could not reach" error, and offline play keeps working.

## What you need
* Node.js 18+ (20 recommended) on the host, or Docker.
* A host that keeps a process running 24/7 and allows WebSockets. Free "sleeping" tiers are NOT suitable: they stop the process after idle time, so matchmaking would fail and the leaderboard file may be wiped.
* A persistent disk/volume for `DATA_DIR` (the leaderboard is `leaderboard.json`). Without a persistent disk the leaderboard resets on every redeploy.
* HTTPS/WSS: Android builds and browsers expect `wss://`. Most hosts below give you HTTPS automatically; on a plain VPS put Caddy or nginx in front (example below).
* No secret keys are needed by the game or the server. The only value in the client is the public server URL.

## Option A - Small VPS (most predictable)
Any 1 vCPU / 1 GB Linux VPS (Hetzner, DigitalOcean, Vultr, etc.; typically in the low single-digit to ~$5-6 USD per month - check the provider's current price).
```
sudo apt install -y nodejs npm caddy        # or install Node 20 from nodesource
cd server && npm install --omit=dev
PORT=8080 DATA_DIR=/var/lib/slither node server.js      # run it under systemd or pm2 so it restarts
```
Caddy (`/etc/caddy/Caddyfile`) gives you automatic HTTPS + WebSocket proxying:
```
game.yourdomain.com {
    reverse_proxy localhost:8080
}
```
Point a DNS A record for `game.yourdomain.com` at the VPS. Your client URL is then `wss://game.yourdomain.com`.

## Option B - Container host (Fly.io, Railway, Render paid instance, etc.)
Use the included `Dockerfile`. Requirements: always-on instance (no auto-sleep), one persistent volume mounted at `/data`, port 8080. Pricing differs per provider and changes; expect a small paid plan (a few USD/month). Do not assume a free tier gives you a permanent server.
Run **one instance only**: each instance keeps its matches in memory, and the leaderboard file is per instance (see "Scaling" below).

## Point the game at your server
Edit `scripts/OnlineConfig.gd` in the Godot project:
```
const SERVER_URL = "wss://game.yourdomain.com"
```
Re-export the game. Players never type an address.

## Check that it is up
Open `https://game.yourdomain.com/health` - you should see `{"ok":true,...}`. `/leaderboard` shows the top 20 as JSON.

## Settings (environment variables, see `.env.example`)
`PORT`, `TARGET_SNAKES` (humans+bots per match, default 10), `MAX_HUMANS` (default 10), `MAX_MATCHES` (default 20), `FILL_BOTS`, `GRACE_MS` (reconnect window, default 12 s), `DATA_DIR`.
Keep `SLITHER_TEST` unset/0 in production (it enables a teleport command used only by the automated tests).

## Capacity and scaling (honest numbers)
* One process simulates every match at 30 ticks/s. The simulation is light (10 snakes per match); in the automated tests a handful of matches used a tiny fraction of one CPU core, but **I have not load-tested hundreds of players**. Measure on your own host before launch (`MAX_MATCHES` caps the load; players get a "server full" message beyond it).
* Matchmaking assigns players to the fullest match that still has room, otherwise creates a new match.
* To go beyond one process you would need several server instances plus a shared leaderboard store (e.g. a database) and a lobby/router service. That is not included.

## Known limits
* WebSocket runs over TCP: a lost packet briefly delays later ones (no UDP). Interpolation hides small hiccups; bad mobile connections may stutter.
* No accounts: a player is identified by a random device id stored on their device. Anyone who reinstalls gets a fresh identity. Names are not moderated beyond character filtering.
* Cosmetic skin choice is sent by the client and is not verified against purchases (it does not affect gameplay or rewards).
