'use strict';
// All settings come from environment variables (see .env.example). No secrets are required.
function num(name, def) { const v = Number(process.env[name]); return Number.isFinite(v) && process.env[name] !== '' && process.env[name] !== undefined ? v : def; }
function bool(name, def) { const v = process.env[name]; if (v === undefined || v === '') return def; return v === '1' || v.toLowerCase() === 'true'; }

module.exports = {
  PORT: num('PORT', 8080),
  ARENA: num('ARENA', 8000),             // same arena size as the offline game
  TICK_HZ: num('TICK_HZ', 30),           // simulation rate
  SNAP_HZ: num('SNAP_HZ', 15),           // snapshot rate sent to each player
  TARGET_SNAKES: num('TARGET_SNAKES', 10), // humans + bots per match
  MAX_HUMANS: num('MAX_HUMANS', 10),     // human capacity of a match (bots make room)
  MAX_MATCHES: num('MAX_MATCHES', 20),   // matches per server process
  FOOD_TARGET: num('FOOD_TARGET', 260),
  FILL_BOTS: bool('FILL_BOTS', true),
  GRACE_MS: num('GRACE_MS', 12000),      // how long a disconnected player's snake stays alive for reconnect
  SESSION_TTL_MS: num('SESSION_TTL_MS', 60000),
  ABANDON_MS: num('ABANDON_MS', 30000),  // empty-of-humans match is destroyed after this
  BOT_RESPAWN_MS: num('BOT_RESPAWN_MS', 4500),
  SPAWN_SHIELD_MS: num('SPAWN_SHIELD_MS', 2500),
  VIEW_RADIUS: num('VIEW_RADIUS', 1500),
  FOOD_RADIUS: num('FOOD_RADIUS', 1300),
  MM_INTERVAL_MS: num('MM_INTERVAL_MS', 250), // matchmaking queue processing interval
  DATA_DIR: process.env.DATA_DIR || require('path').join(__dirname, 'data'),
  TEST_MODE: bool('SLITHER_TEST', false) // NEVER enable in production (allows teleporting snakes)
};
