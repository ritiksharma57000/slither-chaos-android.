# Slither Chaos - Premium UI update

Godot **3.5.3**, GLES2 renderer (unchanged). Built on top of your `Slither_Chaos_Online_Multiplayer` project.

## HOW TO OPEN AND RUN
1. Unzip the folder anywhere.
2. Start Godot 3.5.3, click **Import**, pick `project.godot` in this folder.
3. Let the editor finish importing once (it imports the new fonts and the new music file; the first open takes a few seconds longer).
4. Press **F5**. The game starts on the new loading screen, then the homepage.
5. Check the Output panel after the first run. If Godot reports any script error, send me the exact message and I will fix it.

## READ THIS FIRST: what was and was not tested
| Item | Status |
|---|---|
| All GDScript | **Never run in Godot.** No Godot engine was available where this was built. I checked every script with my own static checks (indentation, bracket balance, no Godot 4 syntax, every `res://` path exists, every signal handler name exists, every call into GameManager / UISettings exists). That cannot catch every Godot 3.5.3 API mistake, so expect that a small fix may be needed on the first run. |
| Server address / protocol | `OnlineConfig.gd`, `OnlineClient.gd`, `GameManager.gd` and the whole `server/` folder are **byte-for-byte identical** to your upload (verified with diff). |
| Online multiplayer | Not tested in this update (needs your hosted server). The menu only calls your existing `OnlineOverlay` / `OnlineClient` code. |
| Performance on your old laptop | Not measured. The effects are lightweight 2D drawing and are designed for it, but please test. |

## What is new
**Loading screen** (`scenes/Boot.tscn`, now the main scene)
* Neon logo, snake circling the logo, sparks following it, animated depth grid, floating orbs, pulsing glow, progress bar, percentage, status text (INITIALIZING, LOADING ASSETS, READY), rotating tips that cross-fade, small spinner.
* **The progress is real.** All scenes, textures, sounds and fonts are loaded stage by stage with `ResourceLoader.load_interactive()` and kept in memory. The bar can never run ahead of the real value. When the last resource is loaded it shows READY and moves on after a very short fade. If loading is fast, the screen is fast. The name of the file being loaded is shown under the bar.
* It cannot trap you: a 25 s watchdog plus an independent 30 s timer both continue to the menu.

**Homepage**: animated arena, snake mascot (uses your equipped skin colours), floating orbs, particles, pointer parallax, logo, subtitle NEON ARCADE SURVIVAL, your real Best Score / Longest Snake / Best Survival Time, and your coin balance. Exactly three main buttons: **PLAY**, **CUSTOMIZE**, **SETTINGS**.

**PLAY -> mode screen**
* OFFLINE SURVIVAL: opens the existing offline game (`MainGame.tscn`) with a fade.
* ONLINE QUICK PLAY: opens your existing connecting / matchmaking / error / retry overlay. Nothing is faked; the card shows the real connection status. A LEADERBOARD button (your existing online leaderboard) is on this card.

**CUSTOMIZE** (tabs)
* SNAKE SKINS: live animated preview, shows EQUIPPED / UNLOCKED / LOCKED honestly. Locked skins stay locked until you unlock them with real coins (your existing coin rules). Nothing is given away.
* MISSIONS and CAREER STATS: your existing missions (claim rewards) and statistics, moved here so nothing was lost.

**SETTINGS**: sound effects, sound volume, music, control sensitivity, graphics quality (Low / Medium / High), particles, glow, screen shake, BACK, and QUIT GAME on desktop. Everything is saved and restored on the next launch.

**In-game**: restyled HUD (score, length, big timer, neon pause button, boost button with an energy ring that shows your real boost energy, framed minimap), restyled pause menu (Resume, Restart, Sound, Main Menu) and game-over screen. Input handling is unchanged.

## How each setting really works
| Setting | Effect |
|---|---|
| Sound effects | Existing `GameManager.sound_enabled` |
| Sound volume | Master audio bus volume |
| Music | Existing `GameManager.music_enabled`. **Your project had no music file, so the toggle did nothing before.** I added a short original ambient loop (`assets/audio/music_loop.wav`, generated for this project). Music is now ON by default (quiet). Turn it off in Settings if you prefer. |
| Graphics quality | **Low** switches on your existing low-performance mode (fewer AI snakes / food / decor in both offline and online scenes) and uses lighter menu effects. **Medium** = your standard gameplay. **High** = same gameplay as Medium with more menu particles and effects. High does not add gameplay load. |
| Particles | Menu particles, boost particles and burst effects |
| Glow effects | Halos on buttons, panels, orbs and the HUD |
| Screen shake | Short camera shake when you die (offline and online). There was no shake in the game before. |
| Control sensitivity | Offline snake turning speed. **Online it has no effect**, because online steering is decided by the server protocol, which I was told not to change. |

## Things I did NOT do (honest list)
* No free-form colour picker. "Colours" means your existing skins, because a custom colour would need changes in gameplay code and the save format.
* No separate sensitivity for online play (see above).
* Old `PerspectiveGrid.gd` and `MenuSnakeMascot.gd` are still in the project but no longer used by the menu. I did not delete them.
* The old MainMenu layout (extra rows, modals) was replaced. Its features live on in the new screens, except the QUIT button, which moved into Settings.

## Save data
* `user://slither_chaos_save.json` is written by the same `GameManager` code as before. Nothing is reset or migrated.
* New settings are stored separately in `user://slither_ui_settings.json`, so deleting that file can never touch your records.
* Quality and the old low-performance flag are kept in sync. Existing players with low-performance mode on start on LOW.

## Files
New: `scripts/UISettings.gd` (autoload), `Boot.gd`, `NeonButton.gd`, `MenuBackground.gd`, `SkinPreview.gd`, `BoostRing.gd`, `scenes/Boot.tscn`, `assets/fonts/Poppins-Bold.ttf`, `Poppins-Medium.ttf`, `assets/audio/music_loop.wav`.
Rewritten: `scenes/MainMenu.tscn`, `scripts/MainMenu.gd` (UI is built in code, so there are no fragile node paths).
Small edits: `project.godot` (main scene = Boot, one autoload line), `HUD.gd`, `Minimap.gd`, `PauseMenu.gd`, `GameOverMenu.gd` (styling only); `Player.gd` (sensitivity, particles toggle, shake on death); `ParticleBurst.gd` (particles toggle); `OnlineArena.gd` (shake on death); `OnlineOverlay.gd` (fonts only, logic untouched).

## Licenses
Poppins fonts: SIL Open Font License 1.1 (free to bundle in games).
